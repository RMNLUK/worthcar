// Main analysis endpoint - fetches MOT data from DVSA, runs Claude AI analysis

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { registration, userNotes = '' } = req.body;
    if (!registration) return res.status(400).json({ status: 'error', error: 'Registration number is required' });

    const cleanReg = registration.trim().toUpperCase().replace(/\s+/g, '');

    // 1. Fetch MOT data from DVSA
    const motDataResult = await fetchDvsaData(cleanReg);
    if (motDataResult.error) {
      return res.status(motDataResult.statusCode || 500).json({ status: 'error', registration: cleanReg, error: motDataResult.error });
    }
    if (!motDataResult.motTests || motDataResult.motTests.length === 0) {
      return res.json({ status: 'no_mot_history', registration: cleanReg, vehicle: motDataResult.vehicle, error: 'Vehicle found but has no MOT history records' });
    }

    // 2. Load active prompt from Supabase
    let activePrompt = null;
    try {
      const promptRes = await fetch(
        `${process.env.SUPABASE_URL}/rest/v1/PromptVersion?is_active=eq.true&limit=1&select=*`,
        { headers: { 'apikey': process.env.SUPABASE_SERVICE_ROLE_KEY, 'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}` } }
      );
      const prompts = await promptRes.json();
      if (prompts && prompts.length > 0) activePrompt = prompts[0].prompt_text;
    } catch (e) { console.warn('Could not load prompt from Supabase:', e.message); }

    if (!activePrompt) {
      // Fallback to AppConfig
      try {
        const cfgRes = await fetch(
          `${process.env.SUPABASE_URL}/rest/v1/AppConfig?key=eq.analysis_prompt&select=*`,
          { headers: { 'apikey': process.env.SUPABASE_SERVICE_ROLE_KEY, 'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}` } }
        );
        const configs = await cfgRes.json();
        if (configs && configs.length > 0) activePrompt = configs[0].value;
      } catch (e) { console.warn('Could not load AppConfig:', e.message); }
    }

    if (!activePrompt) {
      return res.status(500).json({ status: 'error', error: 'No active MOT Master Prompt configured. Please save a prompt in the Admin dashboard.' });
    }

    // 3. Build prompt and call Claude
    const prompt = buildAnalysisPrompt(motDataResult, userNotes, activePrompt);
    let aiAnalysis;
    try {
      const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': process.env.ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-5-20251001',
          max_tokens: 2000,
          messages: [{ role: 'user', content: prompt }],
        }),
      });
      const claudeData = await claudeRes.json();
      const rawText = claudeData.content?.[0]?.text || '';
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) aiAnalysis = JSON.parse(jsonMatch[0]);
    } catch (err) {
      console.error('AI analysis failed:', err.message);
      return res.json({
        status: 'partial_success',
        registration: cleanReg,
        vehicle: motDataResult.vehicle,
        raw_mot_history: motDataResult.motTests,
        ai_analysis: null,
        error: `AI analysis unavailable: ${err.message}`,
      });
    }

    return res.json({
      status: 'success',
      registration: cleanReg,
      vehicle: motDataResult.vehicle,
      raw_mot_history: motDataResult.motTests,
      ai_analysis: aiAnalysis,
      error: null,
    });

  } catch (error) {
    console.error('analyzeMotHistory error:', error);
    return res.status(500).json({ status: 'error', error: error.message });
  }
}

async function fetchDvsaData(cleanReg) {
  try {
    const CLIENT_ID = process.env.MOT_CLIENT_ID;
    const CLIENT_SECRET = process.env.MOT_CLIENT_SECRET;
    const SCOPE_URL = process.env.MOT_SCOPE_URL;
    const TOKEN_URL = process.env.MOT_TOKEN_URL;
    const API_KEY = process.env.MOT_API_KEY;

    if (!CLIENT_ID || !CLIENT_SECRET || !SCOPE_URL || !TOKEN_URL || !API_KEY) {
      return { error: 'DVSA API credentials are not configured', statusCode: 500 };
    }

    const scope = SCOPE_URL.endsWith('/.default') ? SCOPE_URL : `${SCOPE_URL}/.default`;
    const tokenResponse = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64')}`,
      },
      body: new URLSearchParams({ grant_type: 'client_credentials', scope }).toString(),
    });

    if (!tokenResponse.ok) return { error: 'Failed to authenticate with DVSA API', statusCode: 500 };
    const { access_token } = await tokenResponse.json();
    if (!access_token) return { error: 'Failed to obtain DVSA access token', statusCode: 500 };

    const formattedReg = cleanReg.replace(/^([A-Z]{2})(\d{2})([A-Z]{3})$/, '$1$2 $3');
    const motUrl = `https://history.mot.api.gov.uk/v1/trade/vehicles/registration/${formattedReg}`;
    const motHistoryResponse = await fetch(motUrl, {
      headers: { 'x-api-key': API_KEY, 'Authorization': `Bearer ${access_token}`, 'Accept': 'application/json' },
    });

    if (!motHistoryResponse.ok) {
      if (motHistoryResponse.status === 404) return { error: 'Vehicle registration not found in DVSA database', statusCode: 404 };
      return { error: `DVSA API error: ${motHistoryResponse.statusText}`, statusCode: motHistoryResponse.status };
    }

    const dvsaData = await motHistoryResponse.json();
    if (!dvsaData) return { error: 'No vehicle data found', statusCode: 404 };

    if (!dvsaData.motTests || dvsaData.motTests.length === 0) {
      return {
        vehicle: { registration: dvsaData.registration, make: dvsaData.make, model: dvsaData.model, fuelType: dvsaData.fuelType, colour: dvsaData.primaryColour, firstUsedDate: dvsaData.firstUsedDate, registrationDate: dvsaData.registrationDate, motExpiryDate: null },
        motTests: [], statusCode: 200,
      };
    }

    return {
      vehicle: { registration: dvsaData.registration, make: dvsaData.make, model: dvsaData.model, fuelType: dvsaData.fuelType, colour: dvsaData.primaryColour, firstUsedDate: dvsaData.firstUsedDate, registrationDate: dvsaData.registrationDate, motExpiryDate: dvsaData.motTests[0]?.expiryDate || null },
      motTests: dvsaData.motTests.map(test => ({
        completedDate: test.completedDate, testResult: test.testResult, odometerValue: test.odometerValue,
        odometerUnit: test.odometerUnit === 'MI' ? 'mi' : 'km',
        defects: (test.defects || []).map(d => ({ text: d.text, type: d.type === 'DANGEROUS' ? 'dangerous' : (d.type || '').toLowerCase() })),
        expiryDate: test.expiryDate,
      })),
    };
  } catch (error) {
    return { error: error.message, statusCode: 500 };
  }
}

function buildAnalysisPrompt(motDataResult, userNotes, customPromptPrefix) {
  const recentTests = motDataResult.motTests.slice(0, 3);
  const motSummary = {
    vehicle: `${motDataResult.vehicle.make} ${motDataResult.vehicle.model} (${motDataResult.vehicle.registration})`,
    age: new Date().getFullYear() - new Date(motDataResult.vehicle.firstUsedDate).getFullYear(),
    mileage: recentTests[0]?.odometerValue || 0,
    totalTests: motDataResult.motTests.length,
    passes: motDataResult.motTests.filter(t => t.testResult === 'PASSED').length,
    fails: motDataResult.motTests.filter(t => t.testResult === 'FAILED').length,
    recentDefects: recentTests.flatMap(t => t.defects.map(d => `${d.type}: ${d.text}`)).slice(0, 10),
  };
  return `${customPromptPrefix}\n\nHere is the raw MOT data to analyze:\n${JSON.stringify(motSummary, null, 2)}\n\nAdditional user notes:\n${userNotes || 'None provided'}\n\nRespond ONLY with valid JSON matching the output schema above.`;
}
