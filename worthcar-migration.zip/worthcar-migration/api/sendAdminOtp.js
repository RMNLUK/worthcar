// Sends OTP email for admin login

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });

  if (password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const supaHeaders = { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' };

  // Generate OTP
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  // Invalidate old codes
  await fetch(`${SUPABASE_URL}/rest/v1/AdminOTP?email=eq.${email}&used=eq.false`, { method: 'PATCH', headers: supaHeaders, body: JSON.stringify({ used: true }) });

  // Store new code
  await fetch(`${SUPABASE_URL}/rest/v1/AdminOTP`, { method: 'POST', headers: supaHeaders, body: JSON.stringify({ email, code, expires_at: expiresAt, used: false }) });

  // Send via Resend
  const resendRes = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: `WorthCar Admin <${process.env.RESEND_FROM_EMAIL || 'admin@worthcar.co.uk'}>`,
      to: [email],
      subject: 'WorthCar Admin — Verification Code',
      html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px"><h2 style="color:#0f172a">Admin Verification</h2><p style="color:#64748b;font-size:14px">Your one-time verification code:</p><div style="font-size:36px;font-weight:800;letter-spacing:8px;color:#0f172a;background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:20px;text-align:center;margin:20px 0">${code}</div><p style="color:#94a3b8;font-size:12px">Expires in 10 minutes. Do not share this code.</p></div>`,
    }),
  });

  if (!resendRes.ok) return res.status(500).json({ error: 'Failed to send verification email.' });
  return res.json({ success: true });
}
