// Fetches raw MOT data from DVSA (lightweight version, no AI analysis)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { registration } = req.body || {};
  if (!registration) return res.status(400).json({ error: 'Registration is required' });

  const cleanReg = registration.replace(/\s/g, '').toUpperCase();
  const CLIENT_ID = process.env.MOT_CLIENT_ID;
  const CLIENT_SECRET = process.env.MOT_CLIENT_SECRET;
  const SCOPE_URL = process.env.MOT_SCOPE_URL;
  const TOKEN_URL = process.env.MOT_TOKEN_URL;
  const API_KEY = process.env.MOT_API_KEY;

  if (!CLIENT_ID || !CLIENT_SECRET || !SCOPE_URL || !TOKEN_URL || !API_KEY) {
    return res.status(500).json({ error: 'DVSA API credentials are not configured.' });
  }

  try {
    const tokenResponse = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': `Basic ${Buffer.from(`${CLIENT_ID}:${CLIENT_SECRET}`).toString('base64')}` },
      body: new URLSearchParams({ grant_type: 'client_credentials', scope: `${SCOPE_URL}/.default` }).toString(),
    });

    if (!tokenResponse.ok) return res.status(500).json({ error: 'Failed to authenticate with DVSA API' });
    const { access_token } = await tokenResponse.json();

    const motHistoryResponse = await fetch(`https://history.mot.api.gov.uk/v1/trade/vehicles/registration/${cleanReg}`, {
      headers: { 'x-api-key': API_KEY, 'Authorization': `Bearer ${access_token}`, 'Accept': 'application/json' },
    });

    if (!motHistoryResponse.ok) {
      if (motHistoryResponse.status === 404) return res.json({ found: false, vehicle: {}, motTests: [] });
      return res.status(motHistoryResponse.status).json({ error: `DVSA API error` });
    }

    const dvsaData = await motHistoryResponse.json();
    if (!dvsaData?.motTests) return res.json({ found: false, vehicle: {}, motTests: [] });

    return res.json({
      found: true,
      vehicle: { registration: dvsaData.registration, make: dvsaData.make, model: dvsaData.model, fuelType: dvsaData.fuelType, colour: dvsaData.primaryColour, firstUsedDate: dvsaData.firstUsedDate, registrationDate: dvsaData.registrationDate, motExpiryDate: dvsaData.motTests[0]?.expiryDate || null },
      motTests: dvsaData.motTests.map(test => ({ completedDate: test.completedDate, testResult: test.testResult, odometerValue: test.odometerValue, odometerUnit: test.odometerUnit === 'MI' ? 'mi' : 'km', defects: (test.defects || []).map(d => ({ text: d.text, type: d.type === 'DANGEROUS' ? 'dangerous' : (d.type || '').toLowerCase() })), expiryDate: test.expiryDate })),
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
