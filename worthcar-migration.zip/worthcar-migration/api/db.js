// Generic database endpoint - handles all CRUD operations via Supabase REST API

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { table, operation, data, id, filter, sort, limit } = req.body || {};
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

  const headers = {
    'apikey': SUPABASE_KEY,
    'Authorization': `Bearer ${SUPABASE_KEY}`,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation',
  };

  const baseUrl = `${SUPABASE_URL}/rest/v1/${table}`;

  try {
    let response;

    if (operation === 'list') {
      let url = `${baseUrl}?select=*`;
      if (sort) {
        const col = sort.replace(/^-/, '');
        const dir = sort.startsWith('-') ? 'desc' : 'asc';
        url += `&order=${col}.${dir}`;
      }
      if (limit) url += `&limit=${limit}`;
      response = await fetch(url, { headers });

    } else if (operation === 'filter') {
      let url = `${baseUrl}?select=*`;
      if (filter) {
        Object.entries(filter).forEach(([key, value]) => {
          if (value && typeof value === 'object' && value.$in) {
            url += `&${key}=in.(${value.$in.map(v => `"${v}"`).join(',')})`;
          } else {
            url += `&${key}=eq.${encodeURIComponent(value)}`;
          }
        });
      }
      if (sort) {
        const col = sort.replace(/^-/, '');
        const dir = sort.startsWith('-') ? 'desc' : 'asc';
        url += `&order=${col}.${dir}`;
      }
      if (limit) url += `&limit=${limit}`;
      response = await fetch(url, { headers });

    } else if (operation === 'create') {
      response = await fetch(baseUrl, { method: 'POST', headers, body: JSON.stringify(data) });

    } else if (operation === 'update') {
      response = await fetch(`${baseUrl}?id=eq.${id}`, { method: 'PATCH', headers, body: JSON.stringify(data) });

    } else if (operation === 'delete') {
      await fetch(`${baseUrl}?id=eq.${id}`, { method: 'DELETE', headers });
      return res.json({ success: true });

    } else {
      return res.status(400).json({ error: `Unknown operation: ${operation}` });
    }

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      console.error(`DB ${operation} on ${table} failed:`, error);
      return res.status(response.status).json({ error });
    }

    const result = await response.json();
    if (Array.isArray(result) && (operation === 'create' || operation === 'update')) {
      return res.json(result[0] || {});
    }
    return res.json(result);
  } catch (error) {
    console.error('DB error:', error);
    return res.status(500).json({ error: error.message });
  }
}
