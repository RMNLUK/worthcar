// Verifies admin OTP code

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { email, code } = req.body || {};
  if (!email || !code) return res.status(400).json({ error: 'Email and code are required.' });

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const supaHeaders = { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' };

  const otpRes = await fetch(`${SUPABASE_URL}/rest/v1/AdminOTP?email=eq.${email}&code=eq.${code}&used=eq.false&select=*`, { headers: supaHeaders });
  const otps = await otpRes.json();

  if (!otps || otps.length === 0) return res.status(401).json({ error: 'Invalid or expired verification code.' });

  const otp = otps[0];
  if (new Date(otp.expires_at) < new Date()) return res.status(401).json({ error: 'Verification code has expired.' });

  // Mark as used
  await fetch(`${SUPABASE_URL}/rest/v1/AdminOTP?id=eq.${otp.id}`, { method: 'PATCH', headers: supaHeaders, body: JSON.stringify({ used: true }) });

  return res.json({ success: true, email });
}
