// Returns vehicle image - uses Unsplash generic car photo (no AI image generation needed)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  // Return a high quality generic car image from Unsplash
  return res.json({
    success: true,
    imageUrl: 'https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800&h=400&fit=crop&auto=format',
    source: 'fallback',
  });
}
