// Direct Claude API call for use in admin dashboard analytics

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { prompt, model = 'claude-sonnet-4-5-20251001', response_json_schema } = req.body || {};
  if (!prompt) return res.status(400).json({ error: 'Prompt is required.' });

  try {
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5-20251001',
        max_tokens: 1500,
        messages: [{ role: 'user', content: response_json_schema ? `${prompt}\n\nRespond ONLY with valid JSON.` : prompt }],
      }),
    });

    const claudeData = await claudeRes.json();
    const rawText = claudeData.content?.[0]?.text || '';

    if (response_json_schema) {
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) return res.json(JSON.parse(jsonMatch[0]));
    }

    return res.json({ text: rawText });
  } catch (error) {
    console.error('invokeLLM error:', error);
    return res.status(500).json({ error: error.message });
  }
}
