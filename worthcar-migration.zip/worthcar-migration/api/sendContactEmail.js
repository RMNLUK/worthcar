// Saves contact enquiry to Supabase and sends email via Resend

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { full_name, email, phone, message } = req.body || {};
  if (!full_name || !email || !message) return res.status(400).json({ error: 'Name, email and message are required.' });

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const supaHeaders = { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': 'application/json' };

  // Save to database
  await fetch(`${SUPABASE_URL}/rest/v1/ContactEnquiry`, { method: 'POST', headers: supaHeaders, body: JSON.stringify({ full_name, email, phone, message }) });

  // Send email via Resend
  const resendRes = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: `WorthCar <${process.env.RESEND_FROM_EMAIL || 'noreply@worthcar.co.uk'}>`,
      to: [process.env.CONTACT_EMAIL || 'support@ugm-inc.com'],
      subject: `New Contact Enquiry from ${full_name}`,
      text: `New enquiry from WorthCar.co.uk:\n\nName: ${full_name}\nEmail: ${email}\nPhone: ${phone || 'Not provided'}\nMessage:\n${message}`,
    }),
  });

  if (!resendRes.ok) {
    const err = await resendRes.json().catch(() => ({}));
    return res.status(500).json({ error: 'Failed to send email', details: err });
  }

  return res.json({ success: true });
}
