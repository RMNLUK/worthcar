// Extracts UK registration plate from an image using Claude vision

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const { imageBase64, mimeType = 'image/jpeg' } = req.body || {};
  if (!imageBase64) return res.status(400).json({ error: 'Image data is required.' });

  try {
    const claudeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5-20251001',
        max_tokens: 200,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mimeType, data: imageBase64 } },
            { type: 'text', text: 'You are a UK vehicle registration plate reader. Extract the registration number from this image.\n\nRules:\n- Return the registration in standard UK format (e.g., "AB12 CDE")\n- Uppercase only, include a space between 4th and 5th characters\n- UK plates: 2 letters + 2 numbers + space + 3 letters\n\nRespond ONLY with JSON: {"registration": "AB12 CDE", "confidence": 95, "raw_text": "AB12CDE"}' },
          ],
        }],
      }),
    });

    const claudeData = await claudeRes.json();
    const rawText = claudeData.content?.[0]?.text || '{}';
    const jsonMatch = rawText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Could not parse response');
    return res.json(JSON.parse(jsonMatch[0]));
  } catch (error) {
    console.error('extractRegistration error:', error);
    return res.status(500).json({ error: 'Failed to extract registration from image.' });
  }
}
