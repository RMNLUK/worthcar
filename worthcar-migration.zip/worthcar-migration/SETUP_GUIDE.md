# WorthCar Migration — Step by Step Setup Guide

**Total time: approximately 2 hours**
No coding required. Just copy, paste, and click.

---

## Before You Start — Checklist

Make sure you have accounts at:
- [ ] GitHub (github.com)
- [ ] Vercel (vercel.com)
- [ ] Supabase (supabase.com)
- [ ] Resend (resend.com)
- [ ] Anthropic (console.anthropic.com)

Also have ready:
- [ ] Your DVSA API credentials (same ones from Base44 — check your Base44 settings)
- [ ] Your WorthCar logo file saved as `wclogo.png`

---

## STEP 1 — Upload your code to GitHub (15 minutes)

1. Go to **github.com** and sign in
2. Click the **+** button (top right) → **New repository**
3. Name it `worthcar`
4. Leave everything else as default
5. Click **Create repository**
6. On the next page, click **uploading an existing file**
7. Open the `worthcar-migration` folder on your computer
8. **Select ALL files and folders** inside it and drag them into the GitHub upload area
9. Scroll down and click **Commit changes**

✅ Your code is now on GitHub.

---

## STEP 2 — Add your logo file (5 minutes)

1. Find your WorthCar logo image on your computer (save it as `wclogo.png` if needed)
2. In your GitHub repo, click into the `public` folder
3. Click **Add file** → **Upload files**
4. Upload `wclogo.png`
5. Click **Commit changes**

✅ Logo is uploaded.

---

## STEP 3 — Set up your database in Supabase (15 minutes)

1. Go to **supabase.com** → sign in → open your project
2. In the left sidebar, click **SQL Editor**
3. Click **New query**
4. Open the file `supabase-setup.sql` from your migration folder
5. Copy **all the text** inside it
6. Paste it into the SQL Editor in Supabase
7. Click the green **Run** button

You should see: "Success. No rows returned."

✅ Your database tables are created.

---

## STEP 4 — Connect to Vercel and deploy (20 minutes)

1. Go to **vercel.com** → sign in → click **Add New** → **Project**
2. Click **Import Git Repository**
3. Find your `worthcar` GitHub repo and click **Import**
4. Under **Framework Preset**, it should auto-detect Vite — if not, select **Vite** from the dropdown
5. **Do NOT click Deploy yet** — first add your environment variables (Step 5)

---

## STEP 5 — Add environment variables in Vercel (20 minutes)

Still on the Vercel import screen, scroll down to **Environment Variables**.

Open the file `ENVIRONMENT_VARIABLES.txt` from your migration folder.
Add each variable one by one:

**Click "Add" for each one:**

| Name | Value |
|------|-------|
| MOT_CLIENT_ID | [from Base44 settings] |
| MOT_CLIENT_SECRET | [from Base44 settings] |
| MOT_SCOPE_URL | [from Base44 settings] |
| MOT_TOKEN_URL | [from Base44 settings] |
| MOT_API_KEY | [from Base44 settings] |
| SUPABASE_URL | [from Supabase → Settings → API → Project URL] |
| SUPABASE_SERVICE_ROLE_KEY | [from Supabase → Settings → API → service_role key] |
| ANTHROPIC_API_KEY | [from console.anthropic.com → API Keys] |
| RESEND_API_KEY | [from resend.com → API Keys] |
| RESEND_FROM_EMAIL | noreply@worthcar.co.uk |
| CONTACT_EMAIL | support@ugm-inc.com |
| ADMIN_PASSWORD | [choose a strong password] |

Once all variables are added, click **Deploy**.

⏱ Vercel will build and deploy your site. This takes about 2 minutes.

✅ Your site is live at a `worthcar-xyz.vercel.app` URL.

---

## STEP 6 — Add your first AI prompt (10 minutes)

Your admin dashboard controls the AI analysis prompt. You need to add one before the analysis feature works.

1. Go to `https://worthcar-xyz.vercel.app/admindashboard`
   (replace with your actual Vercel URL)
2. Log in with your email and the `ADMIN_PASSWORD` you set
3. Enter the OTP code sent to your email
4. Click **MOT Master Prompt** tab
5. Paste in your existing prompt from Base44 (or use the one below as a starter)
6. Click **Save & Activate**

**Starter prompt to paste:**
```
You are a UK used car expert and MOT history analyst. Analyse the provided MOT history data and give a comprehensive, honest assessment for a potential buyer. 

Focus on:
- Pattern of failures and advisories over time
- Mileage consistency and annual average
- Signs of good or poor maintenance
- Key risks a buyer should know about
- Fair market value estimate based on age, mileage and condition

Be direct, honest and helpful. Use plain English that a non-expert can understand.
```

✅ AI analysis is now active.

---

## STEP 7 — Point your domain to Vercel (10 minutes)

1. In Vercel, go to your project → **Settings** → **Domains**
2. Type `worthcar.co.uk` and click **Add**
3. Vercel will show you DNS records to add
4. Log into your domain registrar (wherever you bought worthcar.co.uk)
5. Add the DNS records Vercel shows you
6. Wait 5–30 minutes for DNS to update

✅ worthcar.co.uk now points to your new stack.

---

## STEP 8 — Test everything (15 minutes)

Test these features one by one:

- [ ] Enter a UK registration number on the homepage → should show MOT analysis
- [ ] Try the camera/photo registration feature → should read number plates
- [ ] Submit the contact form → should send an email to support@ugm-inc.com
- [ ] Log into /admindashboard → should show stats and settings
- [ ] Check that your logo appears in the header

---

## Something not working?

The most common issues are:

**"No active MOT Master Prompt configured"**
→ Go to admin dashboard and add a prompt (Step 6)

**Analysis not loading**
→ Check your DVSA credentials are correct in Vercel environment variables

**Emails not arriving**
→ In Resend, verify your domain worthcar.co.uk. Go to resend.com → Domains → Add Domain

**Logo not showing**
→ Make sure `wclogo.png` is in the `/public` folder in GitHub

---

## You're done! 🎉

Your WorthCar site is now running independently — no Base44 credits, no credit limits, full ownership.

Monthly cost: approximately £18–25 depending on traffic.
