-- WorthCar Database Setup
-- Copy and paste this entire file into your Supabase SQL Editor and click Run

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Admin OTP codes (for admin login)
CREATE TABLE IF NOT EXISTS "AdminOTP" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL,
  code TEXT NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  used BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now()
);

-- App configuration (SEO settings, prompts, etc.)
CREATE TABLE IF NOT EXISTS "AppConfig" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT now()
);

-- AI prompt versions (manages your MOT analysis prompts)
CREATE TABLE IF NOT EXISTS "PromptVersion" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  version_number INTEGER NOT NULL UNIQUE,
  prompt_text TEXT NOT NULL,
  change_notes TEXT,
  is_active BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now()
);

-- Contact form enquiries
CREATE TABLE IF NOT EXISTS "ContactEnquiry" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  message TEXT NOT NULL,
  email_sent BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT now()
);

-- Vehicle search history (for compare feature)
CREATE TABLE IF NOT EXISTS "VehicleSearch" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  registration TEXT,
  make TEXT,
  model TEXT,
  year TEXT,
  status TEXT,
  analysis JSONB,
  created_at TIMESTAMP DEFAULT now()
);

-- Vehicle image cache (saves repeated image lookups)
CREATE TABLE IF NOT EXISTS "VehicleImageCache" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_key TEXT NOT NULL UNIQUE,
  make TEXT,
  model TEXT,
  year TEXT,
  colour TEXT,
  image_url TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

-- Disable Row Level Security (RLS) - your API uses the service role key
ALTER TABLE "AdminOTP" DISABLE ROW LEVEL SECURITY;
ALTER TABLE "AppConfig" DISABLE ROW LEVEL SECURITY;
ALTER TABLE "PromptVersion" DISABLE ROW LEVEL SECURITY;
ALTER TABLE "ContactEnquiry" DISABLE ROW LEVEL SECURITY;
ALTER TABLE "VehicleSearch" DISABLE ROW LEVEL SECURITY;
ALTER TABLE "VehicleImageCache" DISABLE ROW LEVEL SECURITY;

-- Done! All tables created successfully.
