// This file is deprecated - contact emails are now handled by /api/sendContactEmail.js
// Kept here for reference only.
