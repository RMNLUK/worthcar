// WorthCar API Client — replaces Base44 SDK
// All calls now go to /api/* endpoints on Vercel

const call = async (path, body = {}) => {
  const res = await fetch(`/api/${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.error || `API error ${res.status}`);
    error.response = { status: res.status, data: err };
    throw error;
  }
  return res.json();
};

const makeEntity = (table) => ({
  list: (sort, limit) => call('db', { table, operation: 'list', sort, limit }),
  filter: (filter, sort, limit) => call('db', { table, operation: 'filter', filter, sort, limit }),
  create: (data) => call('db', { table, operation: 'create', data }),
  update: (id, data) => call('db', { table, operation: 'update', id, data }),
  delete: (id) => call('db', { table, operation: 'delete', id }),
});

export const base44 = {
  functions: {
    invoke: async (name, data) => {
      const result = await call(name, data);
      return { data: result };
    },
  },
  integrations: {
    Core: {
      InvokeLLM: (params) => call('invokeLLM', params),
      UploadFile: async ({ file }) => {
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve({ file_url: reader.result });
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      },
    },
  },
  entities: {
    VehicleSearch: makeEntity('VehicleSearch'),
    PromptVersion: makeEntity('PromptVersion'),
    AppConfig: makeEntity('AppConfig'),
    ContactEnquiry: makeEntity('ContactEnquiry'),
    VehicleImageCache: makeEntity('VehicleImageCache'),
  },
  auth: {
    me: () => Promise.resolve(null),
    logout: () => {},
    redirectToLogin: () => {},
  },
  users: {
    inviteUser: () => {
      alert('User management is not available in this version. Manage users directly in your Supabase dashboard.');
      return Promise.resolve();
    },
  },
};
