import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, RotateCcw } from "lucide-react";
import useSeo from "@/lib/useSeo";
import { Button } from "@/components/ui/button";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";

import AnalysisLoadingScreen from "@/components/analysis/AnalysisLoadingScreen";
import VehicleImageCard from "@/components/results/VehicleImageCard";
import VehicleSummaryCard from "@/components/results/VehicleSummaryCard";
import MotSummaryCard from "@/components/results/MotSummaryCard";
import MileageAnalysisCard from "@/components/results/MileageAnalysisCard";
import ScoreCards from "@/components/results/ScoreCards";
import KeyInsightsCard from "@/components/results/KeyInsightsCard";
import MaintenanceVerdictCard from "@/components/results/MaintenanceVerdictCard";
import BuyRecommendationCard from "@/components/results/BuyRecommendationCard";
import SellerChecklistCard from "@/components/results/SellerChecklistCard";
import PricingGuidanceCard from "@/components/results/PricingGuidanceCard";
import MotTimelineCard from "@/components/results/MotTimelineCard";
import RiskFlagsCard from "@/components/results/RiskFlagsCard";
import ErrorScreen from "@/components/results/ErrorScreen";
import Footer from "@/components/Footer";
import { runMotAnalysis } from "@/components/analysis/analysisService";

export default function Results() {
  const urlParams = new URLSearchParams(window.location.search);
  const registration = urlParams.get("reg") || "";
  const inputMethod = urlParams.get("method") || "manual";
  const ocrCorrected = urlParams.get("corrected") === "1";
  const ocrOriginal = urlParams.get("original") || "";

  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const noMotHistory = result?.noMotHistory === true;
  const reg = registration.toUpperCase().replace(/\s/g, "");
  const hasQualityData = result && result.motTests?.length > 0 && result.analysis?.pricing_guidance && !noMotHistory;
  const robotsDirective = error || (!isLoading && !hasQualityData) ? "noindex,follow" : "index,follow";

  useSeo({
    title: reg ? `${reg} MOT History, Mileage & Estimated Car Value | WorthCar` : "MOT Check | WorthCar",
    description: reg
      ? `Check MOT history for ${reg}, including failures, advisories, mileage trends, and estimated car value guidance based on UK public data.`
      : "MOT history and estimated car value — WorthCar.co.uk",
    canonical: reg ? `https://worthcar.co.uk/Results?reg=${reg}` : undefined,
    robots: robotsDirective,
    structuredData: hasQualityData
      ? {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "WebPage",
              name: `${reg} MOT History, Mileage & Estimated Car Value | WorthCar`,
              url: `https://worthcar.co.uk/Results?reg=${reg}`,
              description: `Check MOT history for ${reg}, including failures, advisories, mileage trends, and estimated car value guidance based on UK public data.`,
              breadcrumb: {
                "@type": "BreadcrumbList",
                itemListElement: [
                  { "@type": "ListItem", position: 1, name: "Home", item: "https://worthcar.co.uk" },
                  { "@type": "ListItem", position: 2, name: `${reg} MOT Check` },
                ],
              },
            },
            {
              "@type": "FAQPage",
              mainEntity: [
                {
                  "@type": "Question",
                  name: "Can I get a free estimated car value without email?",
                  acceptedAnswer: { "@type": "Answer", text: "Yes. WorthCar provides free estimated car value guidance without requiring an email address." },
                },
                {
                  "@type": "Question",
                  name: "How is this different from a standard MOT check?",
                  acceptedAnswer: { "@type": "Answer", text: "WorthCar adds AI-powered analysis, mileage trend detection, and estimated car value on top of the basic MOT pass/fail record." },
                },
              ],
            },
          ],
        }
      : null,
  });

  useEffect(() => {
    if (!registration) {
      setError({ type: "invalid_reg", message: "No registration provided." });
      setIsLoading(false);
      return;
    }
    runAnalysis();
  }, []);

  const runAnalysis = async () => {
    setIsLoading(true);
    setError(null);
    setCurrentStep(1);

    const stepTimer1 = setTimeout(() => setCurrentStep(2), 800);
    const stepTimer2 = setTimeout(() => setCurrentStep(3), 2500);
    const stepTimer3 = setTimeout(() => setCurrentStep(4), 5000);

    try {
      const res = await runMotAnalysis(registration);
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(stepTimer3);

      if (res.error) {
        setError({ type: res.error, message: res.message });
        setIsLoading(false);
        logSearch("error_" + res.error);
        return;
      }

      setResult(res);
      setIsLoading(false);
      logSearch("success", res);
    } catch (err) {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(stepTimer3);
      setError({ type: "api_error", message: "Something went wrong analysing this vehicle. Please try again." });
      setIsLoading(false);
      logSearch("error_api");
    }
  };

  const logSearch = async (status, res) => {
    try {
      await base44.entities.VehicleSearch.create({
        registration: registration.toUpperCase(),
        input_method: inputMethod,
        ocr_corrected: ocrCorrected,
        ocr_original_text: ocrOriginal || undefined,
        status: status === "success" ? "success" : status.startsWith("error_no") ? "error_no_record" : "error_api",
        vehicle_make: res?.vehicle?.make || undefined,
        vehicle_model: res?.vehicle?.model || undefined,
        analysis_result: res ? JSON.stringify(res.analysis).slice(0, 5000) : undefined,
      });
    } catch (e) {
      // silently fail logging
    }
  };

  if (!registration && !isLoading) {
    return <ErrorScreen type="invalid_reg" onBack={() => (window.location.href = createPageUrl("Home"))} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <AnalysisLoadingScreen registration={registration} currentStep={currentStep} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <ErrorScreen
          type={error.type}
          message={error.message}
          registration={registration}
          onBack={() => (window.location.href = createPageUrl("Home"))}
          onRetry={runAnalysis}
        />
      </div>
    );
  }

  if (!result) return null;

  const { vehicle, motTests, metrics, analysis, dataFound } = result;

  if (noMotHistory) {
    const vehicleFields = [
      { label: "Registration", value: vehicle?.registration || registration },
      { label: "Make", value: vehicle?.make || "—" },
      { label: "Model", value: vehicle?.model || "—" },
      { label: "Fuel Type", value: vehicle?.fuelType || "—" },
      { label: "Colour", value: vehicle?.colour || "—" },
      { label: "First Used", value: vehicle?.firstUsedDate || "—" },
      { label: "Registration Date", value: vehicle?.registrationDate || "—" },
    ];

    return (
      <div className="min-h-screen bg-white">
        <div className="max-w-3xl mx-auto px-4 pt-4 pb-0">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => (window.location.href = createPageUrl("Home"))}
            className="text-slate-500 hover:text-slate-900 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-1" /> New Search
          </Button>
        </div>
        <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
          <VehicleImageCard vehicle={vehicle} />
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5">
            <p className="text-sm font-semibold text-amber-800 mb-1">No MOT History Found</p>
            <p className="text-sm text-amber-700">
              This vehicle was found in the DVSA database but has no MOT history yet. It may be a new vehicle or not
              yet due for testing.
            </p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-slate-200 shadow-sm">
            <div className="bg-gradient-to-r from-slate-900 to-slate-800 px-6 py-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Vehicle Details</p>
                  <h2 className="text-white text-xl font-bold mt-1">
                    {vehicle?.make} {vehicle?.model}
                  </h2>
                </div>
                <div className="flex items-stretch rounded-md overflow-hidden border border-slate-600">
                  <div className="w-2 bg-amber-400" />
                  <div className="px-3 py-1.5 bg-slate-700">
                    <span className="text-white font-bold tracking-wider text-sm">
                      {vehicle?.registration || registration}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 divide-x divide-y divide-slate-100 bg-white">
              {vehicleFields
                .filter((f) => f.value && f.value !== "—")
                .map((field, i) => (
                  <div key={i} className="p-4 hover:bg-slate-50 transition-colors">
                    <p className="text-xs text-slate-400 uppercase tracking-wider font-medium mb-1">{field.label}</p>
                    <p className="text-sm font-semibold text-slate-900 capitalize">{field.value}</p>
                  </div>
                ))}
            </div>
          </div>
          <div className="pt-4 text-center">
            <Button variant="outline" onClick={() => (window.location.href = createPageUrl("Home"))}>
              Check Another Vehicle
            </Button>
          </div>
          <Footer />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-3xl mx-auto px-4 pt-4">
        <div className="flex items-center justify-between mb-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => (window.location.href = createPageUrl("Home"))}
            className="text-slate-500 hover:text-slate-900 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-1" /> New Search
          </Button>
          <Button variant="ghost" size="sm" onClick={runAnalysis} className="text-slate-500">
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-500 text-center">
          This report is based on available data and automated analysis. It is not a vehicle inspection or guarantee.
        </div>

        {!dataFound && (
          <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-100 text-sm text-blue-700">
            <strong>Note:</strong> We couldn't verify live MOT data for this registration. The analysis below is based
            on estimated typical data for this vehicle type and should be used as general guidance only.
          </div>
        )}
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
          <VehicleImageCard vehicle={vehicle} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <BuyRecommendationCard recommendation={analysis?.buy_recommendation} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <ScoreCards scorecard={analysis?.scorecard} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <VehicleSummaryCard vehicle={vehicle} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <MotSummaryCard metrics={metrics} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
          <MileageAnalysisCard metrics={metrics} motTests={motTests} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <KeyInsightsCard insights={analysis?.top_insights} />
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <MaintenanceVerdictCard verdict={analysis?.maintenance_verdict} summary={analysis?.summary} />
        </motion.div>

        {analysis?.risk_flags?.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <RiskFlagsCard flags={analysis.risk_flags} />
          </motion.div>
        )}

        <div className="grid md:grid-cols-2 gap-5">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
            <SellerChecklistCard requirements={analysis?.seller_requirements} />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <PricingGuidanceCard pricing={analysis?.pricing_guidance} />
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }}>
          <MotTimelineCard motTests={motTests} />
        </motion.div>

        <div className="pt-6 pb-10 space-y-6">
          <div className="text-center">
            <p className="text-xs text-slate-400 leading-relaxed max-w-md mx-auto mb-4">
              Analysis generated by AI based on MOT history data. This is for guidance only and does not constitute a
              vehicle inspection, valuation, or guarantee. Always have a vehicle professionally inspected before
              purchase.
            </p>
            <Button variant="outline" onClick={() => (window.location.href = createPageUrl("Home"))}>
              Check Another Vehicle
            </Button>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );
}