import React from "react";
import { Link } from "react-router-dom";
import useSeo from "@/lib/useSeo";
import Footer from "@/components/Footer";
import RegSearchBlock from "@/components/search/RegSearchBlock";

const PAGES = {
  "free-car-valuation-without-email": {
    title: "Free Estimated Car Value Without Email | WorthCar",
    description: "Get a free estimated car value without email or personal details. Check MOT history and receive instant UK car price guidance using public vehicle data.",
    h1: "Free Estimated Car Value Without Email",
    intro: "WorthCar gives you a full estimated car value without asking for your email address, phone number, or any personal details. Simply enter a UK registration number and get MOT history, mileage analysis, and price guidance instantly.",
    keywords: ["free estimated car value without email", "estimated car value uk", "car value without personal details"],
    faq: [
      { q: "Can I get an estimated car value without giving my email?", a: "Yes. WorthCar never asks for your email address. Enter the registration number and get a full MOT history check and estimated car value instantly — no account required." },
      { q: "Is the estimated car value free?", a: "Completely free. WorthCar uses public UK vehicle data to generate price guidance at no cost." },
      { q: "How accurate is the estimated car value?", a: "Valuations are guidance based on MOT history, mileage trends, and public data. They are not a formal appraisal but give you a strong data-backed starting point." },
    ],
  },
  "free-car-valuation-uk": {
    title: "Free Estimated Car Value UK | MOT History & Price Guidance | WorthCar",
    description: "Free UK estimated car value by registration number. Includes MOT history, mileage check, and price guidance. No email required.",
    h1: "Free Estimated Car Value UK",
    intro: "WorthCar is a free UK estimated car value service that uses public MOT history data to give you real price guidance. No email, no sign-up — just enter the registration number and get the facts.",
    keywords: ["free estimated car value uk", "uk estimated car value", "free car check uk"],
    faq: [
      { q: "What data does WorthCar use for UK estimated car values?", a: "WorthCar uses publicly available UK vehicle data including MOT history from DVSA, mileage records, and vehicle details to generate price guidance." },
      { q: "Is WorthCar better than a dealership estimate?", a: "WorthCar is data-driven and unbiased — unlike dealerships who may undervalue your car. Our guidance is based on actual MOT history and mileage facts." },
    ],
  },
  "value-my-car-by-registration-number": {
    title: "Estimated Car Value by Registration Number | WorthCar UK",
    description: "Get your estimated car value by registration number using MOT history, mileage trends, and UK public vehicle data. Free — no email needed.",
    h1: "Estimated Car Value by Registration Number",
    intro: "Enter your UK registration number and WorthCar will pull the full MOT history, mileage trends, and public vehicle data to give you an instant estimated car value. No email. No personal details. Just the facts.",
    keywords: ["estimated car value by registration number", "car value by reg", "check car value by registration"],
    faq: [
      { q: "Can I get an estimated car value using just the registration number?", a: "Yes. WorthCar looks up your vehicle's full MOT history and public data using the registration number to produce an estimated price range." },
      { q: "Does the MOT history affect the car's estimated value?", a: "Significantly. Repeated failures, advisories, and mileage inconsistencies all affect what a vehicle is worth. WorthCar makes these signals visible." },
    ],
  },
  "mot-check-uk": {
    title: "MOT Check UK — Full History with Price Guidance | WorthCar",
    description: "Run a full MOT check UK with pass/fail history, mileage trends, advisories, and AI-powered estimated car value. Free — no email required.",
    h1: "MOT Check UK with Estimated Car Value",
    intro: "WorthCar goes beyond a basic MOT check. Enter any UK registration number to see the full MOT pass/fail history, advisory trends, mileage records, and an AI-powered estimated car value — all in one place.",
    keywords: ["MOT check UK", "check MOT history", "free MOT check", "vehicle MOT history"],
    faq: [
      { q: "What is an MOT check?", a: "An MOT check shows you whether a vehicle has passed its annual roadworthiness test. WorthCar shows the full history including past failures, advisories, and mileage at each test." },
      { q: "How does MOT history affect estimated car value?", a: "A car with a clean MOT history and consistent mileage is worth more than one with repeated failures. WorthCar turns MOT data into estimated price guidance." },
      { q: "Is this an official DVSA MOT check?", a: "WorthCar uses publicly available UK vehicle data to provide guidance. For an official MOT check, use the DVSA service. WorthCar adds AI analysis and estimated car value on top." },
    ],
  },
  "check-mot-history": {
    title: "Check MOT History UK | WorthCar",
    description: "Check the full MOT history of any UK vehicle by registration number. See pass/fail records, advisories, and mileage at every test.",
    h1: "Check MOT History by Registration Number",
    intro: "WorthCar lets you check the complete MOT history of any UK vehicle. See every pass, every fail, every advisory, and the recorded mileage at each test. Use this to spot maintenance patterns and get a more accurate estimated car value.",
    keywords: ["check MOT history", "MOT history check", "full MOT history uk"],
    faq: [
      { q: "How far back does MOT history go?", a: "WorthCar shows all available MOT records from public UK data sources, typically covering many years of test history." },
      { q: "Can I check MOT history for free?", a: "Yes. WorthCar's MOT history check is completely free with no email or sign-up required." },
    ],
  },
  "vehicle-history-check-uk": {
    title: "Vehicle History Check UK | Free by Registration | WorthCar",
    description: "Free vehicle history check UK by registration number. MOT history, mileage analysis, condition signals, and estimated car value guidance.",
    h1: "Vehicle History Check UK",
    intro: "Run a free vehicle history check on any UK car using just the registration number. WorthCar shows MOT history, mileage consistency, condition signals, and an estimated car value — all powered by public UK vehicle data.",
    keywords: ["vehicle history check", "vehicle history check uk", "free vehicle check uk", "car history check"],
    faq: [
      { q: "What does a vehicle history check show?", a: "WorthCar shows MOT history, mileage at each test, pass/fail records, advisories, and an AI-generated condition summary with estimated car value guidance." },
      { q: "Is WorthCar different from a HPI check?", a: "WorthCar focuses on MOT history and public vehicle data to give you condition and estimated value guidance. It does not cover finance checks or stolen vehicle records." },
    ],
  },
  "aa-car-valuation-alternative": {
    title: "AA Car Valuation Alternative — Free Estimated Car Value | WorthCar",
    description: "Looking for a free AA car valuation alternative? WorthCar gives you an estimated car value powered by MOT history and public UK data — no email needed.",
    h1: "Free Alternative to AA Car Valuation",
    intro: "WorthCar is a free alternative to AA car valuation. Instead of relying on market averages alone, WorthCar uses the actual MOT history of the specific vehicle to give you a more accurate estimated car value. No email required.",
    keywords: ["aa car valuation", "aa car valuation alternative", "free car valuation alternative"],
    faq: [
      { q: "How does WorthCar compare to AA car valuation?", a: "WorthCar uses the specific vehicle's MOT history and mileage record to produce an estimated car value, rather than just market averages. This gives a more vehicle-specific view." },
      { q: "Is WorthCar free to use?", a: "Yes. WorthCar is completely free with no email, no registration, and no hidden fees." },
    ],
  },
  "glasses-guide-car-valuation-free-alternative": {
    title: "Glass's Guide Alternative — Free Estimated Car Value | WorthCar",
    description: "Free alternative to Glass's Guide. Check MOT history and get an estimated car value without a subscription or email.",
    h1: "Free Alternative to Glass's Guide",
    intro: "Glass's Guide is used by trade professionals, but most buyers can't access it for free. WorthCar offers a free, public alternative that uses MOT history and public vehicle data to give you an estimated car value without a subscription or email.",
    keywords: ["glasses guide car valuation free", "glass's guide alternative", "free car valuation alternative"],
    faq: [
      { q: "Can I get a Glass's Guide valuation for free?", a: "Glass's Guide is a paid trade tool. WorthCar is a free public alternative that uses MOT history data to give buyers and sellers an estimated car value." },
      { q: "Is WorthCar as accurate as Glass's Guide?", a: "WorthCar focuses on the specific vehicle's history rather than market pricing databases. For a private buyer, MOT-history-based estimated car value is often more useful than trade valuations." },
    ],
  },
  "dvla-car-value": {
    title: "DVLA Car Value Check by Registration | WorthCar UK",
    description: "Use DVLA-linked vehicle data to check any UK car's estimated value. MOT history, mileage trends, and price guidance by registration number.",
    h1: "DVLA Car Value — Estimated by Registration",
    intro: "WorthCar uses DVLA-linked public vehicle information to help you understand a car's estimated value. Enter a registration number to see MOT history, mileage records, and AI-generated estimated car value guidance — all from publicly available UK data.",
    keywords: ["dvla car value", "dvla vehicle check", "dvla car history"],
    faq: [
      { q: "Does DVLA provide car valuations?", a: "DVLA provides vehicle registration data but not valuations. WorthCar uses publicly available vehicle data — including DVLA-linked information — to generate an estimated car value." },
      { q: "Is this an official DVLA service?", a: "No. WorthCar is an independent service that uses public UK vehicle data to help buyers and sellers make better decisions." },
    ],
  },
  "car-valuation-uk-without-personal-details": {
    title: "Estimated Car Value UK Without Personal Details | WorthCar",
    description: "Get an estimated car value in the UK without giving any personal details. No email, no phone number, no sign-up. Just a registration number.",
    h1: "Estimated Car Value UK Without Personal Details",
    intro: "WorthCar never asks for personal details. No email address. No phone number. No account. Enter a UK registration number and get a full MOT history check and estimated car value — completely anonymously.",
    keywords: ["estimated car value uk without personal details", "free estimated car value without personal details", "anonymous car value uk"],
    faq: [
      { q: "Why do other valuation sites ask for my personal details?", a: "Many valuation sites collect your data to sell leads to dealers. WorthCar has no such model — your search is anonymous and your data is not sold." },
      { q: "Do I need to create an account?", a: "No. WorthCar requires no account, no email, and no personal information. Just enter the registration number." },
    ],
  },
};

const RELATED_LINKS = [
  { to: "/free-car-valuation-without-email", label: "Free estimated car value without email" },
  { to: "/value-my-car-by-registration-number", label: "Estimated car value by registration number" },
  { to: "/mot-check-uk", label: "MOT check UK" },
  { to: "/vehicle-history-check-uk", label: "Vehicle history check UK" },
  { to: "/aa-car-valuation-alternative", label: "AA car valuation alternative" },
];

export default function EditorialLanding() {
  const slug = window.location.pathname.replace(/^\//, "");
  const page = PAGES[slug];

  useSeo({
    title: page?.title || "WorthCar.co.uk | Free Estimated Car Value Without Email",
    description: page?.description || "Free estimated car value and MOT history check for any UK vehicle.",
    canonical: `https://worthcar.co.uk/${slug}`,
    robots: "index,follow",
    structuredData: page ? {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "WebPage",
          "@id": `https://worthcar.co.uk/${slug}`,
          "url": `https://worthcar.co.uk/${slug}`,
          "name": page.title,
          "description": page.description,
          "isPartOf": { "@id": "https://worthcar.co.uk/#website" },
        },
        {
          "@type": "FAQPage",
          "mainEntity": page.faq.map(f => ({
            "@type": "Question",
            "name": f.q,
            "acceptedAnswer": { "@type": "Answer", "text": f.a }
          }))
        }
      ]
    } : null,
  });

  if (!page) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <p className="text-slate-500">Page not found.</p>
      </div>
    );
  }

  const related = RELATED_LINKS.filter(l => !l.to.includes(slug)).slice(0, 4);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero — dark navy search panel */}
      <RegSearchBlock
        eyebrow="Free MOT history check"
        headline={page.h1}
        subheading={page.intro}
        showTrustSignals
      />

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 py-12 space-y-10">

        {/* How it works */}
        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-4">How WorthCar Works</h2>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { step: "1", title: "Enter Registration", desc: "Type any UK registration number — no email needed." },
              { step: "2", title: "We Check MOT Data", desc: "WorthCar pulls full MOT history, mileage records, and vehicle details from public UK data." },
              { step: "3", title: "Get Estimated Car Value", desc: "AI analyses the data and gives you a condition summary with private and dealer estimated value ranges." },
            ].map(s => (
              <div key={s.step} className="bg-slate-50 rounded-2xl p-5">
                <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-sm font-bold mb-3">{s.step}</div>
                <h3 className="font-semibold text-slate-900 mb-1">{s.title}</h3>
                <p className="text-sm text-slate-500">{s.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Why MOT affects value */}
        <section className="bg-amber-50 border border-amber-200 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-slate-900 mb-3">Why MOT History Affects Estimated Car Value</h2>
          <p className="text-sm text-slate-700 leading-relaxed">
            A car's MOT history is one of the most reliable indicators of its true condition. Repeated failures, recurring advisories,
            and inconsistent mileage are red flags that affect an estimated car value. WorthCar uses UK public data — including DVSA MOT history and
            DVLA-linked vehicle information — to turn raw facts into clear estimated car value guidance. This is data-driven, not a dealer estimate.
          </p>
        </section>

        {/* FAQ */}
        <section>
          <h2 className="text-xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {page.faq.map((f, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-2xl p-5">
                <h3 className="font-semibold text-slate-900 text-sm mb-2">{f.q}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section>
          <RegSearchBlock
            eyebrow="Ready to check?"
            headline="Get your free MOT history now"
            subheading="Free. No email. No sign-up. Just a registration number."
            showTrustSignals={false}
          />
        </section>

        {/* Internal links */}
        <section>
          <h2 className="text-base font-semibold text-slate-700 mb-3">Related Guides</h2>
          <div className="flex flex-wrap gap-2">
            {related.map(l => (
              <Link key={l.to} to={l.to} className="text-sm text-amber-700 hover:text-amber-900 underline">{l.label}</Link>
            ))}
            <Link to="/mot-check-uk" className="text-sm text-amber-700 hover:text-amber-900 underline">MOT check UK</Link>
          </div>
        </section>

        {/* Trust block */}
        <p className="text-xs text-slate-400 border-t border-slate-100 pt-6 leading-relaxed">
          WorthCar uses public UK vehicle information, including MOT-related data from DVSA and DVLA-linked vehicle records,
          to generate estimated car value guidance and condition signals. This is guidance only and not financial, legal, or mechanical advice.
          Always have a vehicle professionally inspected before purchase.
        </p>

        <Footer />
      </div>
    </div>
  );
}