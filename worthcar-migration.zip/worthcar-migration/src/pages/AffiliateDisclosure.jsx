import React from "react";
import LegalPage, { Callout } from "@/components/LegalPage";

export default function AffiliateDisclosure() {
  return (
    <LegalPage title="Affiliate Disclosure" subtitle="How partner links may support WorthCar">
      <div className="text-sm text-slate-600 leading-relaxed mb-6">
        <p>
          WorthCar may earn commissions or referral fees from selected partners or third-party services that are linked to or referenced on this site. These partnerships help support the ongoing development and operation of WorthCar.co.uk.
        </p>
      </div>
      <Callout>
        Affiliate relationships do not affect our analysis, the data we present, or how results are generated. Our vehicle insights are produced solely from available MOT and public data.
      </Callout>
    </LegalPage>
  );
}