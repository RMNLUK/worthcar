import React from "react";
import { Link } from "react-router-dom";
import LegalPage, { AccordionItem } from "@/components/LegalPage";

export default function PrivacyPolicy() {
  return (
    <LegalPage title="Privacy Policy" subtitle="How WorthCar handles your data" email="support@worthcar.co.uk">
      <AccordionItem title="What we collect">
        Vehicle registrations, IP address, device data, usage data, cookies, and contact details if provided.
      </AccordionItem>
      <AccordionItem title="How we use data">
        To operate the service, deliver results, improve performance, maintain security, and respond to enquiries.
      </AccordionItem>
      <AccordionItem title="Legal basis">
        Legitimate interest, consent, legal obligation, and contract where applicable.
      </AccordionItem>
      <AccordionItem title="Registration data">
        We do not identify or store vehicle owners.
      </AccordionItem>
      <AccordionItem title="Data sharing">
        We may share data with hosting, analytics, and infrastructure providers. We do not sell personal data.
      </AccordionItem>
      <AccordionItem title="Cookies">
        See our Cookie Policy for full details on how we use cookies.
      </AccordionItem>
      <AccordionItem title="Retention">
        Data is retained only as long as necessary for the purposes described above.
      </AccordionItem>
      <AccordionItem title="Security">
        We apply reasonable technical and organisational safeguards to protect your data.
      </AccordionItem>
      <AccordionItem title="Your rights">
        Under UK GDPR, you have the right to request access, correction, deletion, or restriction of your personal data. You may also object to processing and withdraw consent at any time.
      </AccordionItem>
      <AccordionItem title="Contact">
        To exercise your rights or ask about your data, <Link to="/Contact" className="text-amber-600 hover:underline">contact us</Link>.
      </AccordionItem>
    </LegalPage>
  );
}