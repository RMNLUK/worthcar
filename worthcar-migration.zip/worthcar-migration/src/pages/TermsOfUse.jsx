import React from "react";
import LegalPage, { AccordionItem, Callout } from "@/components/LegalPage";

export default function TermsOfUse() {
  return (
    <LegalPage title="Terms of Use" subtitle="The terms that apply when you use WorthCar" email="support@worthcar.co.uk">
      <AccordionItem title="Who we are">
        WorthCar is an online vehicle insight platform providing MOT history analysis, condition indicators, and estimated valuation guidance.
      </AccordionItem>
      <AccordionItem title="What the service does">
        WorthCar allows users to enter a UK vehicle registration and view MOT history, mileage trends, advisory patterns, condition signals, and estimated price ranges. All outputs are informational only.
      </AccordionItem>
      <AccordionItem title="Service limitations">
        <Callout>WorthCar does not inspect vehicles, verify physical condition, confirm ownership, or guarantee that a vehicle is safe, reliable, or worth buying.</Callout>
      </AccordionItem>
      <AccordionItem title="Data accuracy">
        We rely on third-party and public data sources. We do not guarantee that data is complete, accurate, or up to date.
      </AccordionItem>
      <AccordionItem title="Not professional advice">
        WorthCar does not provide legal, financial, mechanical, or insurance advice.
      </AccordionItem>
      <AccordionItem title="Your responsibility">
        You must carry out independent checks before making any vehicle decision.
      </AccordionItem>
      <AccordionItem title="Acceptable use">
        You agree not to misuse the platform, scrape data, automate access, or use the service unlawfully.
      </AccordionItem>
      <AccordionItem title="Liability">
        <Callout>WorthCar is not liable for any loss, damage, or decisions made based on the use of the site.</Callout>
      </AccordionItem>
      <AccordionItem title="Changes">
        We may update these terms at any time.
      </AccordionItem>
      <AccordionItem title="Governing law">
        These terms are governed by the laws of England and Wales.
      </AccordionItem>
    </LegalPage>
  );
}