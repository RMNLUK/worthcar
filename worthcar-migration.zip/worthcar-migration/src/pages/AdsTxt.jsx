import { useEffect } from "react";

export default function AdsTxt() {
  useEffect(() => {
    // Set content type hint via meta and render plain text
    document.title = "ads.txt";
  }, []);

  return (
    <pre style={{ fontFamily: "monospace", whiteSpace: "pre", margin: 0, padding: 0 }}>
      {"google.com, pub-7594093628749233, DIRECT, f08c47fec0942fa0"}
    </pre>
  );
}