import React, { useState } from "react";
import { Link } from "react-router-dom";
import useSeo from "@/lib/useSeo";
import { createPageUrl } from "@/utils";
import { insightsMockData } from "@/data/insightsMockData";

import RegistrationInput from "@/components/search/RegistrationInput";
import OcrVerificationModal from "@/components/search/OcrVerificationModal";
import Footer from "@/components/Footer";
import { extractRegistrationFromImage } from "@/components/analysis/analysisService";

const mp = insightsMockData.marketPulse;
const mot = insightsMockData.motIntelligence;

const FAILURE_BARS = [
  { label: "Lighting & signals", pct: 31, width: 82, color: "#E24B4A" },
  { label: "Tyres",              pct: 24, width: 64, color: "#E24B4A" },
  { label: "Brakes",             pct: 18, width: 48, color: "#EF9F27" },
  { label: "Suspension",         pct: 14, width: 37, color: "#EF9F27" },
  { label: "Emissions",          pct: 9,  width: 24, color: "#639922" },
];

const TRENDING = [
  { model: "Toyota Yaris Cross", brand: "Toyota", change: 41, checks: "2,100" },
  { model: "Ford Puma",          brand: "Ford",   change: 28, checks: "1,840" },
  { model: "Nissan Leaf",        brand: "Nissan", change: 22, checks: "1,560" },
];

const INSIGHT_CARDS = [
  { tag: "High demand", tagBg: "#FCEBEB", tagColor: "#A32D2D", title: "Is a VW Golf worth buying at 70,000 miles?", desc: "Based on 6,200 Golf checks", to: "/insights/buyer-guides" },
  { tag: "Trending",   tagBg: "#FAEEDA", tagColor: "#854F0B", title: "5 most reliable used cars under £10,000",    desc: "Ranked by pass rate score",    to: "/insights/buyer-guides" },
  { tag: "MOT data",   tagBg: "#E6F1FB", tagColor: "#185FA5", title: "What mileage to avoid on a diesel BMW",     desc: "DPF failures spike after 90k", to: "/insights/mot-intelligence" },
  { tag: "Low risk",   tagBg: "#EAF3DE", tagColor: "#3B6D11", title: "The used cars with the best MOT pass rates", desc: "Spring 2026 ranking",          to: "/insights/buyer-guides" },
];

const TRUST_SIGNALS = ["Free to use", "Instant results", "Full MOT history", "48,000+ checks this month"];

const currentMonthYear = new Date().toLocaleString("en-GB", { month: "long", year: "numeric" });

export default function Home() {
  useSeo({
    title: "Free Estimated Car Value Without Email | MOT Check UK | WorthCar",
    description: "Free estimated car value without email. Check MOT history, mileage trends, and get UK car price guidance in seconds. Powered by DVSA data.",
    canonical: "https://worthcar.co.uk/",
    robots: "index,follow",
  });

  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [ocrResult, setOcrResult] = useState(null);
  const [showOcrModal, setShowOcrModal] = useState(false);

  const handleManualSubmit = (registration) => {
    window.location.href = createPageUrl("Results") + `?reg=${encodeURIComponent(registration)}`;
  };

  const handlePhotoCapture = async (file) => {
    setIsProcessingOcr(true);
    const result = await extractRegistrationFromImage(file);
    setOcrResult(result);
    setShowOcrModal(true);
    setIsProcessingOcr(false);
  };

  const handleOcrConfirm = (registration, wasCorrected) => {
    setShowOcrModal(false);
    const params = new URLSearchParams({
      reg: registration, method: "ocr",
      corrected: wasCorrected ? "1" : "0",
      original: ocrResult?.raw_text || "",
    });
    window.location.href = createPageUrl("Results") + `?${params.toString()}`;
  };

  const handleRescan = () => { setShowOcrModal(false); setOcrResult(null); };

  return (
    <div className="min-h-screen bg-white">

      {/* ── 2. HERO ─────────────────────────────────────────────── */}
      <div className="w-full border-b border-slate-100">
        <div className="max-w-3xl mx-auto px-4 pt-14 pb-7 text-center">
          {/* Eyebrow */}
          <p className="text-xs font-medium uppercase tracking-widest mb-3.5 text-slate-400" style={{ letterSpacing: "0.06em" }}>
            Free MOT history check
          </p>
          {/* Headline */}
          <h1 className="font-medium text-slate-900 leading-snug mb-2.5 md:text-3xl text-2xl" style={{ lineHeight: 1.3 }}>
            Is this car worth buying?<br />Find out in seconds.
          </h1>
          {/* Subheading */}
          <p className="text-sm mb-7 text-slate-500" style={{ lineHeight: 1.6 }}>
            Enter Reg, Full MOT, Mileage, Estimate Value and Compare Cars... Cool!
          </p>

          {/* Reg Search */}
          <div className="max-w-xl mx-auto">
            <RegistrationInput
              onSubmit={handleManualSubmit}
              onPhotoCapture={handlePhotoCapture}
              isLoading={isProcessingOcr}
            />
          </div>

          {isProcessingOcr && (
            <p className="text-xs mt-3 text-slate-400">Reading number plate…</p>
          )}

          {/* Trust signals */}
          <div className="flex flex-wrap justify-center gap-x-4 gap-y-1.5 mt-5 pb-7">
            {TRUST_SIGNALS.map((t) => (
              <span key={t} className="flex items-center gap-1.5 text-xs text-slate-400">
                <span className="inline-block w-1.5 h-1.5 rounded-full flex-shrink-0 bg-slate-300" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ── 3. MARKET PULSE STRIP ───────────────────────────────── */}
      <div className="w-full border-b border-slate-100 bg-slate-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest mb-2.5 text-slate-400" style={{ letterSpacing: "0.06em" }}>
              Market pulse — {currentMonthYear}
            </p>
            <div className="flex flex-wrap">
              {[
                { value: mp.summaryStats.mostSearchedBrand.value, label: "Most searched" },
                { value: mp.summaryStats.mostPopularYear.value,   label: "Top plate year" },
                { value: "64k mi",                               label: "Avg mileage" },
                { value: mot.summaryStats.overallPassRate.value,  label: "MOT pass rate" },
              ].map((stat, i) => (
                <div key={i} className="flex items-stretch">
                  {i > 0 && <div className="self-stretch w-px mx-5 my-0.5 bg-slate-200" />}
                  <div>
                    <p className="text-base font-medium text-slate-900 leading-tight" style={{ fontSize: 17 }}>{stat.value}</p>
                    <p className="text-xs mt-0.5 text-slate-400" style={{ fontSize: 11 }}>{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <Link to="/insights/market-pulse" className="text-xs flex-shrink-0 self-center text-blue-600">
            See full insights ›
          </Link>
        </div>
      </div>

      {/* ── 4. MAIN CONTENT ─────────────────────────────────────── */}
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">

        {/* 4a. HOW IT WORKS */}
        <div>
          <p className="text-xs font-medium uppercase tracking-widest mb-3" style={{ color: "#94A3B8", letterSpacing: "0.06em" }}>
            How WorthCar works
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {[
              { n: "1", title: "Enter the reg plate",  desc: "Any UK registration — takes 2 seconds to type in." },
              { n: "2", title: "We check the history", desc: "Full MOT record, mileage timeline, advisories and failures." },
              { n: "3", title: "Buy with confidence",  desc: "Know the real story before you hand over your money." },
            ].map((s) => (
              <div key={s.n} className="bg-white border p-4 rounded-lg" style={{ borderColor: "#E2E8F0", borderWidth: "0.5px" }}>
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium mb-2.5 flex-shrink-0" style={{ background: "#E6F1FB", color: "#185FA5" }}>
                  {s.n}
                </div>
                <p className="text-sm font-medium text-slate-900 mb-1">{s.title}</p>
                <p className="text-xs text-slate-500 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 4b. MOT FAILURES */}
        <div>
          <p className="text-xs font-medium uppercase tracking-widest mb-3" style={{ color: "#94A3B8", letterSpacing: "0.06em" }}>
            Most common MOT failures this month
          </p>
          <div className="bg-white border rounded-lg p-4" style={{ borderColor: "#E2E8F0", borderWidth: "0.5px" }}>
            <div className="space-y-3">
              {FAILURE_BARS.map((f) => (
                <div key={f.label} className="flex items-center gap-3">
                  <span className="text-xs text-slate-500 flex-shrink-0" style={{ minWidth: 110 }}>{f.label}</span>
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "#F1F5F9" }}>
                    <div className="h-full rounded-full" style={{ width: `${f.width}%`, background: f.color }} />
                  </div>
                  <span className="text-xs text-slate-400 text-right" style={{ minWidth: 28 }}>{f.pct}%</span>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-slate-100">
              <span className="text-xs text-slate-400" style={{ fontSize: 11 }}>From 48,200 vehicle checks — {currentMonthYear}</span>
              <Link to="/insights/mot-intelligence" className="text-xs font-medium" style={{ color: "#2563EB", fontSize: 12 }}>Full MOT intelligence ›</Link>
            </div>
          </div>
        </div>

        {/* 4c. TRENDING SEARCHES */}
        <div>
          <p className="text-xs font-medium uppercase tracking-widest mb-3" style={{ color: "#94A3B8", letterSpacing: "0.06em" }}>
            Trending searches this week
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {TRENDING.map((t) => (
              <div key={t.model} className="bg-white border p-4 rounded-lg" style={{ borderColor: "#E2E8F0", borderWidth: "0.5px" }}>
                <p className="text-sm font-medium text-slate-900">{t.model}</p>
                <p className="text-xs text-slate-400 mt-0.5 mb-2" style={{ fontSize: 11 }}>{t.brand}</p>
                <p className="text-xs font-medium" style={{ color: "#3B6D11", fontSize: 11 }}>↑ +{t.change}% this week</p>
                <p className="text-xs text-slate-400 mt-1" style={{ fontSize: 11 }}>{t.checks} checks</p>
              </div>
            ))}
          </div>
        </div>

        {/* 4d. FROM THE INSIGHTS HUB */}
        <div>
          <p className="text-xs font-medium uppercase tracking-widest mb-3" style={{ color: "#94A3B8", letterSpacing: "0.06em" }}>
            From the insights hub
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {INSIGHT_CARDS.map((c) => (
              <Link key={c.title} to={c.to} className="bg-white border p-4 rounded-lg cursor-pointer hover:border-slate-300 transition-colors block" style={{ borderColor: "#E2E8F0", borderWidth: "0.5px" }}>
                <div className="flex items-start justify-between mb-2">
                  <span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium" style={{ background: c.tagBg, color: c.tagColor, fontSize: 11 }}>
                    {c.tag}
                  </span>
                  <span className="text-sm text-slate-400 ml-2 mt-0.5">›</span>
                </div>
                <p className="text-sm font-medium text-slate-900 leading-snug mb-1">{c.title}</p>
                <p className="text-xs text-slate-400" style={{ fontSize: 11 }}>{c.desc}</p>
              </Link>
            ))}
          </div>
        </div>

        {/* SEO internal links */}
        <div className="pt-4 border-t border-slate-100">
          <p className="text-xs text-slate-400 mb-3 font-medium uppercase tracking-wide">Popular Guides</p>
          <div className="flex flex-wrap gap-3">
            {[
              { to: "/free-car-valuation-without-email",             label: "Free estimated car value without email" },
              { to: "/mot-check-uk",                                  label: "MOT check UK" },
              { to: "/value-my-car-by-registration-number",           label: "Value my car by registration" },
              { to: "/vehicle-history-check-uk",                      label: "Vehicle history check UK" },
              { to: "/aa-car-valuation-alternative",                  label: "AA car valuation alternative" },
              { to: "/glasses-guide-car-valuation-free-alternative",  label: "Glass's Guide alternative" },
            ].map(l => (
              <Link key={l.to} to={l.to} className="text-xs text-slate-500 hover:text-amber-600 underline transition-colors">{l.label}</Link>
            ))}
          </div>
        </div>

        <Footer />
      </div>

      {/* OCR Modal */}
      <OcrVerificationModal
        open={showOcrModal}
        onClose={() => setShowOcrModal(false)}
        extractedText={ocrResult?.registration || ""}
        confidence={ocrResult?.confidence ?? null}
        onConfirm={handleOcrConfirm}
        onRescan={handleRescan}
        isLoading={false}
      />
    </div>
  );
}