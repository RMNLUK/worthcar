import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import MotMasterPromptModule from "@/components/admin/MotMasterPromptModule";
import SeoModule from "@/components/admin/SeoModule";
import {
  Car, Lock, ShieldCheck, Eye, EyeOff,
  SlidersHorizontal, BarChart2, Share2, UserPlus, LogOut, Menu, Mail,
  LayoutDashboard, Settings, Trash2, Plus, Save, Search, Download
} from "lucide-react";

// ─── Step 1: Login ────────────────────────────────────────────────────────────
function LoginStep({ onSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await base44.functions.invoke('sendAdminOtp', { email, password });
    setLoading(false);
    if (res.data?.success) {
      onSuccess(email);
    } else {
      setError(res.data?.error || 'Something went wrong. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 w-full max-w-sm">
        <div className="text-center mb-7">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7 text-amber-400" />
          </div>
          <h1 className="text-xl font-bold text-slate-900">Admin Login</h1>
          <p className="text-sm text-slate-500 mt-1">Sign in to access the dashboard</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Email Address</label>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)}
              placeholder="admin@example.com"
              className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Password</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} required value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full border border-slate-200 rounded-xl px-4 py-2.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          {error && <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</p>}
          <button type="submit" disabled={loading}
            className="w-full py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors disabled:opacity-50">
            {loading ? 'Sending verification code…' : 'Continue'}
          </button>
        </form>
        <Link to="/" className="mt-6 block text-center text-xs text-slate-400 hover:text-amber-600 transition-colors">← Back to WorthCar</Link>
      </div>
    </div>
  );
}

// ─── Step 2: OTP ──────────────────────────────────────────────────────────────
function OtpStep({ email, onSuccess, onBack }) {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleVerify = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    const res = await base44.functions.invoke('verifyAdminOtp', { email, code });
    setLoading(false);
    if (res.data?.success) {
      onSuccess();
    } else {
      setError(res.data?.error || 'Invalid code. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 w-full max-w-sm">
        <div className="text-center mb-7">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-7 h-7 text-amber-400" />
          </div>
          <h1 className="text-xl font-bold text-slate-900">Check your email</h1>
          <p className="text-sm text-slate-500 mt-1">We sent a 6-digit code to<br /><span className="font-semibold text-slate-700">{email}</span></p>
        </div>
        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Verification Code</label>
            <input type="text" inputMode="numeric" maxLength={6} required value={code}
              onChange={e => setCode(e.target.value.replace(/\D/g, ''))}
              placeholder="000000"
              className="w-full text-center text-2xl font-bold tracking-[0.4em] border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-amber-400" />
          </div>
          {error && <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</p>}
          <button type="submit" disabled={loading || code.length !== 6}
            className="w-full py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors disabled:opacity-50">
            {loading ? 'Verifying…' : 'Verify & Enter Dashboard'}
          </button>
        </form>
        <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
          <button onClick={onBack} className="hover:text-amber-600 transition-colors">← Back</button>
          <span>Expires in 10 minutes</span>
        </div>
      </div>
    </div>
  );
}

// ─── Overview Module ──────────────────────────────────────────────────────────
function OverviewModule() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.VehicleSearch.list('-created_date', 500),
      base44.entities.ContactEnquiry.list('-created_date', 100),
    ]).then(([searches, enquiries]) => {
      const today = new Date().toDateString();
      const todaySearches = searches.filter(s => new Date(s.created_date).toDateString() === today);
      const successRate = searches.length ? Math.round(searches.filter(s => s.status === 'success').length / searches.length * 100) : 0;
      setStats({
        totalSearches: searches.length,
        todaySearches: todaySearches.length,
        successRate,
        totalEnquiries: enquiries.length,
        unreadEnquiries: enquiries.filter(e => !e.email_sent).length,
      });
      setLoading(false);
    });
  }, []);

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>;

  const cards = [
    { label: 'Total Searches', value: stats.totalSearches, sub: `${stats.todaySearches} today`, color: 'bg-amber-50 border-amber-200' },
    { label: 'Success Rate', value: `${stats.successRate}%`, sub: 'MOT lookups', color: 'bg-emerald-50 border-emerald-200' },
    { label: 'Total Enquiries', value: stats.totalEnquiries, sub: `${stats.unreadEnquiries} unread`, color: 'bg-blue-50 border-blue-200' },
  ];

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">Overview</h2>
      <p className="text-sm text-slate-500 mb-6">WorthCar.co.uk at a glance.</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {cards.map(c => (
          <div key={c.label} className={`rounded-2xl border p-5 ${c.color}`}>
            <p className="text-xs font-semibold text-slate-500 mb-1">{c.label}</p>
            <p className="text-4xl font-extrabold text-slate-900">{c.value}</p>
            <p className="text-xs text-slate-400 mt-1">{c.sub}</p>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-2xl border border-slate-200 p-5">
        <p className="text-sm font-semibold text-slate-700 mb-3">Quick Links</p>
        <div className="flex flex-wrap gap-2">
          {[
            { label: '← Back to Site', to: '/' },
            { label: 'Contact Page', to: '/Contact' },
            { label: 'Compare Page', to: '/compare' },
          ].map(l => (
            <Link key={l.to} to={l.to} className="text-xs px-3 py-1.5 bg-slate-100 hover:bg-amber-100 text-slate-700 rounded-lg font-medium transition-colors">{l.label}</Link>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Analytics Module ─────────────────────────────────────────────────────────
function AnalyticsModule() {
  const [searches, setSearches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.VehicleSearch.list('-created_date', 200).then(data => {
      setSearches(data);
      setLoading(false);
    });
  }, []);

  const total = searches.length;
  const success = searches.filter(s => s.status === 'success').length;
  const errors = searches.filter(s => s.status?.startsWith('error')).length;
  const ocr = searches.filter(s => s.input_method === 'ocr').length;
  const recent = searches.slice(0, 10);

  const stat = (label, value, sub) => (
    <div className="bg-white rounded-2xl border border-slate-200 p-5">
      <p className="text-xs text-slate-500 font-medium mb-1">{label}</p>
      <p className="text-3xl font-extrabold text-slate-900">{value}</p>
      {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
    </div>
  );

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">Analytics</h2>
      <p className="text-sm text-slate-500 mb-6">Vehicle search activity across WorthCar.</p>
      {loading ? (
        <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {stat("Total Searches", total)}
            {stat("Successful", success, `${total ? Math.round(success/total*100) : 0}% success rate`)}
            {stat("Errors", errors)}
            {stat("Via Camera OCR", ocr, `${total ? Math.round(ocr/total*100) : 0}% of searches`)}
          </div>
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-800">Recent Searches</p>
            </div>
            <div className="divide-y divide-slate-100">
              {recent.length === 0 && <p className="text-sm text-slate-400 px-5 py-6 text-center">No searches yet.</p>}
              {recent.map(s => (
                <div key={s.id} className="px-5 py-3 flex items-center justify-between text-sm">
                  <div>
                    <span className="font-mono font-semibold text-slate-800">{s.registration}</span>
                    {s.vehicle_make && <span className="text-slate-400 ml-2">{s.vehicle_make} {s.vehicle_model}</span>}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.status === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'}`}>
                      {s.status}
                    </span>
                    <span className="text-xs text-slate-400">{new Date(s.created_date).toLocaleDateString('en-GB')}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Social Content Module ────────────────────────────────────────────────────
function SocialModule() {
  const [topic, setTopic] = useState('');
  const [platform, setPlatform] = useState('twitter');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const generate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setResult('');
    const platformLabels = { twitter: 'Twitter/X (max 280 chars)', linkedin: 'LinkedIn (professional tone)', facebook: 'Facebook (friendly, engaging)' };
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a social media post for ${platformLabels[platform]} about: "${topic}". 
      The brand is WorthCar.co.uk — a free UK vehicle MOT history and AI valuation tool.
      Tone: confident, helpful, British. Include relevant hashtags. Return only the post text, no explanation.`
    });
    setResult(res);
    setLoading(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">Social Content</h2>
      <p className="text-sm text-slate-500 mb-6">Generate AI-written social media posts for WorthCar.</p>
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1.5">Platform</label>
          <div className="flex gap-2">
            {['twitter', 'linkedin', 'facebook'].map(p => (
              <button key={p} onClick={() => setPlatform(p)}
                className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors ${platform === p ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>
                {p === 'twitter' ? 'Twitter / X' : p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1.5">Topic / Idea</label>
          <input type="text" value={topic} onChange={e => setTopic(e.target.value)}
            placeholder="e.g. Why checking MOT history before buying a used car is essential"
            className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
        </div>
        <button onClick={generate} disabled={loading || !topic.trim()}
          className="px-5 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors disabled:opacity-50">
          {loading ? 'Generating…' : 'Generate Post'}
        </button>
        {result && (
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-slate-600">Generated Post</p>
              <button onClick={copy} className="text-xs text-amber-600 hover:underline font-medium">{copied ? 'Copied!' : 'Copy'}</button>
            </div>
            <textarea value={result} onChange={e => setResult(e.target.value)} rows={6}
              className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-700 bg-slate-50 resize-none focus:outline-none focus:ring-2 focus:ring-amber-400" />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── App Config Module ───────────────────────────────────────────────────────
function AppConfigModule() {
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [newItem, setNewItem] = useState({ key: '', value: '', description: '' });
  const [showNew, setShowNew] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = () => base44.entities.AppConfig.list('key', 100).then(d => { setConfigs(d); setLoading(false); });
  useEffect(() => { load(); }, []);

  const save = async (item) => {
    setSaving(true);
    await base44.entities.AppConfig.update(item.id, { value: item.value, description: item.description });
    setEditing(null);
    setSaving(false);
    load();
  };

  const create = async () => {
    if (!newItem.key || !newItem.value) return;
    setSaving(true);
    await base44.entities.AppConfig.create(newItem);
    setNewItem({ key: '', value: '', description: '' });
    setShowNew(false);
    setSaving(false);
    load();
  };

  const remove = async (id) => {
    await base44.entities.AppConfig.delete(id);
    load();
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">App Config</h2>
      <p className="text-sm text-slate-500 mb-6">Manage site-wide configuration settings.</p>
      {loading ? <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div> : (
        <div className="space-y-3">
          {configs.map(c => (
            <div key={c.id} className="bg-white rounded-2xl border border-slate-200 p-4">
              {editing?.id === c.id ? (
                <div className="space-y-2">
                  <p className="text-xs font-mono font-bold text-slate-500">{c.key}</p>
                  <textarea rows={2} value={editing.value} onChange={e => setEditing({...editing, value: e.target.value})}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none" />
                  <input value={editing.description || ''} onChange={e => setEditing({...editing, description: e.target.value})}
                    placeholder="Description (optional)"
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
                  <div className="flex gap-2">
                    <button onClick={() => save(editing)} disabled={saving}
                      className="flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-lg">
                      <Save className="w-3 h-3" /> {saving ? 'Saving…' : 'Save'}
                    </button>
                    <button onClick={() => setEditing(null)} className="px-4 py-1.5 text-xs text-slate-500 hover:text-slate-700">Cancel</button>
                  </div>
                </div>
              ) : (
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-mono font-bold text-amber-600">{c.key}</p>
                    <p className="text-sm text-slate-800 mt-0.5 break-all">{c.value}</p>
                    {c.description && <p className="text-xs text-slate-400 mt-0.5">{c.description}</p>}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <button onClick={() => setEditing({...c})} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700">
                      <Save className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => remove(c.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}

          {showNew ? (
            <div className="bg-white rounded-2xl border border-amber-200 p-4 space-y-2">
              <p className="text-xs font-semibold text-slate-600">New Config Item</p>
              <input value={newItem.key} onChange={e => setNewItem({...newItem, key: e.target.value})} placeholder="Key (e.g. site_tagline)"
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-400" />
              <input value={newItem.value} onChange={e => setNewItem({...newItem, value: e.target.value})} placeholder="Value"
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
              <input value={newItem.description} onChange={e => setNewItem({...newItem, description: e.target.value})} placeholder="Description (optional)"
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
              <div className="flex gap-2">
                <button onClick={create} disabled={saving || !newItem.key || !newItem.value}
                  className="flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-lg disabled:opacity-50">
                  <Plus className="w-3 h-3" /> {saving ? 'Adding…' : 'Add'}
                </button>
                <button onClick={() => setShowNew(false)} className="px-4 py-1.5 text-xs text-slate-500 hover:text-slate-700">Cancel</button>
              </div>
            </div>
          ) : (
            <button onClick={() => setShowNew(true)}
              className="flex items-center gap-2 w-full px-4 py-3 rounded-2xl border border-dashed border-slate-300 text-sm text-slate-400 hover:text-slate-700 hover:border-slate-400 transition-colors">
              <Plus className="w-4 h-4" /> Add Config Item
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Enquiries Module ────────────────────────────────────────────────────────
function EnquiriesModule() {
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(new Set());

  useEffect(() => {
    base44.entities.ContactEnquiry.list('-created_date', 100).then(data => {
      setEnquiries(data);
      setLoading(false);
    });
  }, []);

  const downloadAsCSV = () => {
    if (enquiries.length === 0) return;
    const headers = ['Full Name', 'Email', 'Phone', 'Message', 'Date', 'Email Sent'];
    const rows = enquiries.map(e => [
      e.full_name,
      e.email,
      e.phone,
      `"${e.message.replace(/"/g, '\\"')}"`,
      new Date(e.created_date).toLocaleString('en-GB'),
      e.email_sent ? 'Yes' : 'No'
    ]);
    const csv = [headers, ...rows].map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `enquiries-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const toggleSelect = (id) => {
    const newSelected = new Set(selected);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelected(newSelected);
  };

  const toggleSelectAll = () => {
    if (selected.size === enquiries.length) setSelected(new Set());
    else setSelected(new Set(enquiries.map(e => e.id)));
  };

  const deleteEnquiry = async (id) => {
    await base44.entities.ContactEnquiry.delete(id);
    setEnquiries(enquiries.filter(e => e.id !== id));
    setSelected(new Set([...selected].filter(s => s !== id)));
  };

  const deleteBulk = async () => {
    if (!confirm(`Delete ${selected.size} enquir${selected.size === 1 ? 'y' : 'ies'}?`)) return;
    await Promise.all([...selected].map(id => base44.entities.ContactEnquiry.delete(id)));
    setEnquiries(enquiries.filter(e => !selected.has(e.id)));
    setSelected(new Set());
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 mb-1">Contact Enquiries</h2>
          <p className="text-sm text-slate-500">Form submissions from WorthCar.co.uk/Contact.</p>
        </div>
        <div className="flex items-center gap-2">
          {selected.size > 0 && (
            <button
              onClick={deleteBulk}
              className="flex items-center gap-2 px-4 py-2.5 bg-red-600 text-white text-sm font-semibold rounded-xl hover:bg-red-700 transition-colors"
            >
              <Trash2 className="w-4 h-4" /> Delete {selected.size}
            </button>
          )}
          {enquiries.length > 0 && (
            <button
              onClick={downloadAsCSV}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors"
            >
              <Download className="w-4 h-4" /> Download CSV
            </button>
          )}
        </div>
      </div>
      {loading ? (
        <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {enquiries.length === 0 && <p className="text-sm text-slate-400 px-5 py-8 text-center">No enquiries yet.</p>}
          <div className="divide-y divide-slate-100">
            {enquiries.map(e => (
              <div key={e.id} className="px-5 py-4 space-y-1 flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={selected.has(e.id)}
                  onChange={() => toggleSelect(e.id)}
                  className="mt-1 w-4 h-4 rounded border border-slate-300 cursor-pointer accent-amber-500"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-slate-900 text-sm">{e.full_name}</p>
                    <span className="text-xs text-slate-400">{new Date(e.created_date).toLocaleString('en-GB')}</span>
                  </div>
                  <p className="text-xs text-slate-500">{e.email} · {e.phone}</p>
                  <p className="text-sm text-slate-700 bg-slate-50 rounded-lg px-3 py-2 mt-1">{e.message}</p>
                  {e.email_sent && <span className="text-xs text-emerald-600 font-medium">✓ Email sent</span>}
                </div>
                <button
                  onClick={() => deleteEnquiry(e.id)}
                  className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 flex-shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Register Users Module ────────────────────────────────────────────────────
function UsersModule() {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('user');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleInvite = async (e) => {
    e.preventDefault();
    setLoading(true); setSuccess(''); setError('');
    await base44.users.inviteUser(email, role);
    setLoading(false);
    setSuccess(`Invitation sent to ${email}`);
    setEmail('');
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">Register Users</h2>
      <p className="text-sm text-slate-500 mb-6">Invite new users to access WorthCar.</p>
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-md">
        <form onSubmit={handleInvite} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Email Address</label>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)}
              placeholder="user@example.com"
              className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400" />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Role</label>
            <select value={role} onChange={e => setRole(e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 bg-white">
              <option value="user">User — standard access</option>
              <option value="admin">Admin — full dashboard access</option>
            </select>
          </div>
          {success && <p className="text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2">{success}</p>}
          {error && <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</p>}
          <button type="submit" disabled={loading}
            className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors disabled:opacity-50">
            <UserPlus className="w-4 h-4" />
            {loading ? 'Sending…' : 'Send Invitation'}
          </button>
        </form>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'analytics', label: 'Analytics', icon: BarChart2 },
  { id: 'enquiries', label: 'Contact Enquiries', icon: Mail },
  { id: 'seo', label: 'SEO Management', icon: Search },
  { id: 'config', label: 'App Config', icon: Settings },
  { id: 'prompt', label: 'MOT AI Prompt', icon: SlidersHorizontal },
  { id: 'social', label: 'Social Content', icon: Share2 },
  { id: 'users', label: 'Register Users', icon: UserPlus },
];

function Sidebar({ active, onSelect, email, onLogout, open, onClose }) {
  return (
    <>
      {open && <div className="fixed inset-0 bg-black/40 z-20 md:hidden" onClick={onClose} />}
      <aside className={`fixed md:static inset-y-0 left-0 z-30 w-60 bg-slate-900 flex flex-col transition-transform duration-200 ${open ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="px-5 py-5 border-b border-slate-800">
          <Link to="/" className="flex items-center gap-2">
            <img
              src="/wclogo.png"
              alt="WorthCar logo"
              className="w-8 h-8 object-contain rounded-lg"
            />
            <span className="font-bold text-sm text-white">WorthCar</span>
          </Link>
          <p className="text-xs text-slate-500 mt-2 truncate">{email}</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => { onSelect(id); onClose(); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors text-left ${active === id ? 'bg-amber-400 text-slate-900' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </button>
          ))}
        </nav>
        <div className="px-3 py-4 border-t border-slate-800">
          <button onClick={onLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-white transition-colors">
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
      </aside>
    </>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function AdminDashboard() {
  const [step, setStep] = useState('login');
  const [adminEmail, setAdminEmail] = useState('');
  const [activeModule, setActiveModule] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (step === 'login') return <LoginStep onSuccess={email => { setAdminEmail(email); setStep('otp'); }} />;
  if (step === 'otp') return <OtpStep email={adminEmail} onSuccess={() => setStep('dashboard')} onBack={() => setStep('login')} />;

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar
        active={activeModule}
        onSelect={setActiveModule}
        email={adminEmail}
        onLogout={() => setStep('login')}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-slate-100 px-5 py-4 flex items-center gap-4 md:justify-end justify-between">
          <button className="md:hidden text-slate-500" onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>
          <span className="text-sm text-slate-500">
            {NAV.find(n => n.id === activeModule)?.label}
          </span>
        </header>
        <main className="flex-1 overflow-y-auto px-6 py-8 max-w-4xl w-full mx-auto">
          {activeModule === 'overview' && <OverviewModule />}
          {activeModule === 'analytics' && <AnalyticsModule />}
          {activeModule === 'enquiries' && <EnquiriesModule />}
          {activeModule === 'seo' && <SeoModule />}
          {activeModule === 'config' && <AppConfigModule />}
          {activeModule === 'prompt' && <MotMasterPromptModule />}
          {activeModule === 'social' && <SocialModule />}
          {activeModule === 'users' && <UsersModule />}
        </main>
      </div>
    </div>
  );
}