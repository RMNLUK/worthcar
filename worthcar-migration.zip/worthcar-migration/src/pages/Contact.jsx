import React, { useState } from "react";
import LegalPage from "@/components/LegalPage";
import { base44 } from "@/api/base44Client";
import { Mail, User, Phone, CheckCircle, Loader2 } from "lucide-react";

function Field({ icon: Icon, label, type, placeholder, maxLength, value, onChange, error }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-1.5">
        {label} <span className="text-amber-500">*</span>
      </label>
      <div className="relative">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
          <Icon className="w-4 h-4" />
        </div>
        <input
          type={type || "text"}
          placeholder={placeholder}
          maxLength={maxLength}
          value={value}
          onChange={onChange}
          className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm bg-white transition-colors focus:outline-none focus:ring-2 focus:ring-amber-400 ${error ? "border-red-400" : "border-slate-200 hover:border-slate-300"}`}
        />
      </div>
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  );
}

export default function Contact() {
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", message: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [sendError, setSendError] = useState("");

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const validate = () => {
    const e = {};
    if (!form.fullName.trim()) e.fullName = "Full name is required.";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "A valid email is required.";
    if (!form.phone.trim() || !/^(\+44|0)[0-9]{9,10}$/.test(form.phone.replace(/\s/g, ""))) e.phone = "A valid UK phone number is required.";
    if (!form.message.trim()) e.message = "Message is required.";
    if (form.message.length > 100) e.message = "Message must be 100 characters or less.";
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    setSendError("");
    try {
      const res = await base44.functions.invoke('sendContactEmail', {
        full_name: form.fullName,
        email: form.email,
        phone: form.phone,
        message: form.message,
      });
      if (res.data?.error) throw new Error(res.data.error);
    } catch (err) {
      setSendError(err?.message || "Failed to send. Please try again.");
      setLoading(false);
      return;
    }
    setLoading(false);
    setSubmitted(true);
  };

  return (
    <LegalPage title="Contact Us" subtitle="We'd love to hear from you">
      <div className="max-w-lg mx-auto">
        {sendError && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">
            <strong>Error:</strong> {sendError}
          </div>
        )}
        {submitted ? (
          <div className="space-y-4">
            <div className="bg-green-50 border border-green-200 rounded-2xl p-5 text-center">
              <p className="text-green-600 font-semibold text-sm leading-relaxed">
                Thank you for your enquiry.<br />
                Your message has been received. Our team will review and respond shortly.<br /><br />
                Due to high demand, response times may be slightly longer than usual. We appreciate your patience.
              </p>
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-3">
              <h3 className="font-bold text-slate-900 text-base mb-1">Message Receipt</h3>
              <div className="text-sm text-slate-600 space-y-2">
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="font-medium text-slate-500">Full Name</span>
                  <span className="text-slate-900">{form.fullName}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="font-medium text-slate-500">Email</span>
                  <span className="text-slate-900">{form.email}</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="font-medium text-slate-500">Phone</span>
                  <span className="text-slate-900">{form.phone}</span>
                </div>
                <div className="pt-1">
                  <span className="font-medium text-slate-500 block mb-1">Message</span>
                  <p className="text-slate-900 bg-slate-50 rounded-xl p-3 text-sm">{form.message}</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="bg-white border border-slate-200 rounded-2xl shadow-sm p-8 space-y-5">
            <div className="mb-2">
              <h2 className="text-lg font-bold text-slate-900">Get in Touch</h2>
              <p className="text-sm text-slate-500 mt-0.5">All fields are required.</p>
            </div>

            <Field icon={User} label="Full Name" placeholder="John Smith" value={form.fullName} onChange={set("fullName")} error={errors.fullName} />
            <Field icon={Mail} label="Contact Email" type="email" placeholder="john@example.com" value={form.email} onChange={set("email")} error={errors.email} />
            <Field icon={Phone} label="UK Phone Number" type="tel" placeholder="07700 900000" value={form.phone} onChange={set("phone")} error={errors.phone} />

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                Message <span className="text-amber-500">*</span>
              </label>
              <div className="relative">
                <textarea
                  placeholder="Type your message here..."
                  maxLength={100}
                  rows={4}
                  value={form.message}
                  onChange={set("message")}
                  className={`w-full px-4 py-3 rounded-xl border text-sm bg-white resize-none transition-colors focus:outline-none focus:ring-2 focus:ring-amber-400 ${errors.message ? "border-red-400" : "border-slate-200 hover:border-slate-300"}`}
                />
                <span className="absolute bottom-2.5 right-3 text-xs text-slate-400">{form.message.length}/100</span>
              </div>
              {errors.message && <p className="mt-1 text-xs text-red-500">{errors.message}</p>}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-3 rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
            >
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Sending...</> : "Send Message"}
            </button>
          </form>
        )}
      </div>
    </LegalPage>
  );
}