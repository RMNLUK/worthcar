import React from "react";
import LegalPage, { Callout } from "@/components/LegalPage";

function Section({ title, children }) {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-bold text-slate-900 mb-2">{title}</h2>
      <div className="text-sm text-slate-600 leading-relaxed">{children}</div>
    </div>
  );
}

export default function Disclaimer() {
  return (
    <LegalPage title="Disclaimer" subtitle="Important limitations of the WorthCar service" email="support@worthcar.co.uk">
      <Callout>WorthCar provides automated insights based on available data. It does not inspect vehicles or guarantee accuracy.</Callout>

      <Section title="Nature of service">
        WorthCar provides informational vehicle insights only. All outputs are generated from available public data and automated analysis.
      </Section>
      <Section title="No inspection">
        We do not physically inspect vehicles, verify seller identity, or confirm the actual condition of any vehicle.
      </Section>
      <Section title="Automated outputs">
        WorthCar uses automated logic and AI-assisted analysis to generate summaries and signals. These are generated programmatically and may not reflect the true condition of a vehicle.
      </Section>
      <Section title="Example outputs">
        <p className="mb-2">WorthCar may produce outputs such as:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Good buy</li>
          <li>Risky vehicle</li>
          <li>Fair value</li>
        </ul>
        <p className="mt-2">These are opinions derived from data, not professional assessments or statements of fact.</p>
      </Section>
      <Section title="Your responsibility">
        You must carry out independent checks — including a physical inspection, HPI check, finance check, and verification of the seller — before making any vehicle purchasing decision.
      </Section>

      <Callout>WorthCar is not responsible for any decisions or losses arising from use of the site.</Callout>
    </LegalPage>
  );
}