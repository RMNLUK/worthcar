import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Plus, X, BarChart2, Loader2, CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { runMotAnalysis } from "@/components/analysis/analysisService";
import { createPageUrl } from "@/utils";
import Footer from "@/components/Footer";
import CompareVehicleColumn from "@/components/compare/CompareVehicleColumn";

export default function Compare() {
  const [pastSearches, setPastSearches] = useState([]);
  const [selectedRegs, setSelectedRegs] = useState([]);
  const [results, setResults] = useState({});
  const [loadingRegs, setLoadingRegs] = useState({});
  const [comparing, setComparing] = useState(false);

  useEffect(() => {
    base44.entities.VehicleSearch.filter({ status: "success" }, "-created_date", 50).then((searches) => {
      // Deduplicate by registration
      const seen = new Set();
      const unique = searches.filter((s) => {
        const reg = s.registration?.toUpperCase();
        if (seen.has(reg)) return false;
        seen.add(reg);
        return true;
      });
      setPastSearches(unique);
    });
  }, []);

  const toggleSelect = (reg) => {
    setSelectedRegs((prev) =>
      prev.includes(reg) ? prev.filter((r) => r !== reg) : [...prev, reg]
    );
  };

  const handleCompare = async () => {
    setComparing(true);
    const toFetch = selectedRegs.filter((r) => !results[r]);
    const newLoading = {};
    toFetch.forEach((r) => (newLoading[r] = true));
    setLoadingRegs(newLoading);

    await Promise.all(
      toFetch.map(async (reg) => {
        const res = await runMotAnalysis(reg);
        setResults((prev) => ({ ...prev, [reg]: res }));
        setLoadingRegs((prev) => ({ ...prev, [reg]: false }));
      })
    );
    setComparing(false);
  };

  const removeVehicle = (reg) => {
    setSelectedRegs((prev) => prev.filter((r) => r !== reg));
    setResults((prev) => {
      const next = { ...prev };
      delete next[reg];
      return next;
    });
  };

  const hasResults = selectedRegs.some((r) => results[r]);

  return (
    <div className="min-h-screen bg-white">
      {/* Header — matches site header */}
      <header className="bg-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-6">
          <Link to="/" className="flex items-center gap-2 text-slate-900 hover:text-amber-600 transition-colors">
            <img
              src="/wclogo.png"
              alt="WorthCar logo"
              className="w-10 h-10 object-contain"
            />
            <span className="font-bold text-base tracking-tight">WorthCar.co.uk</span>
          </Link>
          <span className="text-slate-300">|</span>
          <span className="text-sm text-slate-500 flex items-center gap-1.5"><BarChart2 className="w-4 h-4 text-amber-500" /> Vehicle Comparison</span>
        </div>
      </header>

      {/* Dark navy sub-header */}
      <div style={{ background: "#0A2540" }}>
        <div className="max-w-5xl mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold text-white">Compare Vehicles</h1>
          <p className="text-sm mt-1" style={{ color: "#94A9C4" }}>Select vehicles from your recent searches and compare them side by side.</p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Vehicle Selector */}
        {!hasResults && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-slate-900 mb-1">Select vehicles to compare</h2>
            <p className="text-sm text-slate-500 mb-5">Choose 2 or more vehicles from your recent searches.</p>

            {pastSearches.length === 0 ? (
              <div className="text-center py-16 text-slate-400">
                <p className="mb-3">No previous searches found.</p>
                <Link to={createPageUrl("Home")}>
                  <Button variant="outline">Search a Vehicle</Button>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {pastSearches.map((s) => {
                  const reg = s.registration?.toUpperCase();
                  const selected = selectedRegs.includes(reg);
                  return (
                    <button
                      key={s.id}
                      onClick={() => toggleSelect(reg)}
                      className={`relative p-4 rounded-xl border-2 text-left transition-all ${
                        selected
                          ? "border-amber-400 bg-amber-50"
                          : "border-slate-200 bg-white hover:border-slate-300"
                      }`}
                    >
                      {selected && (
                        <CheckCircle className="absolute top-2 right-2 w-4 h-4 text-amber-500" />
                      )}
                      <div className="font-mono font-bold text-slate-900 text-sm">{reg}</div>
                      {s.vehicle_make && (
                        <div className="text-xs text-slate-500 mt-0.5">
                          {s.vehicle_make} {s.vehicle_model}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}

            {selectedRegs.length >= 2 && (
              <div className="mt-6 flex justify-center">
                <Button
                  onClick={handleCompare}
                  disabled={comparing}
                  className="bg-amber-500 hover:bg-amber-600 text-white px-8"
                >
                  {comparing ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analysing…</>
                  ) : (
                    <><BarChart2 className="w-4 h-4 mr-2" /> Compare {selectedRegs.length} Vehicles</>
                  )}
                </Button>
              </div>
            )}

            {selectedRegs.length === 1 && (
              <p className="text-center text-sm text-slate-400 mt-4">Select at least one more vehicle to compare.</p>
            )}
          </div>
        )}

        {/* Results */}
        {hasResults && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900">Comparison Results</h2>
              <Button variant="outline" size="sm" onClick={() => { setResults({}); setComparing(false); }}>
                <Plus className="w-4 h-4 mr-1" /> Change Selection
              </Button>
            </div>

            <div
              className="grid gap-4"
              style={{ gridTemplateColumns: `repeat(${selectedRegs.length}, minmax(0, 1fr))` }}
            >
              {selectedRegs.map((reg) => (
                <CompareVehicleColumn
                  key={reg}
                  reg={reg}
                  result={results[reg]}
                  loading={loadingRegs[reg]}
                  onRemove={() => removeVehicle(reg)}
                />
              ))}
            </div>

            <div className="mt-8 text-center">
              <p className="text-xs text-slate-400 max-w-lg mx-auto">
                Comparison based on MOT history data and AI analysis. For guidance only — always have a vehicle professionally inspected before purchase.
              </p>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}