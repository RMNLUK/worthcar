import React from "react";
import { Link } from "react-router-dom";
import LegalPage from "@/components/LegalPage";

function Section({ title, children }) {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-bold text-slate-900 mb-2">{title}</h2>
      <div className="text-sm text-slate-600 leading-relaxed">{children}</div>
    </div>
  );
}

export default function CookiePolicy() {
  return (
    <LegalPage title="Cookie Policy" subtitle="How we use cookies on WorthCar" email="support@worthcar.co.uk">
      <Section title="What are cookies?">
        Cookies are small text files stored on your device when you visit a website. They help sites function correctly, remember your preferences, and improve your experience.
      </Section>
      <Section title="Why we use cookies">
        <ul className="list-disc list-inside space-y-1">
          <li>To run and operate the site correctly</li>
          <li>To improve site performance and speed</li>
          <li>To analyse how visitors use WorthCar</li>
          <li>To support site security</li>
          <li>To show relevant advertising (with your consent)</li>
        </ul>
      </Section>
      <Section title="Types of cookies we use">
        <ul className="list-disc list-inside space-y-2">
          <li><strong>Essential cookies</strong> — Required for the site to function. Cannot be disabled.</li>
          <li><strong>Analytics cookies</strong> — Help us understand usage patterns anonymously.</li>
          <li><strong>Preference cookies</strong> — Remember your settings and choices.</li>
          <li><strong>Marketing cookies</strong> — Used to show relevant advertising. Only set with your consent.</li>
        </ul>
      </Section>
      <Section title="Managing cookies">
        You can manage or withdraw cookie consent at any time using the cookie preferences tool on the site, or via your browser settings. Note that disabling certain cookies may affect site functionality.
      </Section>
      <Section title="Third-party cookies">
        Some cookies may be set by third-party services such as analytics platforms or advertising networks. These are subject to the relevant third party's privacy and cookie policies.
      </Section>
      <Section title="Contact">
        For questions about our use of cookies, <Link to="/Contact" className="text-amber-600 hover:underline">contact us</Link>.
      </Section>
    </LegalPage>
  );
}