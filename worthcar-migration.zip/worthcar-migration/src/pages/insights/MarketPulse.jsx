import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import InsightsNav from "@/components/insights/InsightsNav";
import Footer from "@/components/Footer";
import { insightsMockData } from "@/data/insightsMockData";

const d = insightsMockData.marketPulse;
const ACCENT = "#2563EB";
const MUTED = "#CBD5E1";

function StatCard({ label, value, sub }) {
  return (
    <div className="bg-[#E6F1FB] rounded-xl p-5">
      <p className="text-xs uppercase tracking-widest text-[#64748B] mb-1">{label}</p>
      <p className="text-3xl font-medium text-[#0A2540]">{value}</p>
      <p className="text-xs text-[#64748B] mt-1">{sub}</p>
    </div>
  );
}

function TrendPill({ change }) {
  if (change > 0) return (
    <span className="flex items-center gap-1 px-2 py-0.5 bg-[#EAF3DE] text-[#3B6D11] text-xs font-medium rounded-full">
      <TrendingUp className="w-3 h-3" /> +{change}%
    </span>
  );
  if (change < 0) return (
    <span className="flex items-center gap-1 px-2 py-0.5 bg-[#FCEBEB] text-[#A32D2D] text-xs font-medium rounded-full">
      <TrendingDown className="w-3 h-3" /> {change}%
    </span>
  );
  return (
    <span className="flex items-center gap-1 px-2 py-0.5 bg-[#F8FAFC] text-[#64748B] text-xs font-medium rounded-full">
      <Minus className="w-3 h-3" /> 0%
    </span>
  );
}

function RankBadge({ rank }) {
  const gold = "bg-amber-100 text-amber-700";
  const grey = "bg-[#F8FAFC] text-[#64748B]";
  return (
    <span className={`w-7 h-7 flex items-center justify-center rounded-full text-xs font-semibold flex-shrink-0 ${rank <= 3 ? gold : grey}`}>
      {rank}
    </span>
  );
}

const maxBrand = Math.max(...d.topBrands.map(b => b.count));
const total = d.topBrands.reduce((s, b) => s + b.count, 0);

export default function MarketPulse() {
  const topYear = d.yearPopularity.reduce((a, b) => b.searches > a.searches ? b : a, d.yearPopularity[0]);

  return (
    <div className="min-h-screen bg-white">
      <InsightsNav />

      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-[#0A2540] mb-2">Market Pulse</h1>
          <p className="text-[#64748B]">
            Based on <strong className="text-[#0A2540]">{d.totalSearches.toLocaleString()}</strong> vehicle searches in the last 30 days
          </p>
          <p className="text-xs text-[#94a3b8] mt-1">Last updated: {d.lastUpdated}</p>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <StatCard label="Most Searched Brand" value={d.summaryStats.mostSearchedBrand.value} sub={d.summaryStats.mostSearchedBrand.sub} />
          <StatCard label="Most Searched Model" value={d.summaryStats.mostSearchedModel.value} sub={d.summaryStats.mostSearchedModel.sub} />
          <StatCard label="Average Mileage" value={d.summaryStats.avgMileage.value} sub={d.summaryStats.avgMileage.sub} />
          <StatCard label="Most Popular Year" value={d.summaryStats.mostPopularYear.value} sub={d.summaryStats.mostPopularYear.sub} />
        </div>

        {/* Top Brands Bar Chart */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 mb-8 border border-[#E2E8F0]">
          <h2 className="text-lg font-medium text-[#0A2540] mb-6">Most Searched Brands</h2>
          <div className="space-y-3">
            {d.topBrands.map((b) => {
              const pct = Math.round((b.count / total) * 100);
              const barW = Math.round((b.count / maxBrand) * 100);
              return (
                <div key={b.brand} className="flex items-center gap-3">
                  <span className="text-sm text-[#0A2540] w-28 flex-shrink-0">{b.brand}</span>
                  <div className="flex-1 bg-[#E2E8F0] rounded-full h-3 relative">
                    <div
                      className="h-3 rounded-full transition-all"
                      style={{ width: `${barW}%`, backgroundColor: ACCENT }}
                    />
                  </div>
                  <span className="text-xs text-[#64748B] w-20 text-right flex-shrink-0">
                    {b.count.toLocaleString()} · {pct}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Two column section */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Trending Searches */}
          <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0]">
            <h2 className="text-lg font-medium text-[#0A2540] mb-4">Trending Searches</h2>
            <div className="space-y-3">
              {d.trendingSearches.map((t) => (
                <div key={t.model} className="flex items-center justify-between">
                  <span className="text-sm text-[#0A2540]">{t.model}</span>
                  <TrendPill change={t.change} />
                </div>
              ))}
            </div>
          </div>

          {/* Mileage Distribution */}
          <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0]">
            <h2 className="text-lg font-medium text-[#0A2540] mb-4">Mileage Distribution</h2>
            <div className="space-y-3">
              {d.mileageDistribution.map((m) => (
                <div key={m.label} className="flex items-center gap-3">
                  <span className="text-sm text-[#0A2540] w-40 flex-shrink-0">{m.label}</span>
                  <div className="flex-1 bg-[#E2E8F0] rounded-full h-3">
                    <div className="h-3 rounded-full" style={{ width: `${m.pct * 2.5}%`, backgroundColor: m.color }} />
                  </div>
                  <span className="text-xs text-[#64748B] w-8 text-right flex-shrink-0">{m.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Models Table */}
        <div className="bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0] mb-8 overflow-hidden">
          <div className="px-6 py-4 border-b border-[#E2E8F0]">
            <h2 className="text-lg font-medium text-[#0A2540]">Most Searched Models This Month</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E2E8F0]">
                  <th className="text-left px-6 py-3 text-xs uppercase tracking-widest text-[#64748B]">Rank</th>
                  <th className="text-left px-4 py-3 text-xs uppercase tracking-widest text-[#64748B]">Model</th>
                  <th className="text-right px-4 py-3 text-xs uppercase tracking-widest text-[#64748B]">Searches</th>
                  <th className="text-right px-4 py-3 text-xs uppercase tracking-widest text-[#64748B]">Avg Mileage</th>
                  <th className="text-right px-4 py-3 text-xs uppercase tracking-widest text-[#64748B]">Avg Year</th>
                  <th className="text-center px-4 py-3 text-xs uppercase tracking-widest text-[#64748B]">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E8F0]">
                {d.topModels.map((m) => (
                  <tr key={m.rank} className="hover:bg-white transition-colors">
                    <td className="px-6 py-3"><RankBadge rank={m.rank} /></td>
                    <td className="px-4 py-3 font-medium text-[#0A2540]">{m.model}</td>
                    <td className="px-4 py-3 text-right text-[#64748B]">{m.searches.toLocaleString()}</td>
                    <td className="px-4 py-3 text-right text-[#64748B]">{m.avgMileage}</td>
                    <td className="px-4 py-3 text-right text-[#64748B]">{m.avgYear}</td>
                    <td className="px-4 py-3 text-center">
                      {m.trend === "up" && <TrendingUp className="w-4 h-4 text-[#3B6D11] mx-auto" />}
                      {m.trend === "down" && <TrendingDown className="w-4 h-4 text-[#A32D2D] mx-auto" />}
                      {m.trend === "flat" && <Minus className="w-4 h-4 text-[#64748B] mx-auto" />}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Year Popularity Chart */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-4">
          <h2 className="text-lg font-medium text-[#0A2540] mb-6">Registration Year Popularity</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={d.yearPopularity} margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
              <XAxis dataKey="year" tick={{ fontSize: 12, fill: "#64748B" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: "#64748B" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: "1px solid #E2E8F0", fontSize: 13 }}
                formatter={(v) => [v.toLocaleString(), "Searches"]}
              />
              <Bar dataKey="searches" radius={[4, 4, 0, 0]}>
                {d.yearPopularity.map((y) => (
                  <Cell key={y.year} fill={y.year === topYear.year ? ACCENT : MUTED} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <p className="text-xs text-[#94a3b8] text-center mb-4">
          Data is aggregated and anonymised from WorthCar vehicle checks. No personal data is stored or displayed.
        </p>

        <Footer />
      </div>
    </div>
  );
}