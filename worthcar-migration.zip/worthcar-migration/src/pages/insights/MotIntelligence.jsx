import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import InsightsNav from "@/components/insights/InsightsNav";
import Footer from "@/components/Footer";
import { insightsMockData } from "@/data/insightsMockData";

const d = insightsMockData.motIntelligence;

function StatCard({ label, value, sub }) {
  return (
    <div className="bg-[#E6F1FB] rounded-xl p-5">
      <p className="text-xs uppercase tracking-widest text-[#64748B] mb-1">{label}</p>
      <p className="text-3xl font-medium text-[#0A2540]">{value}</p>
      <p className="text-xs text-[#64748B] mt-1">{sub}</p>
    </div>
  );
}

function heatColor(pct) {
  if (pct <= 10) return { bg: "#EAF3DE", text: "#3B6D11" };
  if (pct <= 25) return { bg: "#FAEEDA", text: "#854F0B" };
  if (pct <= 40) return { bg: "#FCEBEB", text: "#A32D2D" };
  return { bg: "#f87171", text: "#7f1d1d" };
}

function rankColor(rank) {
  if (rank <= 3) return "bg-[#FCEBEB] text-[#A32D2D]";
  if (rank <= 5) return "bg-[#FAEEDA] text-[#854F0B]";
  return "bg-[#F8FAFC] text-[#64748B]";
}

function failPctColor(pct) {
  if (pct >= 20) return "text-[#A32D2D] font-semibold";
  if (pct >= 10) return "text-[#854F0B]";
  return "text-[#3B6D11]";
}

const brandColors = ["#22c55e", "#22c55e", "#f59e0b", "#f59e0b", "#ef4444", "#ef4444"];

export default function MotIntelligence() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState("VW Golf");

  const heatMap = d.heatMapData[selected] || d.heatMapData["VW Golf"];

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearch(val);
    const match = Object.keys(d.heatMapData).find(k => k.toLowerCase().includes(val.toLowerCase()));
    if (match) setSelected(match);
  };

  return (
    <div className="min-h-screen bg-white">
      <InsightsNav />

      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-[#0A2540] mb-2">MOT Failure Intelligence</h1>
          <p className="text-[#64748B] mb-4">
            What actually fails — and at what mileage — across hundreds of UK vehicles
          </p>
          <input
            type="text"
            value={search}
            onChange={handleSearch}
            placeholder="Search a make or model, e.g. VW Golf…"
            className="w-full max-w-md border border-[#E2E8F0] rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB] text-[#0A2540]"
          />
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <StatCard label="Overall MOT Pass Rate" value={d.summaryStats.overallPassRate.value} sub={d.summaryStats.overallPassRate.sub} />
          <StatCard label="Most Common Fail" value={d.summaryStats.mostCommonFail.value} sub={d.summaryStats.mostCommonFail.sub} />
          <StatCard label="Avg Failures / Vehicle" value={d.summaryStats.avgFailuresPerVehicle.value} sub={d.summaryStats.avgFailuresPerVehicle.sub} />
          <StatCard label="Highest Risk Mileage" value={d.summaryStats.highestRiskMileage.value} sub={d.summaryStats.highestRiskMileage.sub} />
        </div>

        {/* Top Failure Categories */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
          <h2 className="text-lg font-medium text-[#0A2540] mb-5">Top Failure Categories — All Vehicles</h2>
          <div className="space-y-4">
            {d.topFailureCategories.map((f) => (
              <div key={f.rank} className="flex items-start gap-4">
                <span className={`w-7 h-7 flex-shrink-0 flex items-center justify-center rounded-full text-xs font-semibold ${rankColor(f.rank)}`}>
                  {f.rank}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="font-medium text-[#0A2540] text-sm">{f.category}</span>
                    <span className={`text-sm ${failPctColor(f.pct)}`}>{f.pct}%</span>
                  </div>
                  <p className="text-xs text-[#64748B] mt-0.5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Heat Map */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
          <div className="flex items-baseline gap-2 mb-1">
            <h2 className="text-lg font-medium text-[#0A2540]">Failure Rate by Mileage Band</h2>
            <span className="text-sm text-[#64748B]">— {selected}</span>
          </div>
          <p className="text-xs text-[#64748B] mb-5">% of vehicles in that mileage band that experienced each failure type</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th className="text-left py-2 pr-4 text-xs text-[#64748B] font-medium">Category</th>
                  {heatMap.bands.map((b) => (
                    <th key={b} className="text-center py-2 px-3 text-xs text-[#64748B] font-medium whitespace-nowrap">{b}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {heatMap.categories.map((cat, ci) => (
                  <tr key={cat}>
                    <td className="py-2 pr-4 font-medium text-[#0A2540] text-sm whitespace-nowrap">{cat}</td>
                    {heatMap.values[ci].map((val, bi) => {
                      const { bg, text } = heatColor(val);
                      return (
                        <td key={bi} className="py-1.5 px-2 text-center">
                          <span
                            className="inline-block min-w-[3rem] py-1 px-2 rounded-lg text-xs font-medium"
                            style={{ backgroundColor: bg, color: text }}
                          >
                            {val}%
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Legend */}
          <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-[#E2E8F0]">
            {[["#EAF3DE","#3B6D11","0–10%"], ["#FAEEDA","#854F0B","11–25%"], ["#FCEBEB","#A32D2D","26–40%"], ["#f87171","#7f1d1d","41%+"]].map(([bg, text, label]) => (
              <span key={label} className="flex items-center gap-1.5 text-xs" style={{ color: text }}>
                <span className="w-4 h-4 rounded" style={{ backgroundColor: bg, border: `1px solid ${text}40` }} />
                {label}
              </span>
            ))}
          </div>
        </div>

        {/* Brand Fail Rates */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
          <h2 className="text-lg font-medium text-[#0A2540] mb-6">MOT Fail Rate by Brand</h2>
          <div className="space-y-3">
            {d.brandFailRates.map((b, i) => (
              <div key={b.brand} className="flex items-center gap-3">
                <span className="text-sm text-[#0A2540] w-28 flex-shrink-0">{b.brand}</span>
                <div className="flex-1 bg-[#E2E8F0] rounded-full h-3">
                  <div className="h-3 rounded-full" style={{ width: `${b.failRate * 2.5}%`, backgroundColor: brandColors[i] }} />
                </div>
                <span className="text-xs text-[#64748B] w-8 text-right">{b.failRate}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Advisories vs Hard Fails */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0]">
            <h2 className="text-base font-medium text-[#0A2540] mb-4">Top Advisories</h2>
            <ol className="space-y-2">
              {d.advisories.map((a, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-[#0A2540]">
                  <span className="w-6 h-6 flex-shrink-0 flex items-center justify-center rounded-full bg-[#FAEEDA] text-[#854F0B] text-xs font-semibold">{i + 1}</span>
                  {a}
                </li>
              ))}
            </ol>
          </div>
          <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0]">
            <h2 className="text-base font-medium text-[#0A2540] mb-4">Top Hard Fails</h2>
            <ol className="space-y-2">
              {d.hardFails.map((f, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-[#0A2540]">
                  <span className="w-6 h-6 flex-shrink-0 flex items-center justify-center rounded-full bg-[#FCEBEB] text-[#A32D2D] text-xs font-semibold">{i + 1}</span>
                  {f}
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* Brand Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {d.brandCards.map((b) => (
            <div key={b.brand} className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-lg font-medium text-[#0A2540]">{b.brand}</span>
                <span className="px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: b.passColor + "22", color: b.passColor }}>
                  {b.passRate}% pass
                </span>
              </div>
              <p className="text-xs text-[#64748B] mb-1">Most common failure: <span className="text-[#0A2540]">{b.mostCommonFail}</span></p>
              <p className="text-xs text-[#64748B] mb-4">Recommended max: <span className="text-[#0A2540]">{b.maxMileage}</span></p>
              <button className="text-xs text-[#2563EB] font-medium hover:underline">
                See full {b.brand} MOT data →
              </button>
            </div>
          ))}
        </div>



        <Footer />
      </div>
    </div>
  );
}