import React, { useState } from "react";
import { Search, Clock, TrendingUp } from "lucide-react";
import InsightsNav from "@/components/insights/InsightsNav";
import Footer from "@/components/Footer";
import { insightsMockData } from "@/data/insightsMockData";

const d = insightsMockData.buyerGuides;

const FILTER_TABS = ["All", "By Model", "By Mileage", "By Budget", "Seasonal"];

const TAG_COLORS = {
  "Most viewed": { bg: "#E6F1FB", text: "#2563EB" },
  "MOT data": { bg: "#EAF3DE", text: "#3B6D11" },
  "Trending": { bg: "#FAEEDA", text: "#854F0B" },
  "Low risk": { bg: "#EAF3DE", text: "#3B6D11" },
  "Mileage guide": { bg: "#F8FAFC", text: "#64748B" },
  "Seasonal": { bg: "#FAEEDA", text: "#854F0B" },
  "Compare": { bg: "#E6F1FB", text: "#2563EB" },
  "High demand": { bg: "#FCEBEB", text: "#A32D2D" },
  "Buyer tips": { bg: "#F8FAFC", text: "#64748B" },
  default: { bg: "#F8FAFC", text: "#64748B" },
};

function Tag({ label }) {
  const { bg, text } = TAG_COLORS[label] || TAG_COLORS.default;
  return (
    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: bg, color: text }}>
      {label}
    </span>
  );
}

export default function BuyerGuides() {
  const [activeFilter, setActiveFilter] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredGuides = d.guides.filter((g) => {
    const matchFilter = activeFilter === "All" || g.category === activeFilter;
    const matchSearch = searchTerm === "" || g.headline.toLowerCase().includes(searchTerm.toLowerCase()) || g.desc.toLowerCase().includes(searchTerm.toLowerCase());
    return matchFilter && matchSearch;
  });

  return (
    <div className="min-h-screen bg-white">
      <InsightsNav />

      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-[#0A2540] mb-2">Buyer Guides</h1>
          <p className="text-[#64748B] mb-5">Data-driven answers to the questions every used car buyer is actually asking</p>
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#94a3b8]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search guides…"
              className="w-full pl-10 pr-4 py-2.5 border border-[#E2E8F0] rounded-xl text-sm text-[#0A2540] focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
            />
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {FILTER_TABS.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveFilter(tab)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                activeFilter === tab
                  ? "bg-[#0A2540] text-white"
                  : "bg-[#F8FAFC] text-[#64748B] hover:bg-[#E6F1FB] hover:text-[#2563EB] border border-[#E2E8F0]"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="flex gap-8">
          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Featured Guide */}
            <div className="bg-[#F8FAFC] rounded-2xl p-8 border border-[#E2E8F0] mb-8">
              <div className="flex flex-wrap gap-2 mb-3">
                {d.featured.tags.map((t) => <Tag key={t} label={t} />)}
              </div>
              <h2 className="text-2xl font-medium text-[#0A2540] mb-3">{d.featured.headline}</h2>
              <p className="text-[#64748B] mb-5">{d.featured.description}</p>
              <div className="flex flex-wrap items-center gap-4 text-xs text-[#94a3b8] mb-6">
                <span>{d.featured.date}</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{d.featured.readTime}</span>
                <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3" />{d.featured.searchesThisMonth.toLocaleString()} searches this month</span>
              </div>
              <button className="px-6 py-2.5 bg-[#2563EB] text-white font-medium rounded-xl hover:bg-blue-700 transition-colors text-sm">
                Read guide →
              </button>
            </div>

            {/* Guide Cards Grid */}
            <div className="grid md:grid-cols-2 gap-5 mb-8">
              {filteredGuides.map((g, i) => (
                <div key={i} className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] hover:border-[#2563EB] transition-colors cursor-pointer group">
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {g.tags.map((t) => <Tag key={t} label={t} />)}
                  </div>
                  <h3 className="text-sm font-medium text-[#0A2540] mb-2 group-hover:text-[#2563EB] transition-colors leading-snug">{g.headline}</h3>
                  <p className="text-xs text-[#64748B] mb-4 leading-relaxed">{g.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2 text-xs text-[#94a3b8]">
                      <Clock className="w-3 h-3" />{g.readTime}
                      <span>·</span>{g.date}
                    </span>
                    <span className="text-xs text-[#2563EB] font-medium group-hover:underline">Read guide →</span>
                  </div>
                </div>
              ))}
            </div>

            {filteredGuides.length === 0 && (
              <div className="text-center py-12 text-[#64748B] text-sm">No guides found for your search.</div>
            )}

          </div>

          {/* Sidebar — desktop only */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-[#F8FAFC] rounded-2xl p-5 border border-[#E2E8F0] sticky top-20">
              <h3 className="text-sm font-medium text-[#0A2540] mb-4">Most Read This Month</h3>
              <ol className="space-y-4">
                {d.mostRead.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 cursor-pointer group">
                    <span className="text-lg font-semibold text-[#E2E8F0] leading-none flex-shrink-0 mt-0.5">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <p className="text-xs font-medium text-[#0A2540] leading-snug group-hover:text-[#2563EB] transition-colors">{item.title}</p>
                      <p className="text-xs text-[#94a3b8] mt-1 flex items-center gap-1"><Clock className="w-3 h-3" />{item.readTime}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
}