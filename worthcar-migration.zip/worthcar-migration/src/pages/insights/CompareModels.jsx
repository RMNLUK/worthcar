import React, { useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend,
  LineChart, Line, CartesianGrid,
} from "recharts";
import InsightsNav from "@/components/insights/InsightsNav";
import Footer from "@/components/Footer";
import { insightsMockData } from "@/data/insightsMockData";

const d = insightsMockData.compareModels;
const COLOR_A = "#2563EB";
const COLOR_B = "#E24B4A";

const ROW_LABELS = {
  motPassRate: "MOT Pass Rate",
  avgFailuresPerTest: "Avg Failures Per Test",
  mostCommonFailure: "Most Common Failure",
  avgMileageAtFirstFail: "Avg Mileage at 1st Fail",
  advisoriesPerTest: "Advisories Per Test",
  worthCarScore: "WorthCar Score",
};

const SCORE_ROWS = { worthCarScore: true };

function getComparisonData(modelA, modelB) {
  const key = `${modelA}|${modelB}`;
  const altKey = `${modelB}|${modelA}`;
  return d.comparisons[key] || d.comparisons[altKey] || d.comparisons[Object.keys(d.comparisons)[0]];
}

export default function CompareModels() {
  const [modelA, setModelA] = useState(d.availableModels[0]);
  const [modelB, setModelB] = useState(d.availableModels[1]);
  const [comparison, setComparison] = useState(getComparisonData(d.availableModels[0], d.availableModels[1]));

  const handleCompare = (a, b) => {
    setModelA(a);
    setModelB(b);
    setComparison(getComparisonData(a, b));
  };

  const handleQuickPick = ([a, b]) => {
    handleCompare(a, b);
  };

  return (
    <div className="min-h-screen bg-white">
      <InsightsNav />

      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Hero */}
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-[#0A2540] mb-2">Compare Models</h1>
          <p className="text-[#64748B]">Head-to-head reliability, MOT pass rates and mileage risk — from real WorthCar data</p>
        </div>

        {/* Model Selector */}
        <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
          <div className="flex flex-col sm:flex-row gap-4 items-end">
            <div className="flex-1">
              <label className="block text-xs uppercase tracking-widest text-[#64748B] mb-2">Vehicle A</label>
              <select
                value={modelA}
                onChange={(e) => setModelA(e.target.value)}
                className="w-full border border-[#E2E8F0] rounded-xl px-4 py-2.5 text-sm text-[#0A2540] bg-white focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              >
                {d.availableModels.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div className="text-[#64748B] font-medium px-2 pb-2">vs</div>
            <div className="flex-1">
              <label className="block text-xs uppercase tracking-widest text-[#64748B] mb-2">Vehicle B</label>
              <select
                value={modelB}
                onChange={(e) => setModelB(e.target.value)}
                className="w-full border border-[#E2E8F0] rounded-xl px-4 py-2.5 text-sm text-[#0A2540] bg-white focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
              >
                {d.availableModels.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <button
              onClick={() => handleCompare(modelA, modelB)}
              className="px-6 py-2.5 bg-[#2563EB] text-white text-sm font-medium rounded-xl hover:bg-blue-700 transition-colors"
            >
              Compare
            </button>
          </div>

          {/* Popular Comparisons */}
          <div className="mt-5 pt-4 border-t border-[#E2E8F0]">
            <p className="text-xs text-[#64748B] mb-3 uppercase tracking-widest">Popular comparisons</p>
            <div className="flex flex-wrap gap-2">
              {d.popularComparisons.map(([a, b]) => (
                <button
                  key={`${a}|${b}`}
                  onClick={() => handleQuickPick([a, b])}
                  className="px-3 py-1.5 text-xs font-medium rounded-full border border-[#E2E8F0] text-[#64748B] hover:border-[#2563EB] hover:text-[#2563EB] transition-colors bg-white"
                >
                  {a.split(" ").slice(0, 2).join(" ")} vs {b.split(" ").slice(0, 2).join(" ")}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Comparison Table */}
        {comparison && (
          <>
            <div className="bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0] mb-8 overflow-hidden">
              <div className="grid grid-cols-3 border-b border-[#E2E8F0]">
                <div className="px-6 py-4 text-sm text-[#64748B]" />
                <div className="px-6 py-4 text-center font-medium text-sm" style={{ color: COLOR_A }}>{modelA}</div>
                <div className="px-6 py-4 text-center font-medium text-sm" style={{ color: COLOR_B }}>{modelB}</div>
              </div>
              {Object.entries(ROW_LABELS).map(([key, label]) => {
                const vals = comparison.table[key];
                const winner = comparison.winners[key]; // 0 = A wins, 1 = B wins, undefined = no winner
                const isScore = SCORE_ROWS[key];
                return (
                  <div key={key} className="grid grid-cols-3 border-b border-[#E2E8F0] last:border-0">
                    <div className="px-6 py-4 text-sm text-[#64748B]">{label}</div>
                    {vals && vals.map((val, idx) => (
                      <div
                        key={idx}
                        className={`px-6 py-4 text-center ${winner === idx ? "bg-[#EAF3DE]" : ""} ${isScore ? "text-xl font-semibold text-[#0A2540]" : "text-sm text-[#0A2540]"}`}
                      >
                        {val}
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>

            {/* Advisory Frequency Chart */}
            <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
              <h2 className="text-lg font-medium text-[#0A2540] mb-6">Advisory Frequency Comparison</h2>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={comparison.advisoryFreq} layout="vertical" margin={{ left: 70, right: 20 }}>
                  <XAxis type="number" tick={{ fontSize: 12, fill: "#64748B" }} axisLine={false} tickLine={false} unit="%" />
                  <YAxis type="category" dataKey="category" tick={{ fontSize: 12, fill: "#0A2540" }} axisLine={false} tickLine={false} width={70} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #E2E8F0", fontSize: 13 }} formatter={(v) => [`${v}%`]} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="a" name={modelA.split(" ").slice(0, 2).join(" ")} fill={COLOR_A} radius={[0, 3, 3, 0]} />
                  <Bar dataKey="b" name={modelB.split(" ").slice(0, 2).join(" ")} fill={COLOR_B} radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Mileage Risk Line Chart */}
            <div className="bg-[#F8FAFC] rounded-2xl p-6 border border-[#E2E8F0] mb-8">
              <h2 className="text-lg font-medium text-[#0A2540] mb-2">Mileage Risk Profile</h2>
              <p className="text-xs text-[#64748B] mb-6">Cumulative % chance of at least one MOT failure recorded</p>
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={comparison.mileageRisk} margin={{ right: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="mileage" tick={{ fontSize: 12, fill: "#64748B" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: "#64748B" }} axisLine={false} tickLine={false} unit="%" />
                  <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #E2E8F0", fontSize: 13 }} formatter={(v) => [`${v}%`]} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Line type="monotone" dataKey="a" name={modelA.split(" ").slice(0, 2).join(" ")} stroke={COLOR_A} strokeWidth={2} dot={{ r: 4 }} />
                  <Line type="monotone" dataKey="b" name={modelB.split(" ").slice(0, 2).join(" ")} stroke={COLOR_B} strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Verdict */}
            <div className="bg-[#E6F1FB] border border-[#bfdbfe] rounded-2xl p-6 mb-8">
              <p className="text-xs uppercase tracking-widest text-[#2563EB] mb-2">WorthCar Verdict</p>
              <p className="text-[#0A2540] leading-relaxed">{comparison.verdict}</p>
            </div>
          </>
        )}

        <Footer />
      </div>
    </div>
  );
}