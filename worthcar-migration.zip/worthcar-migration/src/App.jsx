import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import TermsOfUse from './pages/TermsOfUse';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import Disclaimer from './pages/Disclaimer';
import DataSources from './pages/DataSources';
import Contact from './pages/Contact';
import AffiliateDisclosure from './pages/AffiliateDisclosure';
import AdminDashboard from './pages/AdminDashboard';
import EditorialLanding from './pages/EditorialLanding';
import AdsTxt from './pages/AdsTxt';
import Compare from './pages/Compare';
import MarketPulse from './pages/insights/MarketPulse';
import MotIntelligence from './pages/insights/MotIntelligence';
import CompareModels from './pages/insights/CompareModels';
import BuyerGuides from './pages/insights/BuyerGuides';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      <Route path="/TermsOfUse" element={<TermsOfUse />} />
      <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
      <Route path="/CookiePolicy" element={<CookiePolicy />} />
      <Route path="/Disclaimer" element={<Disclaimer />} />
      <Route path="/DataSources" element={<DataSources />} />
      <Route path="/Contact" element={<Contact />} />
      <Route path="/AffiliateDisclosure" element={<AffiliateDisclosure />} />
      <Route path="/admindashboard" element={<AdminDashboard />} />
      <Route path="/free-car-valuation-without-email" element={<EditorialLanding />} />
      <Route path="/free-car-valuation-uk" element={<EditorialLanding />} />
      <Route path="/value-my-car-by-registration-number" element={<EditorialLanding />} />
      <Route path="/mot-check-uk" element={<EditorialLanding />} />
      <Route path="/check-mot-history" element={<EditorialLanding />} />
      <Route path="/vehicle-history-check-uk" element={<EditorialLanding />} />
      <Route path="/aa-car-valuation-alternative" element={<EditorialLanding />} />
      <Route path="/glasses-guide-car-valuation-free-alternative" element={<EditorialLanding />} />
      <Route path="/dvla-car-value" element={<EditorialLanding />} />
      <Route path="/car-valuation-uk-without-personal-details" element={<EditorialLanding />} />
      <Route path="/ads.txt" element={<AdsTxt />} />
      <Route path="/compare" element={<Compare />} />
      <Route path="/insights/market-pulse" element={<MarketPulse />} />
      <Route path="/insights/mot-intelligence" element={<MotIntelligence />} />
      <Route path="/insights/compare-models" element={<CompareModels />} />
      <Route path="/insights/buyer-guides" element={<BuyerGuides />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App