// ============================================================
// WorthCar Insights Hub — Central Mock Data
// Replace values with real API responses to update the UI.
// ============================================================

export const insightsMockData = {

  // ──────────────────────────────────────────────────────────
  // PAGE 1: MARKET PULSE
  // ──────────────────────────────────────────────────────────
  marketPulse: {
    totalSearches: 48200,
    lastUpdated: "April 2026",
    summaryStats: {
      mostSearchedBrand: { value: "Ford", sub: "18% of all searches" },
      mostSearchedModel: { value: "VW Golf", sub: "4,100 checks this month" },
      avgMileage: { value: "64,000 mi", sub: "At time of search" },
      mostPopularYear: { value: "2019", sub: "Plate year buyers want most" },
    },
    topBrands: [
      { brand: "Ford", count: 8780 },
      { brand: "Volkswagen", count: 7490 },
      { brand: "BMW", count: 6200 },
      { brand: "Toyota", count: 5450 },
      { brand: "Vauxhall", count: 4720 },
      { brand: "Audi", count: 4160 },
      { brand: "Mercedes", count: 3800 },
      { brand: "Honda", count: 3200 },
    ],
    trendingSearches: [
      { model: "Toyota Yaris Cross", change: 41 },
      { model: "Ford Puma", change: 28 },
      { model: "Nissan Leaf", change: 22 },
      { model: "VW Polo 2021", change: 18 },
      { model: "BMW 3 Series", change: -7 },
    ],
    mileageDistribution: [
      { label: "Under 30,000 mi", pct: 14, color: "#22c55e" },
      { label: "30,000–60,000 mi", pct: 28, color: "#22c55e" },
      { label: "60,000–100,000 mi", pct: 40, color: "#f59e0b" },
      { label: "Over 100,000 mi", pct: 18, color: "#ef4444" },
    ],
    topModels: [
      { rank: 1, model: "VW Golf", searches: 4100, avgMileage: "68,200", avgYear: 2019, trend: "up" },
      { rank: 2, model: "Ford Fiesta", searches: 3820, avgMileage: "71,400", avgYear: 2018, trend: "up" },
      { rank: 3, model: "BMW 3 Series", searches: 3500, avgMileage: "62,800", avgYear: 2020, trend: "flat" },
      { rank: 4, model: "Toyota Yaris", searches: 3200, avgMileage: "54,100", avgYear: 2021, trend: "up" },
      { rank: 5, model: "Vauxhall Astra", searches: 2980, avgMileage: "74,300", avgYear: 2018, trend: "down" },
      { rank: 6, model: "Ford Focus", searches: 2740, avgMileage: "69,500", avgYear: 2019, trend: "flat" },
      { rank: 7, model: "Audi A3", searches: 2510, avgMileage: "61,200", avgYear: 2020, trend: "up" },
      { rank: 8, model: "Nissan Qashqai", searches: 2380, avgMileage: "66,800", avgYear: 2019, trend: "up" },
      { rank: 9, model: "Honda Civic", searches: 2100, avgMileage: "58,400", avgYear: 2020, trend: "flat" },
      { rank: 10, model: "Mercedes C-Class", searches: 1940, avgMileage: "55,700", avgYear: 2021, trend: "up" },
    ],
    yearPopularity: [
      { year: 2015, searches: 2100 },
      { year: 2016, searches: 3400 },
      { year: 2017, searches: 4800 },
      { year: 2018, searches: 7200 },
      { year: 2019, searches: 8900 },
      { year: 2020, searches: 7600 },
      { year: 2021, searches: 6400 },
      { year: 2022, searches: 4900 },
      { year: 2023, searches: 2800 },
      { year: 2024, searches: 1100 },
    ],
  },

  // ──────────────────────────────────────────────────────────
  // PAGE 2: MOT INTELLIGENCE
  // ──────────────────────────────────────────────────────────
  motIntelligence: {
    summaryStats: {
      overallPassRate: { value: "71%", sub: "Across all checked vehicles" },
      mostCommonFail: { value: "Lighting", sub: "31% of all failures" },
      avgFailuresPerVehicle: { value: "1.6", sub: "Per MOT test on record" },
      highestRiskMileage: { value: "60–80k", sub: "Most failures recorded here" },
    },
    topFailureCategories: [
      { rank: 1, category: "Lighting & Signalling", pct: 31, desc: "Blown bulbs, faulty lights — most common at 3–5 years old" },
      { rank: 2, category: "Tyres", pct: 24, desc: "Tread depth / sidewall damage — peaks at 60–80k miles" },
      { rank: 3, category: "Brakes", pct: 18, desc: "Pads, discs, binding — rises sharply after 80k miles" },
      { rank: 4, category: "Suspension & Steering", pct: 14, desc: "Worn bushes, track rod ends — age 7+ years" },
      { rank: 5, category: "Emissions", pct: 9, desc: "DPF issues — higher on older diesels over 80k miles" },
      { rank: 6, category: "Wipers & Washers", pct: 4, desc: "Common advisory, rarely a hard fail" },
    ],
    heatMapData: {
      "VW Golf": {
        categories: ["Lighting", "Tyres", "Brakes", "Suspension", "Emissions"],
        bands: ["Under 30k", "30–60k", "60–90k", "90–120k", "120k+"],
        values: [
          [8, 14, 22, 31, 44],
          [5, 11, 26, 38, 51],
          [3, 7, 18, 33, 49],
          [2, 6, 12, 24, 41],
          [1, 4, 9, 17, 38],
        ],
      },
      "Ford Focus": {
        categories: ["Lighting", "Tyres", "Brakes", "Suspension", "Emissions"],
        bands: ["Under 30k", "30–60k", "60–90k", "90–120k", "120k+"],
        values: [
          [10, 18, 28, 38, 51],
          [7, 14, 30, 44, 58],
          [4, 9, 22, 38, 54],
          [3, 8, 16, 29, 48],
          [2, 6, 12, 22, 44],
        ],
      },
    },
    brandFailRates: [
      { brand: "Toyota", failRate: 19 },
      { brand: "Honda", failRate: 22 },
      { brand: "Volkswagen", failRate: 26 },
      { brand: "Ford", failRate: 29 },
      { brand: "BMW", failRate: 31 },
      { brand: "Vauxhall", failRate: 34 },
    ],
    advisories: ["Tyre wear approaching limit", "Brake wear noted", "Minor oil leak", "Wiper blade deterioration", "Headlight aim off"],
    hardFails: ["Blown front bulb", "Bald tyre (under limit)", "Brake failure", "DPF blocked", "Suspension joint failed"],
    brandCards: [
      { brand: "Toyota", passRate: 81, passColor: "#22c55e", mostCommonFail: "Lighting", maxMileage: "100,000 mi" },
      { brand: "Volkswagen", passRate: 74, passColor: "#f59e0b", mostCommonFail: "Tyres", maxMileage: "80,000 mi" },
      { brand: "Ford", passRate: 71, passColor: "#f59e0b", mostCommonFail: "Lighting", maxMileage: "75,000 mi" },
    ],
  },

  // ──────────────────────────────────────────────────────────
  // PAGE 3: COMPARE MODELS
  // ──────────────────────────────────────────────────────────
  compareModels: {
    availableModels: [
      "VW Golf (2018–2022)", "Ford Focus (2018–2022)", "Toyota Yaris (2019–2023)",
      "VW Polo (2019–2022)", "BMW 3 Series (2019–2022)", "Audi A4 (2019–2022)",
      "Ford Fiesta (2018–2022)", "Vauxhall Corsa (2019–2022)", "Honda Civic (2019–2022)",
      "Toyota Corolla (2019–2022)", "Nissan Qashqai (2019–2022)", "Ford Kuga (2019–2022)",
    ],
    comparisons: {
      "VW Golf (2018–2022)|Ford Focus (2018–2022)": {
        table: {
          motPassRate: ["82%", "76%"],
          avgFailuresPerTest: ["1.4", "1.8"],
          mostCommonFailure: ["Lighting", "Tyres"],
          avgMileageAtFirstFail: ["71,200 mi", "64,800 mi"],
          advisoriesPerTest: ["2.1", "2.7"],
          worthCarScore: ["7.8 / 10", "7.1 / 10"],
        },
        winners: { motPassRate: 0, avgFailuresPerTest: 0, avgMileageAtFirstFail: 0, advisoriesPerTest: 0, worthCarScore: 0 },
        advisoryFreq: [
          { category: "Tyres", a: 32, b: 40 },
          { category: "Brakes", a: 21, b: 27 },
          { category: "Lighting", a: 29, b: 24 },
          { category: "Suspension", a: 18, b: 22 },
          { category: "Emissions", a: 11, b: 14 },
        ],
        mileageRisk: [
          { mileage: "0", a: 5, b: 7 },
          { mileage: "20k", a: 12, b: 16 },
          { mileage: "40k", a: 21, b: 28 },
          { mileage: "60k", a: 34, b: 44 },
          { mileage: "80k", a: 48, b: 59 },
          { mileage: "100k", a: 62, b: 72 },
          { mileage: "120k+", a: 74, b: 83 },
        ],
        verdict: "Based on WorthCar data, the VW Golf has a higher MOT pass rate and a later average mileage before first failure. For buyers prioritising reliability, the Golf scores better across most categories in this mileage range.",
      },
      "Toyota Yaris (2019–2023)|VW Polo (2019–2022)": {
        table: {
          motPassRate: ["88%", "79%"],
          avgFailuresPerTest: ["1.1", "1.5"],
          mostCommonFailure: ["Lighting", "Brakes"],
          avgMileageAtFirstFail: ["82,400 mi", "68,100 mi"],
          advisoriesPerTest: ["1.7", "2.3"],
          worthCarScore: ["8.4 / 10", "7.4 / 10"],
        },
        winners: { motPassRate: 0, avgFailuresPerTest: 0, avgMileageAtFirstFail: 0, advisoriesPerTest: 0, worthCarScore: 0 },
        advisoryFreq: [
          { category: "Tyres", a: 24, b: 31 },
          { category: "Brakes", a: 17, b: 24 },
          { category: "Lighting", a: 28, b: 26 },
          { category: "Suspension", a: 12, b: 19 },
          { category: "Emissions", a: 8, b: 11 },
        ],
        mileageRisk: [
          { mileage: "0", a: 3, b: 6 },
          { mileage: "20k", a: 8, b: 14 },
          { mileage: "40k", a: 16, b: 25 },
          { mileage: "60k", a: 27, b: 39 },
          { mileage: "80k", a: 40, b: 54 },
          { mileage: "100k", a: 54, b: 67 },
          { mileage: "120k+", a: 67, b: 78 },
        ],
        verdict: "The Toyota Yaris significantly outperforms the VW Polo on reliability metrics across all mileage bands. With an average first failure mileage 14,000 miles higher, the Yaris is the stronger choice for buyers seeking long-term dependability.",
      },
    },
    popularComparisons: [
      ["VW Golf (2018–2022)", "Ford Focus (2018–2022)"],
      ["Toyota Yaris (2019–2023)", "VW Polo (2019–2022)"],
      ["BMW 3 Series (2019–2022)", "Audi A4 (2019–2022)"],
      ["Ford Fiesta (2018–2022)", "Vauxhall Corsa (2019–2022)"],
      ["Honda Civic (2019–2022)", "Toyota Corolla (2019–2022)"],
      ["Nissan Qashqai (2019–2022)", "Ford Kuga (2019–2022)"],
    ],
  },

  // ──────────────────────────────────────────────────────────
  // PAGE 4: BUYER GUIDES
  // ──────────────────────────────────────────────────────────
  buyerGuides: {
    featured: {
      tags: ["Most viewed", "MOT data"],
      headline: "Is a VW Golf worth buying at 70,000 miles?",
      description: "Based on 6,200 Golf checks on WorthCar — here's what fails, what it costs, and what to look out for.",
      date: "March 2026",
      readTime: "6 min read",
      searchesThisMonth: 4100,
    },
    guides: [
      { tags: ["Trending", "MOT data"], headline: "The 5 most reliable used cars under £10,000", desc: "Ranked by WorthCar pass rate score across 2019–2021 plates", date: "March 2026", readTime: "5 min read", category: "By Budget" },
      { tags: ["Low risk", "Mileage guide"], headline: "What mileage should I avoid on a diesel BMW?", desc: "DPF failures spike after 90k — here's what the data says", date: "February 2026", readTime: "4 min read", category: "By Mileage" },
      { tags: ["Seasonal"], headline: "Spring 2026 used car market — what buyers are searching", desc: "Trending makes, average mileage and price expectations", date: "April 2026", readTime: "3 min read", category: "Seasonal" },
      { tags: ["MOT data", "Compare"], headline: "Ford Fiesta vs Vauxhall Corsa — which is more reliable?", desc: "Head-to-head from 9,400 combined WorthCar searches", date: "March 2026", readTime: "5 min read", category: "By Model" },
      { tags: ["Mileage guide"], headline: "Is high mileage always bad? What the MOT data actually shows", desc: "Some high-mileage cars pass more reliably than low-mileage ones", date: "February 2026", readTime: "4 min read", category: "By Mileage" },
      { tags: ["High demand", "MOT data"], headline: "The used cars with the worst MOT fail rates in 2026", desc: "Brands and models buyers should approach with caution", date: "January 2026", readTime: "6 min read", category: "By Model" },
      { tags: ["Buyer tips"], headline: "How to use MOT history to spot a hidden lemon", desc: "The 5 warning signs in a vehicle's MOT record", date: "March 2026", readTime: "4 min read", category: "By Model" },
      { tags: ["Trending", "MOT data"], headline: "Best used family SUVs for reliability under £15,000", desc: "Based on real WorthCar searches from the last 90 days", date: "April 2026", readTime: "7 min read", category: "By Budget" },
    ],
    mostRead: [
      { title: "Is a VW Golf worth buying at 70,000 miles?", readTime: "6 min" },
      { title: "The 5 most reliable used cars under £10,000", readTime: "5 min" },
      { title: "What mileage to avoid on a diesel BMW?", readTime: "4 min" },
      { title: "Ford Fiesta vs Vauxhall Corsa reliability", readTime: "5 min" },
      { title: "How to spot a hidden lemon from MOT history", readTime: "4 min" },
    ],
  },
};