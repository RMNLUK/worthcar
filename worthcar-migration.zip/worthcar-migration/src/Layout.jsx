import React from "react";
import { Link } from "react-router-dom";
import CookieConsent from "@/components/CookieConsent";
import { createPageUrl } from "@/utils";

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-white">
      {/* Global header */}
      <header className="bg-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center">
          <div className="flex items-center gap-6">
            <Link
              to={createPageUrl("Home")}
              className="flex items-center gap-2 text-slate-900 hover:text-amber-600 transition-colors"
            >
              <img
                src="/wclogo.png"
                alt="WorthCar logo"
                className="w-10 h-10 object-contain"
              />
              <span className="font-bold text-base tracking-tight">WorthCar.co.uk</span>
            </Link>
            <Link to="/insights/market-pulse" className="text-sm text-slate-600 hover:text-amber-600 transition-colors font-medium">
              Insights
            </Link>
          </div>
        </div>
      </header>
      {children}
      <CookieConsent />
    </div>
  );
}