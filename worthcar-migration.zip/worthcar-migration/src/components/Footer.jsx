import React from "react";
import { Link } from "react-router-dom";

const LINKS = [
  { label: "Terms of Use", to: "/TermsOfUse" },
  { label: "Privacy Policy", to: "/PrivacyPolicy" },
  { label: "Cookie Policy", to: "/CookiePolicy" },
  { label: "Disclaimer", to: "/Disclaimer" },
  { label: "Data Sources & Accuracy", to: "/DataSources" },
  { label: "Affiliate Disclosure", to: "/AffiliateDisclosure" },
  { label: "Contact", to: "/Contact" },
];

export default function Footer() {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 mb-4">
        {LINKS.map(l => (
          <Link key={l.to} to={l.to} className="text-xs text-slate-400 hover:text-amber-600 transition-colors">
            {l.label}
          </Link>
        ))}
      </div>
      <p className="text-xs text-slate-400 mb-1">© 2026 WorthCar.co.uk</p>
      <p className="text-xs text-slate-400">Vehicle and MOT data provided by the DVLA and DVSA.</p>
      <p className="text-xs text-slate-400 mt-1">© Crown copyright and database rights 2026. Contains public sector information licensed under the <a href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/" target="_blank" rel="noopener noreferrer" className="text-slate-500 hover:text-slate-600 underline">Open Government Licence v3.0</a>.</p>
    </div>
  );
}