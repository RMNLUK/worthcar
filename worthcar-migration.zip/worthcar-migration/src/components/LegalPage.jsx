import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, ChevronUp, AlertTriangle } from "lucide-react";
import Footer from "@/components/Footer";

function Callout({ children }) {
  return (
    <div className="flex gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 my-4">
      <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-500" />
      <p>{children}</p>
    </div>
  );
}

function AccordionItem({ title, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-slate-100">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-4 text-left text-sm font-semibold text-slate-800 hover:text-amber-600 transition-colors"
      >
        {title}
        {open ? <ChevronUp className="w-4 h-4 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 flex-shrink-0" />}
      </button>
      {open && <div className="pb-4 text-sm text-slate-600 leading-relaxed">{children}</div>}
    </div>
  );
}

export { Callout, AccordionItem };

export default function LegalPage({ title, subtitle, email, emailLabel = "Questions?", children }) {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav — matches site header */}
      <header className="bg-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-6">
          <Link to="/" className="flex items-center gap-2 text-slate-900 hover:text-amber-600 transition-colors">
            <img
              src="/wclogo.png"
              alt="WorthCar logo"
              className="w-10 h-10 object-contain"
            />
            <span className="font-bold text-base tracking-tight">WorthCar.co.uk</span>
          </Link>
          <span className="text-slate-300">|</span>
          <span className="text-sm text-slate-500">{title}</span>
        </div>
      </header>

      {/* Hero */}
      <div className="border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-5 py-12">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900">{title}</h1>
          {subtitle && <p className="mt-2 text-sm text-slate-500">{subtitle}</p>}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-5 py-10">
        {children}
      </div>

      <Footer />
    </div>
  );
}