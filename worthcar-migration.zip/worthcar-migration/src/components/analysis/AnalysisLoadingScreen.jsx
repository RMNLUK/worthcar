import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FileSearch, Database, Brain, CheckCircle2, Loader2 } from "lucide-react";

const STEPS = [
  { id: 1, label: "Reading registration", icon: FileSearch, duration: 800 },
  { id: 2, label: "Fetching MOT history", icon: Database, duration: 2000 },
  { id: 3, label: "Analysing maintenance patterns", icon: Brain, duration: 3000 },
  { id: 4, label: "Generating buyer guidance", icon: Brain, duration: 2000 },
];

export default function AnalysisLoadingScreen({ registration, currentStep }) {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md"
      >
        {/* Plate display */}
        <div className="flex items-center justify-center mb-10">
          <div className="flex items-stretch rounded-lg overflow-hidden border-2 border-slate-200 bg-white shadow-md">
            <div className="w-2.5 bg-amber-400" />
            <div className="px-6 py-3">
              <span className="text-2xl font-bold tracking-widest text-slate-900">
                {registration}
              </span>
            </div>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-4">
          {STEPS.map((step, index) => {
            const StepIcon = step.icon;
            const isActive = currentStep === step.id;
            const isComplete = currentStep > step.id;
            const isPending = currentStep < step.id;

            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-500 ${
                  isActive
                    ? "bg-amber-50 border border-amber-200 shadow-sm"
                    : isComplete
                    ? "bg-emerald-50 border border-emerald-100"
                    : "bg-slate-50 border border-transparent"
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-500 ${
                    isActive
                      ? "bg-amber-400 text-white"
                      : isComplete
                      ? "bg-emerald-500 text-white"
                      : "bg-slate-200 text-slate-400"
                  }`}
                >
                  {isComplete ? (
                    <CheckCircle2 className="w-5 h-5" />
                  ) : isActive ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <StepIcon className="w-5 h-5" />
                  )}
                </div>
                <span
                  className={`text-base font-medium transition-colors duration-300 ${
                    isActive
                      ? "text-slate-900"
                      : isComplete
                      ? "text-emerald-700"
                      : "text-slate-400"
                  }`}
                >
                  {step.label}
                </span>
              </motion.div>
            );
          })}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-sm text-slate-400 mt-8"
        >
          This usually takes 10–20 seconds
        </motion.p>
      </motion.div>
    </div>
  );
}