import { base44 } from "@/api/base44Client";

/**
 * Extracts registration text from an uploaded image using Claude vision.
 * Sends image as base64 to /api/extractRegistration
 */
export async function extractRegistrationFromImage(file) {
  // Convert file to base64
  const base64 = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const base64Data = dataUrl.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

  const res = await fetch('/api/extractRegistration', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64: base64, mimeType: file.type || 'image/jpeg' }),
  });

  if (!res.ok) throw new Error('Failed to extract registration from image');
  return res.json();
}

/**
 * Runs full MOT analysis using the analyzeMotHistory backend function
 */
export async function runMotAnalysis(registration, userNotes = '') {
  try {
    const response = await base44.functions.invoke('analyzeMotHistory', {
      registration,
      userNotes
    });

    const result = response.data;
    console.log("runMotAnalysis response:", result);

    if (result.status === 'no_mot_history') {
      return {
        success: true,
        dataFound: false,
        noMotHistory: true,
        vehicle: {
          ...result.vehicle,
          registration: result.registration,
        },
        motTests: [],
        metrics: null,
        analysis: null,
      };
    }

    if (result.status === 'error') {
      if (result.error.includes('not found')) {
        return { error: "no_record", message: "Registration not found in MOT database." };
      }
      if (result.error.includes('DVSA') || result.error.includes('authenticate')) {
        return { error: "api_error", message: "Unable to connect to MOT data service. Please try again shortly." };
      }
      return { error: "api_error", message: result.error };
    }

    if (result.status === 'partial_success') {
      const metrics = computeDerivedMetrics(result.raw_mot_history);
      const analysis = mapAiAnalysisToFrontend(null, metrics);
      return {
        success: true,
        dataFound: true,
        vehicle: { ...result.vehicle, registration: result.registration },
        motTests: result.raw_mot_history,
        metrics,
        analysis,
      };
    }

    if (result.status === 'success') {
      const metrics = computeDerivedMetrics(result.raw_mot_history);
      const analysis = mapAiAnalysisToFrontend(result.ai_analysis, metrics);
      return {
        success: true,
        dataFound: true,
        vehicle: { ...result.vehicle, registration: result.registration },
        motTests: result.raw_mot_history,
        metrics,
        analysis,
      };
    }

    return { error: "api_error", message: "Unexpected response from analysis service." };
  } catch (error) {
    console.error("Error in runMotAnalysis:", error);
    if (error.response?.status === 404) {
      return { error: "no_record", message: "No MOT history found for this registration." };
    }
    if (error.response?.status) {
      const errorData = error.response?.data;
      if (errorData?.error) return { error: "api_error", message: errorData.error };
      return { error: "api_error", message: `Service error (${error.response.status})` };
    }
    return { error: "api_error", message: "Failed to analyze MOT history." };
  }
}

function computeDerivedMetrics(motTests) {
  if (!motTests || motTests.length === 0) {
    return { totalTests: 0, totalPasses: 0, totalFails: 0, failRate: 0, totalAdvisories: 0, totalDangerous: 0, avgMilesPerYear: 0, latestMileage: 0, firstMileage: 0, mileageAnomalyFlag: false, maintenanceScore: 50, riskScore: 50 };
  }
  const sorted = [...motTests].sort((a, b) => new Date(a.completedDate) - new Date(b.completedDate));
  const totalTests = sorted.length;
  const totalPasses = sorted.filter((t) => (t.testResult || "").toUpperCase().includes("PASS")).length;
  const totalFails = totalTests - totalPasses;
  const failRate = totalTests > 0 ? (totalFails / totalTests) * 100 : 0;
  let totalAdvisories = 0, totalDangerous = 0;
  sorted.forEach((t) => {
    (t.defects || []).forEach((d) => {
      const dtype = (d.type || "").toLowerCase();
      if (dtype === "advisory") totalAdvisories++;
      if (dtype === "dangerous") totalDangerous++;
    });
  });
  const mileages = sorted.filter((t) => t.odometerValue > 0);
  const latestMileage = mileages.length > 0 ? mileages[mileages.length - 1].odometerValue : 0;
  const firstMileage = mileages.length > 0 ? mileages[0].odometerValue : 0;
  let avgMilesPerYear = 0, mileageAnomalyFlag = false;
  if (mileages.length >= 2) {
    const firstDate = new Date(mileages[0].completedDate);
    const lastDate = new Date(mileages[mileages.length - 1].completedDate);
    const years = (lastDate - firstDate) / (365.25 * 24 * 60 * 60 * 1000);
    if (years > 0) avgMilesPerYear = Math.round((latestMileage - firstMileage) / years);
    for (let i = 1; i < mileages.length; i++) {
      if (mileages[i].odometerValue < mileages[i - 1].odometerValue) { mileageAnomalyFlag = true; break; }
    }
  }
  let maintenanceScore = 70, riskScore = 30;
  maintenanceScore -= failRate * 0.5; riskScore += failRate * 0.4;
  maintenanceScore -= totalDangerous * 10; riskScore += totalDangerous * 12;
  const avgAdvisoriesPerTest = totalAdvisories / Math.max(totalTests, 1);
  if (avgAdvisoriesPerTest > 3) { maintenanceScore -= 10; riskScore += 8; }
  if (sorted.length >= 3) {
    const recentTests = sorted.slice(-3);
    const recentDefects = recentTests.reduce((sum, t) => sum + (t.defects || []).length, 0);
    const olderTests = sorted.slice(0, -3);
    const olderDefects = olderTests.reduce((sum, t) => sum + (t.defects || []).length, 0) / Math.max(olderTests.length, 1);
    if (recentDefects / 3 < olderDefects) { maintenanceScore += 10; riskScore -= 8; }
  }
  if (mileageAnomalyFlag) { riskScore += 15; maintenanceScore -= 10; }
  return { totalTests, totalPasses, totalFails, failRate, totalAdvisories, totalDangerous, avgMilesPerYear, latestMileage, firstMileage, mileageAnomalyFlag, maintenanceScore: Math.max(0, Math.min(100, Math.round(maintenanceScore))), riskScore: Math.max(0, Math.min(100, Math.round(riskScore))) };
}

function mapAiAnalysisToFrontend(aiAnalysis, metrics) {
  if (!aiAnalysis) {
    return { summary: "Analysis unavailable - please review the MOT history manually.", top_insights: ["AI analysis was unavailable for this vehicle"], maintenance_verdict: "Unable to determine", buy_recommendation: "Seek professional inspection", seller_requirements: [], pricing_guidance: { label: "Unable to estimate", estimated_range_low: 0, estimated_range_high: 0, confidence_note: "AI analysis unavailable" }, risk_flags: [], scorecard: { maintenance_score: metrics.maintenanceScore, risk_score: metrics.riskScore, buying_confidence_score: 50 } };
  }
  const marketValue = aiAnalysis.market_value_estimate;
  const privateSale = marketValue?.private_sale_price_gbp;
  return { summary: aiAnalysis.plain_english_summary || "", top_insights: aiAnalysis.timeline_insights || [], maintenance_verdict: aiAnalysis.maintenance_assessment?.rating || "Unknown", buy_recommendation: aiAnalysis.rcie?.overall_recommendation || determineBuyRecommendation(aiAnalysis), seller_requirements: aiAnalysis.buyer_risks || [], pricing_guidance: { label: aiAnalysis.value_summary || "AI Market Value Estimate", estimated_range_low: privateSale?.low || 0, estimated_range_high: privateSale?.high || 0, confidence_note: aiAnalysis.buyer_note || "Based on MOT history, age, and mileage." }, risk_flags: aiAnalysis.buyer_risks || [], scorecard: { maintenance_score: metrics.maintenanceScore, risk_score: metrics.riskScore, buying_confidence_score: calculateBuyingConfidence(aiAnalysis, metrics) } };
}

function determineBuyRecommendation(aiAnalysis) {
  const rating = aiAnalysis.maintenance_assessment?.rating?.toLowerCase() || '';
  const hasRisks = (aiAnalysis.buyer_risks || []).length > 0;
  if (rating.includes('proactive')) return hasRisks ? 'Buy with caution' : 'Strong buy candidate';
  if (rating.includes('neglect')) return 'Avoid unless heavily discounted';
  return 'Buy with caution';
}

function calculateBuyingConfidence(aiAnalysis, metrics) {
  let confidence = 50;
  const rating = aiAnalysis.maintenance_assessment?.rating?.toLowerCase() || '';
  if (rating.includes('proactive')) confidence += 20;
  if (rating.includes('neglect')) confidence -= 30;
  confidence -= (aiAnalysis.buyer_risks || []).length * 5;
  confidence += (aiAnalysis.positive_signs || []).length * 3;
  return Math.max(0, Math.min(100, confidence));
}
