import React from "react";
import { X, Loader2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

function ScoreBadge({ label, value, invert = false }) {
  const pct = Math.min(100, Math.max(0, value));
  const color = invert
    ? pct < 33 ? "text-green-600 bg-green-50" : pct < 66 ? "text-amber-600 bg-amber-50" : "text-red-600 bg-red-50"
    : pct > 66 ? "text-green-600 bg-green-50" : pct > 33 ? "text-amber-600 bg-amber-50" : "text-red-600 bg-red-50";

  return (
    <div className={`rounded-lg p-3 text-center ${color}`}>
      <div className="text-2xl font-bold">{pct}</div>
      <div className="text-xs font-medium mt-0.5">{label}</div>
    </div>
  );
}

function Row({ label, value, highlight }) {
  return (
    <div className={`py-2 border-b border-slate-100 last:border-0 ${highlight ? "bg-amber-50 -mx-4 px-4 rounded" : ""}`}>
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-sm font-semibold text-slate-900 mt-0.5">{value || "—"}</div>
    </div>
  );
}

export default function CompareVehicleColumn({ reg, result, loading, onRemove }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
      {/* Header */}
      <div className="bg-slate-900 text-white px-4 py-3 flex items-center justify-between">
        <span className="font-mono font-bold text-sm tracking-widest">{reg}</span>
        <button onClick={onRemove} className="text-slate-400 hover:text-white transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      {loading && (
        <div className="flex-1 flex items-center justify-center py-16 text-slate-400">
          <Loader2 className="w-6 h-6 animate-spin mr-2" />
          <span className="text-sm">Analysing…</span>
        </div>
      )}

      {!loading && !result && (
        <div className="flex-1 flex items-center justify-center py-16 text-slate-400 text-sm">
          Pending…
        </div>
      )}

      {!loading && result?.error && (
        <div className="flex-1 flex flex-col items-center justify-center py-12 px-4 text-center text-slate-500">
          <AlertTriangle className="w-8 h-8 text-amber-400 mb-2" />
          <p className="text-sm">Could not load data for this vehicle.</p>
        </div>
      )}

      {!loading && result && !result.error && (
        <div className="p-4 flex flex-col gap-4">
          {/* Vehicle identity */}
          <div>
            <div className="font-semibold text-slate-900">
              {result.vehicle?.make} {result.vehicle?.model}
            </div>
            {result.vehicle?.yearOfManufacture && (
              <div className="text-xs text-slate-500">{result.vehicle.yearOfManufacture} · {result.vehicle?.colour}</div>
            )}
          </div>

          {/* Scores */}
          <div className="grid grid-cols-3 gap-2">
            <ScoreBadge label="Maintenance" value={result.metrics?.maintenanceScore} />
            <ScoreBadge label="Risk" value={result.metrics?.riskScore} invert />
            <ScoreBadge label="Confidence" value={result.analysis?.scorecard?.buying_confidence_score} />
          </div>

          {/* MOT stats */}
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">MOT History</div>
            <Row label="Total Tests" value={result.metrics?.totalTests} />
            <Row label="Passes" value={result.metrics?.totalPasses} />
            <Row label="Fails" value={result.metrics?.totalFails} highlight={result.metrics?.totalFails > 2} />
            <Row label="Advisories" value={result.metrics?.totalAdvisories} highlight={result.metrics?.totalAdvisories > 5} />
            <Row label="Dangerous Items" value={result.metrics?.totalDangerous} highlight={result.metrics?.totalDangerous > 0} />
          </div>

          {/* Mileage */}
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Mileage</div>
            <Row label="Latest Mileage" value={result.metrics?.latestMileage ? result.metrics.latestMileage.toLocaleString() + " mi" : null} />
            <Row label="Avg / Year" value={result.metrics?.avgMilesPerYear ? result.metrics.avgMilesPerYear.toLocaleString() + " mi" : null} />
            {result.metrics?.mileageAnomalyFlag && (
              <div className="mt-2 text-xs text-red-600 bg-red-50 rounded p-2 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Mileage anomaly detected
              </div>
            )}
          </div>

          {/* AI Value */}
          {result.analysis?.pricing_guidance?.estimated_range_low > 0 && (
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
              <div className="text-xs font-semibold text-amber-700 uppercase tracking-wide mb-1">AI Value Estimate</div>
              <div className="text-lg font-bold text-amber-800">
                £{result.analysis.pricing_guidance.estimated_range_low.toLocaleString()} – £{result.analysis.pricing_guidance.estimated_range_high.toLocaleString()}
              </div>
              {result.analysis.pricing_guidance.confidence_note && (
                <p className="text-xs text-amber-600 mt-1">{result.analysis.pricing_guidance.confidence_note}</p>
              )}
            </div>
          )}

          {/* Buy recommendation */}
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Recommendation</div>
            <div className="text-sm font-semibold text-slate-800">{result.analysis?.buy_recommendation || "—"}</div>
          </div>

          {/* Top insights */}
          {result.analysis?.top_insights?.length > 0 && (
            <div>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Key Insights</div>
              <ul className="space-y-1">
                {result.analysis.top_insights.slice(0, 3).map((insight, i) => (
                  <li key={i} className="text-xs text-slate-600 flex gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>
                    <span>{insight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}