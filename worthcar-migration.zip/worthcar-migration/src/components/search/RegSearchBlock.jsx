/**
 * RegSearchBlock — shared dark-navy search panel.
 * Drop this anywhere a reg-plate search is needed.
 * Reuses the existing RegistrationInput + OcrVerificationModal.
 */
import React, { useState } from "react";
import { createPageUrl } from "@/utils";
import RegistrationInput from "@/components/search/RegistrationInput";
import OcrVerificationModal from "@/components/search/OcrVerificationModal";
import { extractRegistrationFromImage } from "@/components/analysis/analysisService";

const TRUST_SIGNALS = ["Free to use", "Instant results", "Full MOT history", "No email needed"];

export default function RegSearchBlock({ eyebrow, headline, subheading, showTrustSignals = true }) {
  const [isProcessingOcr, setIsProcessingOcr] = useState(false);
  const [ocrResult, setOcrResult] = useState(null);
  const [showOcrModal, setShowOcrModal] = useState(false);

  const handleManualSubmit = (registration) => {
    window.location.href = createPageUrl("Results") + `?reg=${encodeURIComponent(registration)}`;
  };

  const handlePhotoCapture = async (file) => {
    setIsProcessingOcr(true);
    const result = await extractRegistrationFromImage(file);
    setOcrResult(result);
    setShowOcrModal(true);
    setIsProcessingOcr(false);
  };

  const handleOcrConfirm = (registration, wasCorrected) => {
    setShowOcrModal(false);
    const params = new URLSearchParams({
      reg: registration, method: "ocr",
      corrected: wasCorrected ? "1" : "0",
      original: ocrResult?.raw_text || "",
    });
    window.location.href = createPageUrl("Results") + `?${params.toString()}`;
  };

  return (
    <>
      <div className="w-full border-b border-slate-100">
        <div className="max-w-3xl mx-auto px-4 pt-12 pb-7 text-center">
          {eyebrow && (
            <p className="text-xs font-medium uppercase tracking-widest mb-3 text-slate-400" style={{ letterSpacing: "0.06em" }}>
              {eyebrow}
            </p>
          )}
          {headline && (
            <h2 className="font-medium text-slate-900 mb-2 text-2xl md:text-3xl" style={{ lineHeight: 1.3 }}>
              {headline}
            </h2>
          )}
          {subheading && (
            <p className="text-sm mb-6 text-slate-500" style={{ lineHeight: 1.6 }}>
              {subheading}
            </p>
          )}
          <div className="max-w-xl mx-auto">
            <RegistrationInput
              onSubmit={handleManualSubmit}
              onPhotoCapture={handlePhotoCapture}
              isLoading={isProcessingOcr}
            />
          </div>
          {isProcessingOcr && (
            <p className="text-xs mt-3 text-slate-400">Reading number plate…</p>
          )}
          {showTrustSignals && (
            <div className="flex flex-wrap justify-center gap-x-4 gap-y-1.5 mt-5 pb-5">
              {TRUST_SIGNALS.map((t) => (
                <span key={t} className="flex items-center gap-1.5 text-xs text-slate-400">
                  <span className="inline-block w-1.5 h-1.5 rounded-full flex-shrink-0 bg-slate-300" />
                  {t}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      <OcrVerificationModal
        open={showOcrModal}
        onClose={() => setShowOcrModal(false)}
        extractedText={ocrResult?.registration || ""}
        confidence={ocrResult?.confidence ?? null}
        onConfirm={handleOcrConfirm}
        onRescan={() => { setShowOcrModal(false); setOcrResult(null); }}
        isLoading={false}
      />
    </>
  );
}