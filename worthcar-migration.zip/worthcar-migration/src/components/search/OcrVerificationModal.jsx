import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Check, RotateCcw, AlertTriangle, Camera } from "lucide-react";
import { motion } from "framer-motion";

const UK_PLATE_REGEX = /^[A-Z]{2}[0-9]{2}\s?[A-Z]{3}$/i;

export default function OcrVerificationModal({
  open,
  onClose,
  extractedText,
  confidence,
  onConfirm,
  onRescan,
  isLoading,
}) {
  const [editedReg, setEditedReg] = useState(extractedText || "");
  const isLowConfidence = confidence !== null && confidence < 70;
  const isValid = UK_PLATE_REGEX.test(editedReg.replace(/\s/g, ""));

  React.useEffect(() => {
    if (extractedText) {
      setEditedReg(extractedText);
    }
  }, [extractedText]);

  const formatReg = (value) => {
    const cleaned = value.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (cleaned.length > 4) {
      return cleaned.slice(0, 4) + " " + cleaned.slice(4, 7);
    }
    return cleaned;
  };

  const handleChange = (e) => {
    const formatted = formatReg(e.target.value);
    if (formatted.replace(/\s/g, "").length <= 7) {
      setEditedReg(formatted);
    }
  };

  const getConfidenceColor = () => {
    if (confidence >= 85) return "bg-emerald-100 text-emerald-700 border-emerald-200";
    if (confidence >= 70) return "bg-amber-100 text-amber-700 border-amber-200";
    return "bg-red-100 text-red-700 border-red-200";
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-sm rounded-2xl border-0 shadow-2xl p-0 overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 px-6 py-5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-amber-400 flex items-center justify-center">
            <Camera className="w-5 h-5 text-slate-900" />
          </div>
          <div>
            <h2 className="text-white font-bold text-lg leading-tight">Verify Registration</h2>
            <p className="text-slate-400 text-xs">Check the plate looks correct</p>
          </div>
        </div>

        <div className="px-6 py-5 space-y-5 bg-white">
          {/* Confidence badge */}
          {confidence !== null && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Scan confidence:</span>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${
                confidence >= 85 ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
                confidence >= 70 ? "bg-amber-50 text-amber-700 border-amber-200" :
                "bg-red-50 text-red-700 border-red-200"
              }`}>{confidence}%</span>
              {isLowConfidence && (
                <span className="flex items-center gap-1 text-amber-600 text-xs">
                  <AlertTriangle className="w-3 h-3" /> Please check carefully
                </span>
              )}
            </div>
          )}

          {/* UK plate styled input */}
          <div
            className="rounded-md shadow-lg mx-auto"
            style={{
              background: "#f5c518",
              border: "3px solid #1a1a1a",
              padding: "6px",
              display: "grid",
              gridTemplateColumns: "44px 1fr",
              alignItems: "center",
            }}
          >
            <div
              className="flex flex-col items-center justify-center rounded-sm"
              style={{ background: "#003399", alignSelf: "stretch", padding: "4px 0" }}
            >
              <span className="text-white font-extrabold" style={{ fontSize: 11, letterSpacing: 0.5 }}>GB</span>
            </div>
            <input
              value={editedReg}
              onChange={handleChange}
              maxLength={8}
              autoComplete="off"
              spellCheck={false}
              className="bg-transparent border-none outline-none text-center font-extrabold text-slate-900 w-full"
              style={{
                fontFamily: "'UKNumberPlate', 'Charles Wright', 'Arial Black', sans-serif",
                fontSize: "clamp(22px, 6vw, 34px)",
                letterSpacing: "0.12em",
                caretColor: "#1a1a1a",
              }}
            />
          </div>

          {!isValid && editedReg.length > 3 && (
            <p className="text-xs text-red-500 text-center">
              Doesn't look like a valid UK registration
            </p>
          )}

          {/* Buttons */}
          <div className="flex gap-3 pt-1">
            <Button
              variant="outline"
              onClick={onRescan}
              disabled={isLoading}
              className="flex-1 border-2 border-slate-200 hover:border-amber-400 hover:bg-amber-50 text-slate-700 rounded-xl font-semibold"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Rescan
            </Button>
            <Button
              onClick={() => onConfirm(editedReg.toUpperCase(), editedReg !== extractedText)}
              disabled={!isValid || isLoading}
              className="flex-1 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold"
            >
              <Check className="w-4 h-4 mr-2" />
              Confirm
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}