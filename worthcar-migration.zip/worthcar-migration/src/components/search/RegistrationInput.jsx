import React, { useState, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Camera, Search, Upload, X } from "lucide-react";
import { motion } from "framer-motion";

const UK_PLATE_REGEX = /^[A-Z0-9]{2,7}$/i;

export default function RegistrationInput({ onSubmit, onPhotoCapture, isLoading }) {
  const [reg, setReg] = useState("");
  const [error, setError] = useState("");
  const fileInputRef = useRef(null);
  const uploadInputRef = useRef(null);

  const formatReg = (value) => {
    const cleaned = value.toUpperCase().replace(/[^A-Z0-9]/g, "");
    // Only auto-space modern format plates (7 chars: 2L+2N+3L)
    if (cleaned.length > 4 && /^[A-Z]{2}[0-9]{2}/.test(cleaned)) {
      return cleaned.slice(0, 4) + " " + cleaned.slice(4, 7);
    }
    return cleaned;
  };

  const handleChange = (e) => {
    const formatted = formatReg(e.target.value);
    if (formatted.replace(/\s/g, "").length <= 7) {
      setReg(formatted);
      setError("");
    }
  };

  const handleSubmit = () => {
    const cleaned = reg.replace(/\s/g, "");
    if (!UK_PLATE_REGEX.test(cleaned)) {
      setError("Please enter a valid UK registration (e.g. AB12 CDE)");
      return;
    }
    onSubmit(reg.toUpperCase());
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleSubmit();
  };

  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      onPhotoCapture(file);
    }
    e.target.value = "";
  };

  return (
    <div className="w-full max-w-lg mx-auto space-y-6">
      {/* Registration plate input - styled as UK plate */}
      <div className="relative flex flex-col items-center">
        <div
          className="rounded-md shadow-xl"
          style={{
            background: "#f5c518",
            border: "3px solid #1a1a1a",
            padding: "6px",
            minWidth: 280,
            maxWidth: 360,
            width: "100%",
            display: "grid",
            gridTemplateColumns: "44px 1fr 44px",
            alignItems: "center",
          }}
        >
          {/* Blue EU strip on the left */}
          <div
            className="flex flex-col items-center justify-center rounded-sm"
            style={{
              background: "#003399",
              alignSelf: "stretch",
              padding: "4px 0",
            }}
          >
            <span className="text-white font-extrabold" style={{ fontSize: 11, letterSpacing: 0.5 }}>
              GB
            </span>
          </div>

          {/* Plate text input — centre column */}
          <input
            value={reg}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            placeholder="ENTER REG"
            maxLength={8}
            disabled={isLoading}
            autoComplete="off"
            spellCheck={false}
            className="bg-transparent border-none outline-none text-center font-extrabold text-slate-900 placeholder-slate-400 w-full"
            style={{
              fontFamily: "'UKNumberPlate', 'Charles Wright', 'Arial Black', sans-serif",
              fontSize: "clamp(20px, 6vw, 32px)",
              letterSpacing: "0.12em",
              caretColor: "#1a1a1a",
            }}
          />

          {/* Right column — clear button */}
          <div className="flex items-center justify-center">
            {reg && (
              <button
                onClick={() => { setReg(""); setError(""); }}
                className="text-slate-600 hover:text-slate-900 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-red-500 text-sm mt-2"
          >
            {error}
          </motion.p>
        )}
      </div>

      {/* Action buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          onClick={handleSubmit}
          disabled={!reg.trim() || isLoading}
          className="flex-1 h-13 text-base font-semibold bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition-all duration-200 shadow-md hover:shadow-lg"
        >
          <Search className="w-5 h-5 mr-2" />
          Check MOT History
        </Button>
        <Button
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          disabled={isLoading}
          className="flex-1 h-13 text-base font-semibold border-2 border-slate-200 hover:border-amber-400 hover:bg-amber-50 text-slate-700 rounded-xl transition-all duration-200"
        >
          <Camera className="w-5 h-5 mr-2" />
          Take Reg Photo
        </Button>
      </div>

      {/* Secondary: upload from gallery */}
      <div className="text-center pb-1">
        <button
          onClick={() => uploadInputRef.current?.click()}
          disabled={isLoading}
          className="text-sm text-slate-500 hover:text-amber-600 transition-colors inline-flex items-center gap-1.5 disabled:opacity-40 underline underline-offset-2 decoration-dotted"
        >
          <Upload className="w-3.5 h-3.5" />
          Upload photo from gallery
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
      />
      <input
        ref={uploadInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}