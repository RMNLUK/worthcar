import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Save, RotateCcw, Clock, CheckCircle, ChevronDown, ChevronUp } from "lucide-react";

const DEFAULT_PROMPT = `You are a UK used-car pricing analyst. Estimate market value for this vehicle based on MOT history.

ANALYZE: Age, mileage, MOT pass/fail pattern, defects, maintenance quality.

PRICE LOGIC:
- Adjust down for: neglect, failures, corrosion, suspension/brake issues, near-term costs
- Adjust up for: clean passes, proactive maintenance, stable mileage
- Dealer > Private > Trade-in prices

RCIE FRAMEWORK:
R (Risk): LOW/MEDIUM/HIGH based on MOT issues
C (Condition): STRONG/AVERAGE/WEAK based on maintenance
I (Investability): HIGH/MEDIUM/LOW for buyer value
E (Exit): STRONG/MODERATE/WEAK for resale
Overall: STRONG BUY | BUY WITH CAUTION | PRICE SENSITIVE ONLY | AVOID UNLESS HEAVILY DISCOUNTED

Return JSON only.`;

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleString("en-GB", {
    day: "2-digit", month: "short", year: "numeric",
    hour: "2-digit", minute: "2-digit"
  });
}

export default function MotMasterPromptModule() {
  const [versions, setVersions] = useState([]);
  const [activeVersion, setActiveVersion] = useState(null);
  const [newPrompt, setNewPrompt] = useState('');
  const [changeNotes, setChangeNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [reverting, setReverting] = useState(null);

  const loadVersions = async () => {
    const records = await base44.entities.PromptVersion.list('-version_number', 50);
    setVersions(records);
    const active = records.find(r => r.is_active);
    setActiveVersion(active || null);
    setNewPrompt(active?.prompt_text || DEFAULT_PROMPT);
    setLoading(false);
  };

  useEffect(() => { loadVersions(); }, []);

  const handleSave = async () => {
    if (!newPrompt.trim()) return;
    setSaving(true);

    // Deactivate all current active versions
    const currentActive = versions.filter(v => v.is_active);
    await Promise.all(currentActive.map(v => base44.entities.PromptVersion.update(v.id, { is_active: false })));

    // Also sync to AppConfig for the analysis service
    const configs = await base44.entities.AppConfig.filter({ key: "analysis_prompt" });
    if (configs.length > 0) {
      await base44.entities.AppConfig.update(configs[0].id, { value: newPrompt });
    } else {
      await base44.entities.AppConfig.create({ key: "analysis_prompt", value: newPrompt, description: "AI vehicle analysis system prompt" });
    }

    // Create new version
    const nextNumber = versions.length > 0 ? Math.max(...versions.map(v => v.version_number)) + 1 : 1;
    await base44.entities.PromptVersion.create({
      version_number: nextNumber,
      prompt_text: newPrompt,
      change_notes: changeNotes.trim() || null,
      is_active: true
    });

    setChangeNotes('');
    await loadVersions();
    setSaving(false);
  };

  const handleRevert = async (version) => {
    setReverting(version.id);

    const currentActive = versions.filter(v => v.is_active);
    await Promise.all(currentActive.map(v => base44.entities.PromptVersion.update(v.id, { is_active: false })));

    const configs = await base44.entities.AppConfig.filter({ key: "analysis_prompt" });
    if (configs.length > 0) {
      await base44.entities.AppConfig.update(configs[0].id, { value: version.prompt_text });
    } else {
      await base44.entities.AppConfig.create({ key: "analysis_prompt", value: version.prompt_text, description: "AI vehicle analysis system prompt" });
    }

    const nextNumber = Math.max(...versions.map(v => v.version_number)) + 1;
    await base44.entities.PromptVersion.create({
      version_number: nextNumber,
      prompt_text: version.prompt_text,
      change_notes: `Reverted to v${version.version_number}`,
      is_active: true
    });

    await loadVersions();
    setReverting(null);
  };

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">MOT Data Master Prompt</h2>
      <p className="text-sm text-slate-500 mb-6">
        Manage the AI system prompt used for every vehicle analysis. Each save creates a timestamped version record. Previous versions are read-only and can be restored.
      </p>

      {/* Editor */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-8">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-slate-800">Active Prompt</p>
            {activeVersion && (
              <p className="text-xs text-slate-400 mt-0.5">
                v{activeVersion.version_number} · Saved {formatDate(activeVersion.created_date)}
              </p>
            )}
          </div>
          <span className="text-xs text-slate-400">{newPrompt.length} chars</span>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" />
          </div>
        ) : (
          <textarea
            value={newPrompt}
            onChange={e => setNewPrompt(e.target.value)}
            rows={20}
            className="w-full px-5 py-4 text-sm font-mono text-slate-700 bg-slate-50 resize-none focus:outline-none focus:bg-white transition-colors"
          />
        )}

        <div className="px-5 py-4 border-t border-slate-100 space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">Change Notes (optional)</label>
            <input
              type="text"
              value={changeNotes}
              onChange={e => setChangeNotes(e.target.value)}
              placeholder="e.g. Added stricter mileage anomaly guidance"
              className="w-full border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleSave}
              disabled={saving || loading}
              className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl hover:bg-slate-700 transition-colors disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {saving ? "Saving…" : "Save New Version"}
            </button>
            <button
              onClick={() => setNewPrompt(DEFAULT_PROMPT)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white text-slate-600 text-sm rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
            >
              <RotateCcw className="w-4 h-4" /> Reset to Default
            </button>
          </div>
        </div>
      </div>

      {/* Version History */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-slate-400" /> Version History
        </h3>
        {versions.length === 0 && !loading && (
          <p className="text-sm text-slate-400 text-center py-8">No versions saved yet. Save a prompt to start tracking history.</p>
        )}
        <div className="space-y-2">
          {versions.map(v => (
            <div key={v.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-5 py-3.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {v.is_active && (
                    <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-800">v{v.version_number}</span>
                      {v.is_active && <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-medium">Active</span>}
                    </div>
                    <p className="text-xs text-slate-400">{formatDate(v.created_date)}</p>
                    {v.change_notes && <p className="text-xs text-slate-500 mt-0.5 italic">{v.change_notes}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {!v.is_active && (
                    <button
                      onClick={() => handleRevert(v)}
                      disabled={!!reverting}
                      className="text-xs px-3 py-1.5 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
                    >
                      {reverting === v.id ? "Restoring…" : "Restore"}
                    </button>
                  )}
                  <button
                    onClick={() => setExpandedId(expandedId === v.id ? null : v.id)}
                    className="text-slate-400 hover:text-slate-600 transition-colors"
                  >
                    {expandedId === v.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              {expandedId === v.id && (
                <div className="border-t border-slate-100 px-5 py-4 bg-slate-50">
                  <pre className="text-xs font-mono text-slate-600 whitespace-pre-wrap">{v.prompt_text}</pre>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}