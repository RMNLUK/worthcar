import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Save, Plus, Trash2, Globe, FileText, CheckCircle, XCircle, ChevronDown, ChevronUp } from "lucide-react";

// ─── Tabs ─────────────────────────────────────────────────────────────────────
const TABS = [
  { id: 'overview', label: 'SEO Strategy' },
  { id: 'meta', label: 'Meta Templates' },
  { id: 'quality', label: 'Quality Thresholds' },
  { id: 'editorial', label: 'Editorial Pages' },
  { id: 'sitemap', label: 'Sitemap Rules' },
];

// ─── SEO Strategy Overview ────────────────────────────────────────────────────
function StrategyTab() {
  const sections = [
    {
      title: "Core SEO Rule",
      content: "Every page must help a user: (1) understand MOT history, (2) understand mileage and condition signals, (3) understand price guidance, (4) make a better used-car decision. If a page does not deliver that value → NOINDEX.",
    },
    {
      title: "Page Types & Indexing",
      items: [
        { label: "/check — Search Page", status: "index" },
        { label: "/reg/{REG} — Vehicle Result Page", status: "conditional" },
        { label: "/free-car-valuation-without-email — Editorial", status: "index" },
        { label: "/mot-check-uk — Editorial", status: "index" },
        { label: "/aa-car-valuation-alternative — Comparison", status: "conditional" },
      ],
    },
    {
      title: "Auto-Generation Flow",
      steps: [
        "User enters registration",
        "Normalize & sanitize registration",
        "Query MOT/public data API",
        "Run valuation engine",
        "Generate structured page content blocks",
        "Calculate quality score",
        "Set canonical, robots, title, meta, structured data, sitemap status",
        "Render page — INDEX or NOINDEX based on score",
      ],
    },
    {
      title: "Target Keywords",
      keywords: [
        "free car valuation without email",
        "value my car by registration number",
        "glasses guide car valuation free",
        "aa car valuation",
        "dvla car value",
        "free car valuation uk",
        "MOT check UK",
        "check MOT history",
        "vehicle history check",
        "free car check",
        "check car by registration",
      ],
    },
    {
      title: "Final White-Hat Rule",
      content: "WorthCar must never auto-index pages only because a search happened. Index only when the page is genuinely useful, unique, data-backed, and helpful to users. SEARCH CREATES PAGE — QUALITY DECIDES INDEXING.",
    },
  ];

  const [open, setOpen] = useState(null);

  return (
    <div className="space-y-3">
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-4">
        <p className="text-xs font-bold text-amber-800 uppercase tracking-wide mb-1">Primary Message</p>
        <p className="text-sm text-amber-900 font-semibold">Check any UK car. Read the MOT facts. Understand the price.</p>
        <p className="text-xs text-amber-700 mt-1">Secondary: Free car valuation without email, powered by MOT history and public data.</p>
      </div>

      {sections.map((s, i) => (
        <div key={i} className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <button
            onClick={() => setOpen(open === i ? null : i)}
            className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
          >
            <span className="text-sm font-semibold text-slate-800">{s.title}</span>
            {open === i ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
          </button>
          {open === i && (
            <div className="px-5 pb-5">
              {s.content && <p className="text-sm text-slate-600 leading-relaxed">{s.content}</p>}
              {s.items && (
                <div className="space-y-2">
                  {s.items.map((item, j) => (
                    <div key={j} className="flex items-center gap-3">
                      {item.status === 'index' && <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />}
                      {item.status === 'noindex' && <XCircle className="w-4 h-4 text-red-400 shrink-0" />}
                      {item.status === 'conditional' && <div className="w-4 h-4 rounded-full border-2 border-amber-400 shrink-0" />}
                      <span className="text-sm text-slate-700 font-mono">{item.label}</span>
                    </div>
                  ))}
                </div>
              )}
              {s.steps && (
                <ol className="space-y-1.5">
                  {s.steps.map((step, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                      <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-xs flex items-center justify-center shrink-0 mt-0.5">{j + 1}</span>
                      {step}
                    </li>
                  ))}
                </ol>
              )}
              {s.keywords && (
                <div className="flex flex-wrap gap-2">
                  {s.keywords.map((kw, j) => (
                    <span key={j} className="text-xs bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full font-medium">{kw}</span>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Meta Templates ───────────────────────────────────────────────────────────
const DEFAULT_META = [
  { key: 'vehicle_title', label: 'Vehicle Page Title', value: '{REG} MOT History, Mileage & Estimated Car Value | WorthCar' },
  { key: 'vehicle_desc', label: 'Vehicle Page Description', value: 'Check MOT history for {REG}, including failures, advisories, mileage trends, and estimated car value guidance based on UK public data.' },
  { key: 'home_title', label: 'Homepage Title', value: 'Free Estimated Car Value Without Email | MOT Check UK | WorthCar' },
  { key: 'home_desc', label: 'Homepage Description', value: 'Free estimated car value without email. Check MOT history, mileage trends, and get UK car price guidance in seconds.' },
  { key: 'editorial_title', label: 'Editorial Page Title Formula', value: '{KEYWORD} | WorthCar.co.uk' },
  { key: 'editorial_desc', label: 'Editorial Page Description Formula', value: 'Free car valuation without personal details. Check MOT history and get instant UK car value guidance.' },
];

function MetaTab() {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);

  useEffect(() => {
    base44.entities.AppConfig.filter({ key: { $in: DEFAULT_META.map(d => `seo_${d.key}`) } }).then(existing => {
      const map = {};
      existing.forEach(e => { map[e.key] = e; });
      const merged = DEFAULT_META.map(d => {
        const stored = map[`seo_${d.key}`];
        return stored ? { ...d, value: stored.value, id: stored.id } : { ...d };
      });
      setTemplates(merged);
      setLoading(false);
    });
  }, []);

  const saveTemplate = async (tpl) => {
    setSaving(tpl.key);
    if (tpl.id) {
      await base44.entities.AppConfig.update(tpl.id, { value: tpl.value });
    } else {
      const created = await base44.entities.AppConfig.create({ key: `seo_${tpl.key}`, value: tpl.value, description: tpl.label });
      setTemplates(prev => prev.map(t => t.key === tpl.key ? { ...t, id: created.id } : t));
    }
    setSaving(null);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <p className="text-xs text-slate-500 bg-slate-50 rounded-xl px-4 py-2">Use <code className="font-mono bg-white border border-slate-200 px-1 rounded">{'{REG}'}</code> and <code className="font-mono bg-white border border-slate-200 px-1 rounded">{'{KEYWORD}'}</code> as dynamic placeholders.</p>
      {templates.map(tpl => (
        <div key={tpl.key} className="bg-white rounded-2xl border border-slate-200 p-4 space-y-2">
          <label className="text-xs font-semibold text-slate-600">{tpl.label}</label>
          <textarea
            rows={2}
            value={tpl.value}
            onChange={e => setTemplates(prev => prev.map(t => t.key === tpl.key ? { ...t, value: e.target.value } : t))}
            className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none"
          />
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">{tpl.value.length} chars</span>
            {tpl.value.length > 160 && <span className="text-xs text-red-400 font-medium">⚠ Too long for meta description</span>}
            <button
              onClick={() => saveTemplate(tpl)}
              disabled={saving === tpl.key}
              className="ml-auto flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-lg disabled:opacity-50"
            >
              <Save className="w-3 h-3" /> {saving === tpl.key ? 'Saving…' : 'Save'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Quality Thresholds ───────────────────────────────────────────────────────
const QUALITY_DEFAULTS = [
  { key: 'seo_q_min_score', label: 'Minimum Quality Score to INDEX', value: '5', description: 'Score out of 7 (valid reg, MOT data, mileage, valuation, summary, FAQ, vehicle details)' },
  { key: 'seo_q_min_words', label: 'Minimum Word Count', value: '300', description: 'Pages below this word count will be NOINDEX' },
  { key: 'seo_q_require_mot', label: 'Require MOT Data', value: 'true', description: 'true = NOINDEX if no MOT history found' },
  { key: 'seo_q_require_valuation', label: 'Require Valuation', value: 'true', description: 'true = NOINDEX if no valuation generated' },
  { key: 'seo_q_require_summary', label: 'Require Unique Summary', value: 'true', description: 'true = NOINDEX if AI summary was not generated' },
];

function QualityTab() {
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(null);

  useEffect(() => {
    base44.entities.AppConfig.list('key', 100).then(existing => {
      const map = {};
      existing.forEach(e => { map[e.key] = e; });
      setConfigs(QUALITY_DEFAULTS.map(d => ({ ...d, ...(map[d.key] ? { value: map[d.key].value, id: map[d.key].id } : {}) })));
      setLoading(false);
    });
  }, []);

  const save = async (cfg) => {
    setSaving(cfg.key);
    if (cfg.id) {
      await base44.entities.AppConfig.update(cfg.id, { value: cfg.value });
    } else {
      const created = await base44.entities.AppConfig.create({ key: cfg.key, value: cfg.value, description: cfg.description });
      setConfigs(prev => prev.map(c => c.key === cfg.key ? { ...c, id: created.id } : c));
    }
    setSaving(null);
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-xs text-blue-800">
        These thresholds control when a vehicle result page is marked INDEX vs NOINDEX. Changes take effect on next page generation.
      </div>
      {configs.map(cfg => (
        <div key={cfg.key} className="bg-white rounded-2xl border border-slate-200 p-4">
          <label className="text-xs font-semibold text-slate-700">{cfg.label}</label>
          <p className="text-xs text-slate-400 mb-2">{cfg.description}</p>
          {cfg.value === 'true' || cfg.value === 'false' ? (
            <div className="flex gap-2 mb-3">
              {['true', 'false'].map(v => (
                <button key={v} onClick={() => setConfigs(prev => prev.map(c => c.key === cfg.key ? { ...c, value: v } : c))}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold border transition-colors ${cfg.value === v ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-500 border-slate-200'}`}>
                  {v}
                </button>
              ))}
            </div>
          ) : (
            <input
              type="number"
              value={cfg.value}
              onChange={e => setConfigs(prev => prev.map(c => c.key === cfg.key ? { ...c, value: e.target.value } : c))}
              className="w-24 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 mb-3"
            />
          )}
          <div>
            <button onClick={() => save(cfg)} disabled={saving === cfg.key}
              className="flex items-center gap-1.5 px-4 py-1.5 bg-slate-900 text-white text-xs font-semibold rounded-lg disabled:opacity-50">
              <Save className="w-3 h-3" /> {saving === cfg.key ? 'Saving…' : 'Save'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Editorial Pages ──────────────────────────────────────────────────────────
const EDITORIAL_DEFAULTS = [
  '/free-car-valuation-without-email',
  '/free-car-valuation-uk',
  '/value-my-car-by-registration-number',
  '/car-valuation-uk-without-personal-details',
  '/glasses-guide-car-valuation-free-alternative',
  '/aa-car-valuation-alternative',
  '/dvla-car-value',
  '/mot-check-uk',
  '/check-mot-history',
  '/vehicle-history-check-uk',
];

function EditorialTab() {
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newUrl, setNewUrl] = useState('');
  const [saving, setSaving] = useState(false);

  const load = () => {
    base44.entities.AppConfig.filter({ key: 'seo_editorial_page' }).then(data => {
      setPages(data);
      setLoading(false);
    });
  };

  useEffect(() => { load(); }, []);

  const add = async (url) => {
    if (!url.trim()) return;
    setSaving(true);
    await base44.entities.AppConfig.create({ key: 'seo_editorial_page', value: url.startsWith('/') ? url : `/${url}`, description: 'Editorial SEO landing page' });
    setNewUrl('');
    setSaving(false);
    load();
  };

  const remove = async (id) => {
    await base44.entities.AppConfig.delete(id);
    load();
  };

  const allUrls = pages.map(p => p.value);
  const missing = EDITORIAL_DEFAULTS.filter(u => !allUrls.includes(u));

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-slate-200 border-t-slate-700 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <p className="text-xs text-slate-500 bg-slate-50 rounded-xl px-4 py-2">
        These are the recommended high-intent editorial landing pages. Each should have a unique H1, intro, FAQ, and CTA linking to /check.
      </p>

      {missing.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
          <p className="text-xs font-semibold text-amber-800 mb-2">Recommended pages not yet added:</p>
          <div className="flex flex-wrap gap-2">
            {missing.map(u => (
              <button key={u} onClick={() => add(u)}
                className="text-xs px-2.5 py-1 bg-white border border-amber-300 text-amber-800 rounded-lg hover:bg-amber-100 font-mono transition-colors">
                + {u}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        {pages.length === 0 && <p className="text-sm text-slate-400 px-5 py-6 text-center">No editorial pages added yet.</p>}
        <div className="divide-y divide-slate-100">
          {pages.map(p => (
            <div key={p.id} className="px-5 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-sm font-mono text-slate-700">{p.value}</span>
              </div>
              <button onClick={() => remove(p.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-2">
        <input
          value={newUrl}
          onChange={e => setNewUrl(e.target.value)}
          placeholder="/my-custom-editorial-page"
          className="flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-400"
          onKeyDown={e => e.key === 'Enter' && add(newUrl)}
        />
        <button onClick={() => add(newUrl)} disabled={saving || !newUrl.trim()}
          className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-900 text-white text-sm font-semibold rounded-xl disabled:opacity-50">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>
    </div>
  );
}

// ─── Sitemap Rules ────────────────────────────────────────────────────────────
function SitemapTab() {
  const rules = {
    include: [
      'Homepage (/)',
      'Core editorial landing pages',
      'Comparison pages (if unique & substantial)',
      'Vehicle pages that pass quality score threshold',
    ],
    exclude: [
      'NOINDEX pages',
      'Failed lookups / empty result pages',
      'Duplicate or near-duplicate pages',
      'Temporary or test URLs',
      'Registration pages that fail quality threshold',
    ],
    structure: [
      '/sitemap-pages.xml — Homepage + editorial + comparison pages',
      '/sitemap-registry-1.xml — Indexed vehicle pages (batch 1)',
      '/sitemap-registry-2.xml — Indexed vehicle pages (batch 2)',
      '/sitemap-registry-3.xml — Indexed vehicle pages (batch 3)',
    ],
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4">
          <p className="text-xs font-bold text-emerald-800 uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5" /> Include in Sitemap
          </p>
          <ul className="space-y-1.5">
            {rules.include.map((r, i) => <li key={i} className="text-sm text-emerald-900">• {r}</li>)}
          </ul>
        </div>
        <div className="bg-red-50 border border red-200 rounded-2xl p-4">
          <p className="text-xs font-bold text-red-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <XCircle className="w-3.5 h-3.5" /> Exclude from Sitemap
          </p>
          <ul className="space-y-1.5">
            {rules.exclude.map((r, i) => <li key={i} className="text-sm text-red-900">• {r}</li>)}
          </ul>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <p className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5" /> Recommended Sitemap Structure
        </p>
        <ul className="space-y-2">
          {rules.structure.map((r, i) => (
            <li key={i} className="text-sm font-mono text-slate-700 bg-slate-50 rounded-lg px-3 py-2">{r}</li>
          ))}
        </ul>
      </div>

      <div className="bg-slate-900 rounded-2xl p-4 text-xs text-slate-300 space-y-1">
        <p className="font-bold text-white mb-2">Canonical URL Rule</p>
        <p>All registration variants must canonical to:</p>
        <p className="font-mono text-amber-400">https://worthcar.co.uk/reg/AB12CDE</p>
        <p className="mt-2 text-slate-400">AB12CDE / AB12 CDE / ab12cde → all point to the same canonical. No query params. No tracking URLs.</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-4">
        <p className="text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">Structured Data (JSON-LD)</p>
        <div className="space-y-1">
          {[
            'Site level: WebSite, Organization, WebApplication',
            'Editorial pages: WebPage + FAQPage',
            'Vehicle pages: WebPage + FAQPage + BreadcrumbList',
          ].map((item, i) => (
            <p key={i} className="text-sm text-slate-600">• {item}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Main SEO Module ──────────────────────────────────────────────────────────
export default function SeoModule() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-900 mb-1">SEO Management</h2>
      <p className="text-sm text-slate-500 mb-5">White-hat programmatic SEO system — UK MOT + car value pages.</p>

      <div className="flex gap-1 flex-wrap mb-6 bg-slate-100 p-1 rounded-xl">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${activeTab === t.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && <StrategyTab />}
      {activeTab === 'meta' && <MetaTab />}
      {activeTab === 'quality' && <QualityTab />}
      {activeTab === 'editorial' && <EditorialTab />}
      {activeTab === 'sitemap' && <SitemapTab />}
    </div>
  );
}