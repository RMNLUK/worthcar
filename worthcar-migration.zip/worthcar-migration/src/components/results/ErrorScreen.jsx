import React from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft, RotateCcw, SearchX, WifiOff, Clock } from "lucide-react";
import { motion } from "framer-motion";

const ERROR_CONFIG = {
  invalid_reg: {
    icon: SearchX,
    title: "Invalid Registration",
    desc: "The registration number doesn't appear to be valid. Please check and try again.",
    color: "text-amber-500",
    bg: "bg-amber-50",
  },
  no_record: {
    icon: SearchX,
    title: "Registration Not Found",
    desc: "This registration was not found in the MOT database. Please check the registration number is correct.",
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  no_mot_records: {
    icon: SearchX,
    title: "No MOT History Yet",
    desc: "This vehicle was found but has no MOT history records yet. It may be too new or not yet tested.",
    color: "text-amber-500",
    bg: "bg-amber-50",
  },
  api_error: {
    icon: WifiOff,
    title: "Service Unavailable",
    desc: "We couldn't reach the MOT data service right now. Please try again in a moment.",
    color: "text-red-500",
    bg: "bg-red-50",
  },
  rate_limit: {
    icon: Clock,
    title: "Too Many Requests",
    desc: "We've hit the rate limit. Please wait a moment and try again.",
    color: "text-orange-500",
    bg: "bg-orange-50",
  },
};

export default function ErrorScreen({ type, message, onBack, onRetry, registration }) {
  const config = ERROR_CONFIG[type] || ERROR_CONFIG.api_error;
  const Icon = config.icon;
  
  // Add registration number to error message
  let displayMessage = message;
  if ((type === 'no_record' || type === 'no_mot_records') && registration && !message) {
    displayMessage = type === 'no_mot_records' 
      ? `${registration} was found but has no MOT history records yet. This vehicle may be too new or not yet submitted for testing.`
      : `No MOT record found for ${registration}. Please check the registration number is correct.`;
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center max-w-md"
      >
        {registration && (type === 'no_record' || type === 'no_mot_records') && (
          <div className="mb-6 flex justify-center">
            <div className="bg-yellow-300 border-4 border-slate-900 rounded px-4 py-2 font-mono font-bold text-slate-900 tracking-wider text-lg shadow-sm">
              {registration}
            </div>
          </div>
        )}
        <div className={`w-20 h-20 rounded-2xl ${config.bg} flex items-center justify-center mx-auto mb-6`}>
          <Icon className={`w-10 h-10 ${config.color}`} />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-3">{config.title}</h2>
        <p className="text-slate-500 leading-relaxed mb-8">
         {displayMessage || message || config.desc}
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          {onBack && (
            <Button
              variant="outline"
              onClick={onBack}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Search
            </Button>
          )}
          {onRetry && (
            <Button
              onClick={onRetry}
              className="bg-slate-900 hover:bg-slate-800 flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Try Again
            </Button>
          )}
        </div>
      </motion.div>
    </div>
  );
}