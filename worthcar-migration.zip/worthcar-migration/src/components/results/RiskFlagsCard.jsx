import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Flag } from "lucide-react";

export default function RiskFlagsCard({ flags }) {
  if (!flags || flags.length === 0) return null;

  return (
    <Card className="border-0 shadow-lg border-l-4 border-l-red-400">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Flag className="w-5 h-5 text-red-500" />
          Risk Flags
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {flags.map((flag, i) => (
            <li key={i} className="flex items-start gap-3 p-2.5 bg-red-50 rounded-lg">
              <span className="w-2 h-2 rounded-full bg-red-400 mt-1.5 flex-shrink-0" />
              <span className="text-sm text-red-800 leading-relaxed">{flag}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}