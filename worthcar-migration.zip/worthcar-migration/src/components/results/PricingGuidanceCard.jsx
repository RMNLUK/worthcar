import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PoundSterling, Info } from "lucide-react";

export default function PricingGuidanceCard({ pricing }) {
  if (!pricing) return null;

  const hasRange = pricing.estimated_range_low != null && pricing.estimated_range_high != null;

  return (
    <Card className="border-0 shadow-lg overflow-hidden">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <PoundSterling className="w-5 h-5 text-emerald-500" />
          Pricing Guidance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {pricing.label && (
          <p className="text-sm font-medium text-slate-700">{pricing.label}</p>
        )}

        {hasRange && (
          <div className="bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl p-5">
            <div className="flex items-center justify-between">
              <div className="text-center">
                <p className="text-xs text-slate-500 mb-1">Strong Buy At</p>
                <p className="text-2xl font-bold text-emerald-700">
                  £{pricing.estimated_range_low?.toLocaleString()}
                </p>
              </div>
              <div className="h-12 w-px bg-slate-200" />
              <div className="text-center">
                <p className="text-xs text-slate-500 mb-1">Walk Away Above</p>
                <p className="text-2xl font-bold text-red-600">
                  £{pricing.estimated_range_high?.toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Disclaimer */}
        <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-lg border border-amber-100">
          <Info className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-amber-800 leading-relaxed">
            {pricing.confidence_note ||
              "This is an MOT-history-based estimate only, not a formal market valuation. Actual market value depends on condition, service history, spec, and comparable listings."}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}