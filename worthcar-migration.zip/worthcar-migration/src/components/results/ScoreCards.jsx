import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, AlertTriangle, ThumbsUp } from "lucide-react";

function ScoreRing({ score, size = 80, strokeWidth = 6, color }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = ((score || 0) / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#f1f5f9"
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={circumference - progress}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xl font-bold text-slate-900">{score || 0}</span>
      </div>
    </div>
  );
}

export default function ScoreCards({ scorecard }) {
  if (!scorecard) return null;

  const scores = [
    {
      label: "Maintenance",
      score: scorecard.maintenance_score,
      icon: Shield,
      color: "#10b981",
      desc: "How well maintained",
    },
    {
      label: "Risk Level",
      score: 100 - (scorecard.risk_score || 0),
      icon: AlertTriangle,
      color: scorecard.risk_score > 50 ? "#ef4444" : "#f59e0b",
      desc: "Lower risk = better",
    },
    {
      label: "Buy Confidence",
      score: scorecard.buying_confidence_score,
      icon: ThumbsUp,
      color: "#6366f1",
      desc: "Overall buying signal",
    },
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardContent className="p-5">
        <div className="grid grid-cols-3 gap-4">
          {scores.map((s, i) => (
            <div key={i} className="flex flex-col items-center text-center gap-2">
              <ScoreRing score={s.score} color={s.color} />
              <div>
                <p className="text-sm font-semibold text-slate-800">{s.label}</p>
                <p className="text-xs text-slate-400">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}