import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, XCircle, AlertTriangle, Shield } from "lucide-react";

export default function MotSummaryCard({ metrics }) {
  if (!metrics) return null;

  const stats = [
    {
      label: "Total Tests",
      value: metrics.totalTests || 0,
      icon: Shield,
      color: "text-slate-600",
      bg: "bg-slate-100",
    },
    {
      label: "Passes",
      value: metrics.totalPasses || 0,
      icon: CheckCircle2,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      label: "Fails",
      value: metrics.totalFails || 0,
      icon: XCircle,
      color: "text-red-600",
      bg: "bg-red-50",
    },
    {
      label: "Advisories",
      value: metrics.totalAdvisories || 0,
      icon: AlertTriangle,
      color: "text-amber-600",
      bg: "bg-amber-50",
    },
  ];

  const failRate = metrics.failRate != null ? metrics.failRate : 0;
  const dangerousCount = metrics.totalDangerous || 0;

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900">MOT Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-4 gap-2">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className={`${stat.bg} rounded-xl p-2.5 text-center`}>
                <Icon className={`w-3.5 h-3.5 ${stat.color} mx-auto mb-1`} />
                <p className="text-xs text-slate-500 leading-tight mb-0.5">{stat.label}</p>
                <p className={`text-xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* Fail rate bar */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-slate-600">Fail Rate</span>
            <span className={`text-sm font-bold ${failRate > 40 ? "text-red-600" : failRate > 20 ? "text-amber-600" : "text-emerald-600"}`}>
              {failRate.toFixed(0)}%
            </span>
          </div>
          <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                failRate > 40 ? "bg-red-500" : failRate > 20 ? "bg-amber-400" : "bg-emerald-500"
              }`}
              style={{ width: `${Math.min(failRate, 100)}%` }}
            />
          </div>
        </div>

        {dangerousCount > 0 && (
          <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg border border-red-100">
            <XCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
            <span className="text-sm font-medium text-red-700">
              {dangerousCount} dangerous defect{dangerousCount > 1 ? "s" : ""} recorded
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}