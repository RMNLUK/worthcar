import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wrench, ShieldCheck, AlertTriangle, XOctagon } from "lucide-react";

const VERDICT_CONFIG = {
  proactive: {
    icon: ShieldCheck,
    bg: "bg-emerald-50",
    border: "border-emerald-200",
    iconColor: "text-emerald-600",
    titleColor: "text-emerald-800",
  },
  mixed: {
    icon: AlertTriangle,
    bg: "bg-amber-50",
    border: "border-amber-200",
    iconColor: "text-amber-600",
    titleColor: "text-amber-800",
  },
  neglected: {
    icon: XOctagon,
    bg: "bg-red-50",
    border: "border-red-200",
    iconColor: "text-red-600",
    titleColor: "text-red-800",
  },
};

function getVerdictType(verdict) {
  const lower = (verdict || "").toLowerCase();
  if (lower.includes("proactive") || lower.includes("well")) return "proactive";
  if (lower.includes("neglect") || lower.includes("poor")) return "neglected";
  return "mixed";
}

export default function MaintenanceVerdictCard({ verdict, summary }) {
  if (!verdict) return null;

  const type = getVerdictType(verdict);
  const config = VERDICT_CONFIG[type];
  const Icon = config.icon;

  return (
    <Card className={`border-0 shadow-lg overflow-hidden`}>
      <div className={`${config.bg} border-l-4 ${config.border} p-5`}>
        <div className="flex items-start gap-3">
          <div className={`w-10 h-10 rounded-full ${config.bg} flex items-center justify-center flex-shrink-0`}>
            <Icon className={`w-5 h-5 ${config.iconColor}`} />
          </div>
          <div>
            <h3 className={`text-base font-bold ${config.titleColor}`}>{verdict}</h3>
            {summary && (
              <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">{summary}</p>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}