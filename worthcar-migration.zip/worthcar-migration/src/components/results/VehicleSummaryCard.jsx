import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Car, Fuel, Palette, Calendar, Clock } from "lucide-react";

export default function VehicleSummaryCard({ vehicle }) {
  if (!vehicle) return null;

  const details = [
    { icon: Car, label: "Make / Model", value: `${vehicle.make || "—"} ${vehicle.model || ""}`.trim() },
    { icon: Fuel, label: "Fuel Type", value: vehicle.fuelType || "—" },
    { icon: Palette, label: "Colour", value: vehicle.colour || "—" },
    { icon: Calendar, label: "First Used", value: vehicle.firstUsedDate || "—" },
    { icon: Clock, label: "MOT Expires", value: vehicle.motExpiryDate || "—" },
  ];

  return (
    <Card className="overflow-hidden border-0 shadow-lg">
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 px-6 py-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Vehicle</p>
            <h2 className="text-white text-xl font-bold mt-1">
              {vehicle.make} {vehicle.model}
            </h2>
          </div>
          <div className="flex items-stretch rounded-md overflow-hidden border border-slate-600">
            <div className="w-2 bg-amber-400" />
            <div className="px-3 py-1.5 bg-slate-700">
              <span className="text-white font-bold tracking-wider text-sm">
                {vehicle.registration}
              </span>
            </div>
          </div>
        </div>
      </div>
      <CardContent className="p-0">
        <div className="grid grid-cols-2 sm:grid-cols-3 divide-x divide-y divide-slate-100">
          {details.map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-2 mb-1">
                  <Icon className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-xs text-slate-400 uppercase tracking-wider font-medium">{item.label}</span>
                </div>
                <p className="text-sm font-semibold text-slate-900 capitalize">{item.value}</p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}