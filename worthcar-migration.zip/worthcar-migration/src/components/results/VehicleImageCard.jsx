import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function VehicleImageCard({ vehicle }) {
  const [imageUrl, setImageUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        const dateField = vehicle.firstUsedDate || vehicle.registrationDate;
        const year = dateField ? new Date(dateField).getFullYear() : undefined;
        const response = await base44.functions.invoke('getVehicleImage', {
          make: vehicle.make,
          model: vehicle.model,
          year: year,
          colour: vehicle.colour
        });
        
        setImageUrl(response.data.imageUrl);
      } catch (error) {
        console.error('Failed to fetch vehicle image:', error);
        setImageUrl('https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800&h=400&fit=crop');
      } finally {
        setIsLoading(false);
      }
    };

    fetchImage();
  }, [vehicle]);

  return (
    <div className="mb-6 rounded-lg overflow-hidden border border-slate-200">
      {(isLoading || !imageLoaded) && (
        <div className="absolute w-full h-64 bg-gradient-to-r from-slate-200 to-slate-300 animate-pulse" />
      )}
      <div className="relative w-full h-64 bg-black">
        {imageUrl && (
          <img 
            src={imageUrl} 
            alt={`${vehicle.make} ${vehicle.model}`}
            className={`w-full h-full object-cover transition-opacity duration-300 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setImageLoaded(true)}
            onError={(e) => {
              e.target.src = 'https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800&h=400&fit=crop';
              setImageLoaded(true);
            }}
          />
        )}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
          <p className="text-white font-semibold">
            {vehicle.make} {vehicle.model}
          </p>
          <p className="text-white/80 text-sm">
            {(() => {
              const dateField = vehicle.firstUsedDate || vehicle.registrationDate;
              const year = dateField ? new Date(dateField).getFullYear() : 'Unknown year';
              return `${year} • ${vehicle.colour || 'Unknown colour'} • ${vehicle.fuelType || 'Unknown fuel'}`;
            })()} 
          </p>
        </div>
      </div>
    </div>
  );
}