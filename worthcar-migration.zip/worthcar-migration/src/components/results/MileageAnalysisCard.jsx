import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Gauge, AlertTriangle, ArrowUpRight, Activity, Info } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell, LabelList } from "recharts";

function detectAnomalies(sortedTests) {
  const anomalies = [];
  for (let i = 1; i < sortedTests.length; i++) {
    const prev = sortedTests[i - 1];
    const curr = sortedTests[i];
    const milesDiff = curr.odometerValue - prev.odometerValue;
    const daysDiff = (new Date(curr.completedDate) - new Date(prev.completedDate)) / (1000 * 60 * 60 * 24);
    const yearsDiff = daysDiff / 365;
    const annualRate = yearsDiff > 0 ? milesDiff / yearsDiff : 0;
    const dateLabel = new Date(curr.completedDate).toLocaleDateString("en-GB", { month: "short", year: "numeric" });

    if (milesDiff < 0) {
      anomalies.push({
        date: dateLabel,
        detail: `Mileage dropped by ${Math.abs(milesDiff).toLocaleString()} mi at ${dateLabel}`,
        reasons: [
          "Odometer may have been tampered with or replaced",
          "A different vehicle may have been presented for MOT",
          "Recording error by the MOT tester"
        ]
      });
    } else if (milesDiff === 0 && daysDiff > 30) {
      anomalies.push({
        date: dateLabel,
        detail: `Mileage unchanged between tests (${Math.round(daysDiff)} days apart)`,
        reasons: [
          "Vehicle may have been stored or rarely used",
          "Odometer may have been frozen or not functioning",
          "Possible recording discrepancy"
        ]
      });
    } else if (annualRate > 30000) {
      anomalies.push({
        date: dateLabel,
        detail: `Very high rate: ~${Math.round(annualRate).toLocaleString()} mi/yr before ${dateLabel}`,
        reasons: [
          "Could indicate commercial or long-distance use in that period",
          "May reflect catch-up mileage after a low-mileage period",
          "Could suggest odometer discrepancy in an earlier test"
        ]
      });
    } else if (annualRate < 1000 && yearsDiff > 0.5 && milesDiff > 0) {
      anomalies.push({
        date: dateLabel,
        detail: `Very low usage: ~${Math.round(annualRate).toLocaleString()} mi/yr before ${dateLabel}`,
        reasons: [
          "Vehicle may have been laid up or rarely driven",
          "Could indicate a second car or seasonal use",
          "Low mileage can sometimes mask unreported issues"
        ]
      });
    }
  }
  return anomalies;
}

const UK_AVG_ANNUAL = 7400;

export default function MileageAnalysisCard({ metrics, motTests }) {
  if (!metrics) return null;

  const sortedTests = (motTests || [])
    .filter((t) => t.odometerValue && t.odometerValue > 0)
    .sort((a, b) => new Date(a.completedDate) - new Date(b.completedDate));

  const mileageData = sortedTests.map((t, i) => {
    const prev = sortedTests[i - 1];
    const milesDiff = prev ? t.odometerValue - prev.odometerValue : null;
    const daysDiff = prev ? (new Date(t.completedDate) - new Date(prev.completedDate)) / (1000 * 60 * 60 * 24) : null;
    const annualRate = daysDiff && milesDiff != null ? Math.round(milesDiff / (daysDiff / 365)) : null;
    return {
      date: new Date(t.completedDate).toLocaleDateString("en-GB", { month: "short", year: "2-digit" }),
      miles: t.odometerValue,
      increment: milesDiff,
      annualRate,
    };
  });

  const anomalies = detectAnomalies(sortedTests);
  const totalDistance = sortedTests.length > 1
    ? sortedTests[sortedTests.length - 1].odometerValue - sortedTests[0].odometerValue
    : null;
  const comparedToAvg = metrics.avgMilesPerYear
    ? Math.round(((metrics.avgMilesPerYear - UK_AVG_ANNUAL) / UK_AVG_ANNUAL) * 100)
    : null;

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900">Mileage Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">

          {/* Stats row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <div className="bg-blue-50 rounded-xl p-3 text-center">
              <Gauge className="w-4 h-4 text-blue-600 mx-auto mb-1" />
              <p className="text-xs text-slate-500 mb-0.5">Latest Mileage</p>
              <p className="text-xl font-bold text-blue-700">
                {metrics.latestMileage ? metrics.latestMileage.toLocaleString() : "—"}
              </p>
              <p className="text-xs text-slate-400">miles</p>
            </div>
            <div className="bg-indigo-50 rounded-xl p-3 text-center">
              <TrendingUp className="w-4 h-4 text-indigo-600 mx-auto mb-1" />
              <p className="text-xs text-slate-500 mb-0.5">Avg / Year</p>
              <p className="text-xl font-bold text-indigo-700">
                {metrics.avgMilesPerYear ? metrics.avgMilesPerYear.toLocaleString() : "—"}
              </p>
              {comparedToAvg !== null && (
                <p className={`text-xs font-medium ${comparedToAvg > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                  {comparedToAvg > 0 ? `+${comparedToAvg}%` : `${comparedToAvg}%`} vs UK avg
                </p>
              )}
            </div>
            <div className="bg-violet-50 rounded-xl p-3 text-center">
              <ArrowUpRight className="w-4 h-4 text-violet-600 mx-auto mb-1" />
              <p className="text-xs text-slate-500 mb-0.5">First Recorded</p>
              <p className="text-xl font-bold text-violet-700">
                {metrics.firstMileage ? metrics.firstMileage.toLocaleString() : "—"}
              </p>
              <p className="text-xs text-slate-400">miles</p>
            </div>
            <div className="bg-teal-50 rounded-xl p-3 text-center">
              <Activity className="w-4 h-4 text-teal-600 mx-auto mb-1" />
              <p className="text-xs text-slate-500 mb-0.5">MOT Span Total</p>
              <p className="text-xl font-bold text-teal-700">
                {totalDistance != null ? totalDistance.toLocaleString() : "—"}
              </p>
              <p className="text-xs text-slate-400">miles</p>
            </div>
          </div>

          {/* Odometer chart */}
          {mileageData.length > 1 && (() => {
            const maxMiles = Math.max(...mileageData.map(d => d.miles));
            const yDomainMax = Math.ceil((maxMiles * 1.15) / 1000) * 1000;
            const isCrowded = mileageData.length > 6;
            return (
              <div>
                <p className="text-xs font-medium text-slate-500 mb-2">Odometer Progression</p>
                <div className="overflow-x-auto -mx-1 px-1">
                  <div style={{ minWidth: mileageData.length * 64 + 48 }}>
                    <BarChart data={mileageData} width={Math.max(mileageData.length * 64 + 48, 300)} height={260} margin={{ top: 32, right: 8, left: 0, bottom: 5 }} barCategoryGap="8%">
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                      <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} width={32} domain={[0, yDomainMax]} />
                      <Tooltip
                        formatter={(value, name, props) => {
                          const d = props.payload;
                          const lines = [`Total: ${value.toLocaleString()} mi`];
                          if (d.increment != null) lines.push(`+${d.increment.toLocaleString()} mi from prev`);
                          return [lines.join('  ·  '), ''];
                        }}
                        contentStyle={{ borderRadius: "12px", border: "none", boxShadow: "0 4px 20px rgba(0,0,0,0.08)", fontSize: "12px" }}
                        labelStyle={{ fontWeight: 600, color: "#1e293b" }}
                      />
                      <Bar dataKey="miles" radius={[6, 6, 0, 0]} isAnimationActive={false} maxBarSize={64}>
                        {mileageData.map((d, i) => (
                          <Cell key={i} fill={d.increment < 0 ? "#f87171" : d.annualRate > 25000 ? "#fbbf24" : "#6366f1"} />
                        ))}
                        {/* Total miles label — top of bar */}
                        <LabelList
                          dataKey="miles"
                          position="top"
                          style={{ fontSize: 10, fontWeight: 700, fill: "#1e293b" }}
                          formatter={(v) => `${(v / 1000).toFixed(1)}k`}
                        />
                        {/* Delta label — inside bar */}
                        <LabelList
                          dataKey="increment"
                          position="insideTop"
                          style={{ fontSize: 9, fontWeight: 600, fill: "#ffffff" }}
                          formatter={(v) => v != null ? `+${(v / 1000).toFixed(1)}k` : ''}
                        />
                      </Bar>
                    </BarChart>
                  </div>
                </div>
                <div className="flex items-center gap-4 mt-1 justify-end">
                  <span className="flex items-center gap-1 text-xs text-slate-400"><span className="w-3 h-3 rounded-sm inline-block bg-indigo-400"></span>Normal</span>
                  <span className="flex items-center gap-1 text-xs text-slate-400"><span className="w-3 h-3 rounded-sm inline-block bg-amber-400"></span>High usage</span>
                  <span className="flex items-center gap-1 text-xs text-slate-400"><span className="w-3 h-3 rounded-sm inline-block bg-red-400"></span>Drop</span>
                </div>
              </div>
            );
          })()}

          {/* UK avg context */}
          <div className="flex items-start gap-2 p-3 bg-slate-50 rounded-xl border border-slate-100">
            <Info className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-slate-500 leading-relaxed">
              UK average is ~{UK_AVG_ANNUAL.toLocaleString()} mi/yr (DVLA).
              {comparedToAvg !== null && comparedToAvg > 20 && " This vehicle is driven significantly more than average — higher wear expected."}
              {comparedToAvg !== null && comparedToAvg < -20 && " This vehicle is driven well below average — verify it hasn't been stored or clocked."}
              {comparedToAvg !== null && Math.abs(comparedToAvg) <= 20 && " Usage is broadly in line with the national average."}
            </p>
          </div>

          {/* Anomalies */}
          {anomalies.length > 0 ? (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-amber-700 uppercase tracking-wide">⚠ Suspicious Patterns</p>
              {anomalies.map((a, i) => (
                <div key={i} className="p-3 bg-amber-50 rounded-xl border border-amber-100">
                  <div className="flex items-start gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <span className="text-xs font-semibold text-amber-800">{a.detail}</span>
                  </div>
                  <p className="text-xs font-medium text-amber-700 mb-1 ml-6">Possible reasons:</p>
                  <ul className="ml-6 space-y-0.5">
                    {a.reasons.map((r, j) => (
                      <li key={j} className="text-xs text-amber-600 flex items-start gap-1">
                        <span className="flex-shrink-0">•</span>
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ) : sortedTests.length > 1 && (
            <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-xl border border-emerald-100">
              <TrendingUp className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span className="text-xs font-medium text-emerald-700">No anomalies detected — mileage progression is consistent</span>
            </div>
          )}

          {/* Per-test breakdown */}
          {mileageData.length > 1 && (
            <div>
              <p className="text-xs font-medium text-slate-500 mb-2">Year-by-Year Breakdown</p>
              <div className="space-y-1.5">
                {mileageData.map((d, i) => (
                  <div key={i} className="grid text-xs bg-slate-50 rounded-lg px-3 py-2" style={{gridTemplateColumns: '4rem 1fr 1fr'}}>
                    <span className="text-slate-600 font-medium">{d.date}</span>
                    <span className="text-slate-800 font-semibold text-center">{d.miles.toLocaleString()} mi</span>
                    {d.increment != null ? (
                      <span className={`font-medium text-right ${d.increment < 0 ? "text-red-600" : d.annualRate > 25000 ? "text-amber-600" : "text-slate-500"}`}>
                        +{d.increment.toLocaleString()} mi{d.annualRate != null ? ` (${d.annualRate.toLocaleString()}/yr)` : ""}
                      </span>
                    ) : (
                      <span className="text-slate-400 text-right">—</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </CardContent>
    </Card>
  );
}