import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ThumbsUp, ShieldAlert, Ban } from "lucide-react";

const REC_CONFIG = {
  buy: {
    icon: ThumbsUp,
    bg: "bg-gradient-to-br from-emerald-500 to-emerald-600",
    label: "Worth Buying",
  },
  caution: {
    icon: ShieldAlert,
    bg: "bg-gradient-to-br from-amber-400 to-amber-500",
    label: "Proceed with Caution",
  },
  avoid: {
    icon: Ban,
    bg: "bg-gradient-to-br from-red-500 to-red-600",
    label: "Walk Away",
  },
};

function getRecType(rec) {
  const lower = (rec || "").toLowerCase();
  if (lower.includes("buy") || lower.includes("worth") || lower.includes("good")) return "buy";
  if (lower.includes("avoid") || lower.includes("walk") || lower.includes("don't") || lower.includes("no")) return "avoid";
  return "caution";
}

export default function BuyRecommendationCard({ recommendation }) {
  if (!recommendation) return null;

  const type = getRecType(recommendation);
  const config = REC_CONFIG[type];
  const Icon = config.icon;

  return (
    <Card className="border-0 shadow-lg overflow-hidden">
      <div className={`${config.bg} p-6 text-white`}>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
            <Icon className="w-7 h-7" />
          </div>
          <div>
            <p className="text-sm font-medium text-white/80 uppercase tracking-wider">Recommendation</p>
            <h3 className="text-xl font-bold mt-0.5">{config.label}</h3>
          </div>
        </div>
        <p className="text-sm text-white/90 mt-4 leading-relaxed">{recommendation}</p>
      </div>
    </Card>
  );
}