import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, ChevronDown, ChevronUp, History, Gauge } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function MotTimelineCard({ motTests }) {
  const [expanded, setExpanded] = useState(false);
  if (!motTests || motTests.length === 0) return null;

  const sorted = [...motTests].sort(
    (a, b) => new Date(b.completedDate) - new Date(a.completedDate)
  );
  const displayed = expanded ? sorted : sorted.slice(0, 5);

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <History className="w-5 h-5 text-slate-500" />
          Full MOT History
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-0">
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-5 top-0 bottom-0 w-px bg-slate-200" />

          {displayed.map((test, i) => {
            const isPassed = (test.testResult || "").toLowerCase().includes("pass");
            const defects = test.defects || [];
            const advisories = defects.filter((d) => d.type === "advisory" || d.type === "ADVISORY");
            const failures = defects.filter((d) => d.type !== "advisory" && d.type !== "ADVISORY");

            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="relative pl-12 pb-6 last:pb-0"
              >
                {/* Timeline dot */}
                <div
                  className={`absolute left-3 top-1 w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                    isPassed
                      ? "bg-emerald-100 border-emerald-400"
                      : "bg-red-100 border-red-400"
                  }`}
                >
                  {isPassed ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  ) : (
                    <XCircle className="w-3 h-3 text-red-600" />
                  )}
                </div>

                <div className="bg-slate-50 rounded-xl p-4 hover:bg-slate-100 transition-colors">
                  <div className="flex items-center justify-between flex-wrap gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-800">
                        {new Date(test.completedDate).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })}
                      </span>
                      <Badge
                        className={
                          isPassed
                            ? "bg-emerald-100 text-emerald-700 border-emerald-200"
                            : "bg-red-100 text-red-700 border-red-200"
                        }
                        variant="outline"
                      >
                        {isPassed ? "PASS" : "FAIL"}
                      </Badge>
                    </div>
                    {test.odometerValue > 0 && (
                      <div className="flex items-center gap-1 text-xs text-slate-500">
                        <Gauge className="w-3 h-3" />
                        {test.odometerValue.toLocaleString()} {test.odometerUnit || "mi"}
                      </div>
                    )}
                  </div>

                  {failures.length > 0 && (
                    <div className="space-y-1 mt-2">
                      {failures.map((d, j) => (
                        <div key={j} className="flex items-start gap-2">
                          <XCircle className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                          <span className="text-xs text-red-700">{d.text}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {advisories.length > 0 && (
                    <div className="space-y-1 mt-2">
                      {advisories.map((d, j) => (
                        <div key={j} className="flex items-start gap-2">
                          <span className="w-3 h-3 rounded-full bg-amber-300 mt-0.5 flex-shrink-0" />
                          <span className="text-xs text-amber-700">{d.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {sorted.length > 5 && (
          <Button
            variant="ghost"
            onClick={() => setExpanded(!expanded)}
            className="w-full mt-4 text-sm text-slate-500 hover:text-slate-700"
          >
            {expanded ? (
              <>
                <ChevronUp className="w-4 h-4 mr-1" /> Show Less
              </>
            ) : (
              <>
                <ChevronDown className="w-4 h-4 mr-1" /> Show All {sorted.length} Tests
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}