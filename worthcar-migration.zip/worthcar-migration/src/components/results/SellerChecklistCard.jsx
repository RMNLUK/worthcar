import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ClipboardList, CircleDot } from "lucide-react";

export default function SellerChecklistCard({ requirements }) {
  if (!requirements || requirements.length === 0) return null;

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-indigo-500" />
          Ask the Seller For
        </CardTitle>
        <p className="text-sm text-slate-500">
          Evidence and documents you should request before committing
        </p>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2.5">
          {requirements.map((item, i) => (
            <li key={i} className="flex items-start gap-3">
              <CircleDot className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
              <span className="text-sm text-slate-700 leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}