import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";

const CONSENT_KEY = "worthcar_cookie_consent_v2";

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [showManage, setShowManage] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: true, advertising: true });

  useEffect(() => {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) setVisible(true);
  }, []);

  const save = (overrides) => {
    const final = { ...prefs, ...overrides, timestamp: Date.now() };
    localStorage.setItem(CONSENT_KEY, JSON.stringify(final));
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 z-50 p-4"
        >
          <div className="max-w-3xl mx-auto bg-white border border-slate-200 rounded-2xl shadow-2xl p-5">
            <h2 className="text-sm font-bold text-slate-900 mb-1">We use cookies & similar technologies</h2>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">
              WorthCar.co.uk uses cookies to run the site, improve performance, and analyse usage. With your consent, we also use advertising cookies. We process data under UK GDPR / EU GDPR.{" "}
              <Link to="/CookiePolicy" className="text-amber-600 hover:underline" onClick={() => setVisible(false)}>Cookie Policy</Link>
              {" · "}
              <Link to="/PrivacyPolicy" className="text-amber-600 hover:underline" onClick={() => setVisible(false)}>Privacy Policy</Link>
            </p>

            {showManage && (
              <div className="mb-4 space-y-2 p-3 bg-slate-50 rounded-xl text-xs text-slate-700">
                <div className="flex items-center justify-between">
                  <span><strong>Essential cookies</strong> — always active</span>
                  <span className="text-emerald-600 font-semibold">Required</span>
                </div>
                <div className="flex items-center justify-between">
                  <span><strong>Analytics cookies</strong> — anonymous usage data</span>
                  <button
                    onClick={() => setPrefs(p => ({ ...p, analytics: !p.analytics }))}
                    className={`w-10 h-5 rounded-full transition-colors ${prefs.analytics ? "bg-amber-500" : "bg-slate-300"}`}
                  >
                    <span className={`block w-4 h-4 bg-white rounded-full shadow transition-transform mx-0.5 ${prefs.analytics ? "translate-x-5" : "translate-x-0"}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span><strong>Advertising cookies</strong> — relevant ads</span>
                  <button
                    onClick={() => setPrefs(p => ({ ...p, advertising: !p.advertising }))}
                    className={`w-10 h-5 rounded-full transition-colors ${prefs.advertising ? "bg-amber-500" : "bg-slate-300"}`}
                  >
                    <span className={`block w-4 h-4 bg-white rounded-full shadow transition-transform mx-0.5 ${prefs.advertising ? "translate-x-5" : "translate-x-0"}`} />
                  </button>
                </div>
                <p className="text-slate-400 pt-1">You can withdraw consent at any time (UK GDPR Art. 7).</p>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => save({ analytics: true, advertising: true })}
                className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-xl hover:bg-slate-700 transition-colors"
              >
                Accept All
              </button>
              <button
                onClick={() => save({ analytics: false, advertising: false })}
                className="px-4 py-2 bg-white text-slate-700 text-xs font-medium rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
              >
                Reject Non-Essential
              </button>
              {showManage ? (
                <button
                  onClick={() => save(prefs)}
                  className="px-4 py-2 bg-amber-500 text-white text-xs font-semibold rounded-xl hover:bg-amber-600 transition-colors"
                >
                  Save Preferences
                </button>
              ) : (
                <button
                  onClick={() => setShowManage(true)}
                  className="px-4 py-2 bg-white text-slate-500 text-xs rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
                >
                  Manage Preferences
                </button>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}