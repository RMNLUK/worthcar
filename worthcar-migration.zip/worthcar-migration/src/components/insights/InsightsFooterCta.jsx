import React from "react";
import { Link } from "react-router-dom";

export default function InsightsFooterCta() {
  return (
    <div className="mt-10">
      <p className="text-xs text-[#94a3b8] text-center leading-relaxed max-w-3xl mx-auto">
        All statistics on this page are derived from anonymised, aggregated data collected from WorthCar vehicle searches.
        Individual vehicle data is never displayed without a direct reg plate lookup. Data is updated monthly.
        WorthCar is not responsible for decisions made based on aggregated trend data.
      </p>
    </div>
  );
}