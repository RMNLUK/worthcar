import React from "react";
import { Link, useLocation } from "react-router-dom";

const TABS = [
  { label: "Market Pulse", path: "/insights/market-pulse" },
  { label: "MOT Intelligence", path: "/insights/mot-intelligence" },
  { label: "Compare Models", path: "/insights/compare-models" },
  { label: "Buyer Guides", path: "/insights/buyer-guides" },
];

export default function InsightsNav() {
  const { pathname } = useLocation();

  return (
    <div className="sticky top-0 z-40 bg-white border-b border-[#E2E8F0]">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-14 gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <img
              src="/wclogo.png"
              alt="WorthCar"
              className="w-8 h-8 object-contain"
            />
            <span className="font-semibold text-[#0A2540] text-sm hidden sm:block">WorthCar.co.uk</span>
          </Link>

          {/* Tabs */}
          <nav className="flex items-center gap-1 overflow-x-auto flex-1 justify-center">
            {TABS.map((tab) => {
              const active = pathname === tab.path;
              return (
                <Link
                  key={tab.path}
                  to={tab.path}
                  className={`whitespace-nowrap px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                    active
                      ? "bg-[#E6F1FB] text-[#2563EB]"
                      : "text-[#64748B] hover:text-[#0A2540] hover:bg-[#F8FAFC]"
                  }`}
                >
                  {tab.label}
                </Link>
              );
            })}
          </nav>

          {/* CTA */}
          <Link
            to="/"
            className="flex-shrink-0 px-4 py-1.5 bg-[#2563EB] text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors hidden sm:block"
          >
            Check a reg →
          </Link>
        </div>
      </div>
    </div>
  );
}